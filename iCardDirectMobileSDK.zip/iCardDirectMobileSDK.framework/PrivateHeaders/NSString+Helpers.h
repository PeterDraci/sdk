//
//  NSString+Helpers.h
//  ICCheckout
//
//  Created by Valio Cholakov on 1/30/17.
//  Copyright © 2017 Intercard Finance AD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Helpers)


- (NSData *)sha1HashedData;

- (NSString *)sha1HashedString;
- (NSString *)encrypted;
- (NSString *)decrypted;
- (NSString *)signature;
- (NSString *)urlEncoded;
- (NSString *)urlDecoded;

@end
