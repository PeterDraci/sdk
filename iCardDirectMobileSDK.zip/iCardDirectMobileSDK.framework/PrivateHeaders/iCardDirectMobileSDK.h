#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "ICRSAManager.h"

@interface iCardDirectMobileSDK : NSObject


@end
