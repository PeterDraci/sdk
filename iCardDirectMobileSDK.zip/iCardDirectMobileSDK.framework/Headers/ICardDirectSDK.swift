import Foundation
import IPGSharedCode
import UIKit

public class ICardDirectSDK {
    
    private init() {
        
    }
    
    // MARK: Variables
    private var purchasePresenter           : PurchasePresenter?
    private var refundPresenter             : RefundPresenter?
    private var cardPresenter               : CardPresenter?
    private var transactionStatusPresenter  : TransactionStatusPresenter?
    private var cardForTransferPresenter    : CardForTransferPresenter?
    
    private var purchaseView                : ICPurchaseView?
    private var refundView                  : ICRefundView?
    private var storedCardView              : ICStoreCardView?
    private var updateCardView              : ICUpdateCardView?
    private var transactionStatusView       : TransactionStatusView?
    private var cardDetailsForTransferView  : ICCardDetailsForTransferView?
    
    private var serviceLocator              : ServiceLocator?                   = nil
    private var themeManager                : ThemeManager                      = ThemeManager()
    private var firstInitalizationComplete  : Bool                              = false
    
    // MARK: Constants
    public static let shared                : ICardDirectSDK                    = ICardDirectSDK()
    let requestSigner                       : RequestSigner                     = RequestSigner()
    static let DefaultVerificationAmount    : String                            = "0.00"
    
    // MARK: Public client API
    public func changeThemeManager(themeManager : ThemeManager) {
        self.themeManager = themeManager
    }
    
    public func currentThemeManager() -> ThemeManager {
        return themeManager
    }
    
    public func initialize( mid                 : String,
                            currency            : String,
                            clientPrivateKey    : String,
                            icardPublicKey      : String,
                            originator          : String,
                            backendUrl          : String,
                            taxUrl              : String,
                            language            : String = "EN",
                            clientDetails       : ICClientDetails?,
                            keyIndex            : Int = 1,
                            isSandbox           : Bool) {
        
        let config = ICCheckoutSdkConfig()
        config.merchantId   = mid
        
        if isSandbox {
            config.privateKey   = clientPrivateKey
        }
        else {
            do {
                let pKeyData = try SwKeyConvert.PrivateKey.pemToPKCS1DER(clientPrivateKey)
                config.privateKey   = pKeyData.base64EncodedString()
            } catch let e {
                let errorMessage = e.localizedDescription
                ICLog.log("errorMessage could not initialize encryption private key \(errorMessage)")
            }
        }
        config.publicKey    = icardPublicKey
        config.originator   = originator
        config.isSandbox    = isSandbox
        setLanguage(lang: language)
        
        self.requestSigner.rsaManager.isSandbox         = isSandbox
        self.requestSigner.rsaManager._privateKeyName   = config.privateKey
        self.requestSigner.rsaManager._publicKeyName    = config.publicKey
        
        self.serviceLocator = ServiceLocator()
        self.serviceLocator?.icNativeConnector          = requestSigner
        
        if !self.firstInitalizationComplete {
            let dbDriver = DatabaseDriverFactory().createDriver()
            self.serviceLocator?.setupKodeinContainer(sqlDriver: dbDriver)
            self.serviceLocator?.setupIcardModel()
            Utils.loadAllFonts
            self.firstInitalizationComplete = true
        }
        
        if let icardModel = self.serviceLocator?.getIcardModel {
            icardModel.mid                      = config.merchantId
            icardModel.clientPrivateKey         = config.privateKey
            icardModel.iCardPublicKey           = config.publicKey
            icardModel.originator               = config.originator
            icardModel.isSandbox                = config.isSandbox
            icardModel.language                 = config.languageFileName
            icardModel.backendUrl               = backendUrl
            icardModel.language                 = language
            icardModel.currency                 = currency.uppercased()
            icardModel.taxUrl                   = taxUrl
            icardModel.keyIndex                 = Int32(keyIndex)
            icardModel.name                     = clientDetails?.name ?? ""
            icardModel.billingAddressCity       = clientDetails?.billingAddressCity ?? ""
            icardModel.billingAddressCountry    = clientDetails?.billingAddressCountry ?? ""
            icardModel.billingAddress1          = clientDetails?.billingAddress ?? ""
            icardModel.emailAddress             = clientDetails?.emailAddress ?? ""
            icardModel.billingAddressPostCode   = clientDetails?.billingAddressPostCode ?? ""
        } else {
            ICLog.log("NO ICARD MODEL ERROR! ICARD SDK SETUP FAILED.")
        }
        
    }
    
    func isSandbox() -> Bool {
        if let icardModel = self.serviceLocator?.getIcardModel {
            return icardModel.isSandbox
        }
        return false
    }
    
    public func purchase(presentingViewController   : UIViewController,
                         orderId                    : String?,
                         cardToken                  : String?,
                         cartItems                  : [ICCartItemModel],
                         expiryDate                 : String?,
                         cardHolderName             : String?,
                         cardCustomName             : String?,
                         delegate                   : ICCheckoutSdkPurchaseDelegate) {
        
        var totalAmount = 0.0
        var cards: [CartItemModel] = []
               
        cartItems.forEach { (elem) in
            let model = elem.mapToCartItemModel()
            cards.append(model)
            totalAmount += model.amount
        }
        
        let token = cardToken ?? ""
        if purchasePresenter == nil {
            self.serviceLocator?.setupPurchasePresenter()
        }
        purchasePresenter = serviceLocator?.getPurchasePresenter
        
        let ipgProtocol = IPGProtocol.Companion()
        let method = ipgProtocol.METHOD_PURCHASE
        
        var expMonth: String = ""
        var expYear: String = ""
        if let dateElems = expiryDate?.split(separator: "/"), dateElems.count == 2 {
            expMonth = String(dateElems[0])
            expYear = String(dateElems[1])
        }
        
        let orderIdFinal = (orderId?.isEmpty ?? true) ? String(Date().timeIntervalSince1970) : orderId!
        let model = ICPurchaseModel(cards: cards, totalAmount: totalAmount, orderId: orderIdFinal, expiryMonth: expMonth, expiryYear: expYear, eci: "", avv: "", xid: "", secure3dTransactionId: "", method: method, cardHolderName: "")
        
        if token.isEmpty {
            if let viewController = StoreCardViewController.inistantiate() {
                let navVc = createNavViewController(viewController: viewController)
                viewController.purchasePresenter    = purchasePresenter
                viewController.purchaseModel        = model
                viewController.customName           = cardCustomName ?? ""
                viewController.cardTokenClearText   = token
                viewController.cardHolderName       = (cardHolderName ?? "").uppercased()
                viewController.verificationAmount   = ICardDirectSDK.DefaultVerificationAmount
                viewController.purchaseDelegate     = delegate
                presentingViewController.present(navVc, animated: true, completion: nil)
                return
            }
        }
        else {
            if let viewController = PerformPaymentViewController.instantiate() {
                model.cardToken             = cardToken
                model.currency              = self.sdkCurrency()
                
                let navVc = createNavViewController(viewController: viewController)
                viewController.presenter        = purchasePresenter
                viewController.model            = model
                viewController.delegate         = delegate
                viewController.panClearText     = ""
                viewController.customName       = cardCustomName ?? ""
                viewController.cardHolderName   = cardHolderName?.uppercased()
                viewController.cardToken        = token
                presentingViewController.present(navVc, animated: true, completion: nil)
                return
            }
        }        
    }
    
    public func updateCard( presentingViewController    : UIViewController,
                            cardToken                   : String,
                            updateCardDelegate          : ICCheckoutSdkUpdateCardDelegate?) {
        if cardToken.isEmpty {
            ICLog.log("cardToken needs to be a valid card token")
            updateCardDelegate?.errorWithCardUpdate(status: -1)
            return
        }
        if cardPresenter == nil {
            self.serviceLocator?.setupCardPresenter()
        }
        let method = IPGProtocol.Companion().METHOD_STORE_CARD_UPDATE
        // TODO check handling of secure3dTransactionId once it is available
        let model = IPGStoredCardUpdate(note: "", token: cardToken, method: method, cardholderName: "", customName: "", eci: "", avv: "", xid: "", secure3dTransactionId: "", cardVerification: "", orderId: "\(Date().timeIntervalSince1970)", amount: ICardDirectSDK.DefaultVerificationAmount)
        if let viewController = StoreCardViewController.inistantiate() {
            viewController.updateCardDelegate   = updateCardDelegate
            viewController.storedCardUpdate     = model
            viewController.cardHolderName       = ""
            viewController.cardTokenClearText   = cardToken
            viewController.verificationAmount   = ICardDirectSDK.DefaultVerificationAmount
            let navViewController = createNavViewController(viewController: viewController)
            presentingViewController.present(navViewController, animated: true, completion: nil)
        }
    }
    
    public func storeCard(  presentingViewController        : UIViewController,
                            orderId                         : String,
                          storeCardDelegate                 : CardStoreDelegate?) {
        if let viewController = StoreCardViewController.inistantiate() {
            viewController.storeCardDelegate    = storeCardDelegate
            viewController.customName           = ""
            viewController.cardTokenClearText   = ""
            viewController.storeCardOrderId     = orderId
            viewController.verificationAmount   = ICardDirectSDK.DefaultVerificationAmount
            let navViewController = createNavViewController(viewController: viewController)
            presentingViewController.present(navViewController, animated: true, completion: nil)
        }
    }
    
    public func storeCardForTransfer( presentingViewController          : UIViewController,
                                      orderId                           : String,
                                      storeCardForTransferDelegate      : ICStoreCardForTransferDelegate) {
        
        if cardForTransferPresenter == nil {
            self.serviceLocator?.setupCardForTransferPresenter()
        }
        cardForTransferPresenter    = serviceLocator?.getCardForTransferPresenter
        

        if let viewControler = CardDetailsForTransferViewControler.inistantiate() {
            viewControler.cardDetailsForTransferDelegate    = storeCardForTransferDelegate
            viewControler.cardDetailsForTransferPresenter   = cardForTransferPresenter
            viewControler.orderId                           = orderId
            let navViewController                           = createNavViewController(viewController: viewControler)
            presentingViewController.present(navViewController, animated: true, completion: nil)
        }
        
    }
    
    public func storeCardAndPurchase(   presentingViewController   : UIViewController,
                                        orderId                    : String?,
                                        cartItems                  : [ICCartItemModel],
                                        cardStoreDelegate          : CardStoreDelegate) {
        
        var totalAmount = 0.0
        var cards: [CartItemModel] = []
        
        cartItems.forEach { (elem) in
            let model = elem.mapToCartItemModel()
            cards.append(model)
            totalAmount += model.amount
        }
        
        if purchasePresenter == nil {
            self.serviceLocator?.setupPurchasePresenter()
        }
        purchasePresenter = serviceLocator?.getPurchasePresenter
        
        let ipgProtocol = IPGProtocol.Companion()
        let method = ipgProtocol.METHOD_PURCHASE
        
        let orderIdFinal = (orderId?.isEmpty ?? true) ? String(Date().timeIntervalSince1970) : orderId!
        ICLog.log("orderIdFinal \(orderIdFinal)")
        let model = ICPurchaseModel(cards: cards, totalAmount: totalAmount, orderId: orderIdFinal, expiryMonth: "", expiryYear: "", eci: "", avv: "", xid: "", secure3dTransactionId: "", method: method, cardHolderName: "")
        
        if let viewController = StoreCardViewController.inistantiate() {
            let navVc = createNavViewController(viewController: viewController)
            viewController.purchasePresenter                = purchasePresenter
            viewController.purchaseModel                    = model
            viewController.cardTokenClearText               = ""
            viewController.verificationAmount               = String(format: "%.2f", totalAmount)
            viewController.storeCardDelegate                = cardStoreDelegate
            viewController.storeCardAndPurchaseOperation    = true
            presentingViewController.present(navVc, animated: true, completion: nil)
            return
        }
        
    }
    
    public func refundTransaction(  transactionReference    : String,
                                    amount                  : Double,
                                    orderId                 : String,
                                    refundDelegate          : RefundDelegate) {
        
        if transactionReference.isEmpty || orderId.isEmpty {
            ICLog.log("refundTransaction cannot exectute with invalid parameters")
            refundDelegate.errorWithRefund(status: -1)
            return
        }
        
        if refundPresenter == nil {
            self.serviceLocator?.setupRefundPresenter()
        }
        refundPresenter = serviceLocator?.getRefundPresenter
        refundView = ICRefundView(delegate: refundDelegate, refundPresenter: self.refundPresenter)
        refundPresenter?.view = refundView
        refundPresenter?.attachView(view: refundView!)
        
        let refundMethodName = IPGProtocol.Companion().METHOD_REFUND
        let name = ServiceLocator().getIcardModel?.name ?? ""
        let model = IPGRefundModel(transactionRef: transactionReference, amount: String(amount), cardholderName: name, orderId: orderId, method: refundMethodName)
        refundPresenter?.refund(ipgRefundModel: model)
    }
    
    public func getTransactionStatus( orderId: String,
                 getTransactionStatusDelegate: GetTransactionStatusDelegate) {
        
        if transactionStatusPresenter == nil {
            self.serviceLocator?.setupGetTransactionPresenter()
        }
        
        transactionStatusPresenter = serviceLocator?.getTransactionStatusPresenter
        self.transactionStatusView = ICTransactionStatusView(transactionStatusPresenter: self.transactionStatusPresenter, delegate: getTransactionStatusDelegate)
        
        self.transactionStatusPresenter?.view = self.transactionStatusView
        self.transactionStatusPresenter?.attachView(view: self.transactionStatusView!)
        self.transactionStatusPresenter?.getTransactionStatus(orderId: orderId)
    }
    
    public func setKeyIndex(keyIndex: Int) {
        serviceLocator?.getIcardModel?.keyIndex = Int32(keyIndex)
    }
    
    public func setLanguage(lang: String) {
        serviceLocator?.getIcardModel?.language = lang
        Bundle.setLanguage(lang)
    }
    
    public func sdkLanguage() -> String {
        return serviceLocator?.getIcardModel?.language ?? "en"
    }
    
    // MARK: Internal SDK Api
    func icardModel() -> Icard? {
        return self.serviceLocator?.getIcardModel
    }
    
    func sdkCurrency() -> String {
        return serviceLocator?.getIcardModel?.currency ?? CurrencyEnum.eur.currency
    }
    
    func createNavViewController(viewController: UIViewController) -> UINavigationController {
        let navViewController = ICNavigationViewController(rootViewController: viewController)
        
        setDefaultStyle(navViewController: navViewController)
        
        return navViewController
    }
    
    func setDefaultStyle(navViewController: UINavigationController) {
        let backgroundColor = themeManager.currentToolbarColor()
        navViewController.navigationBar.backgroundColor = backgroundColor
        navViewController.navigationBar.barTintColor = backgroundColor
        
        let titleBarFont = UIFont(name: UIView().appFontName(fontType: .regular), size: CGFloat(17.0)) ?? UIFont.systemFont(ofSize: 17.0)
        navViewController.navigationBar.titleTextAttributes = [
            .foregroundColor: themeManager.currentToolbarTextColor(),
            .font: titleBarFont
        ]
        navViewController.navigationBar.barStyle = .black
        navViewController.modalPresentationStyle = .overFullScreen
    }
    
    func storeCard(model: IPGStoreCardModel, storeCardDelegate: CardStoreDelegate?, amount: String) {
        if cardPresenter == nil {
            self.serviceLocator?.setupCardPresenter()
        }
        model.amount = amount
        model.cardVerification = "2"
        cardPresenter = serviceLocator?.getCardPresenter
        storedCardView = ICStoreCardView(delegate: storeCardDelegate, storeCardPresenter: self.cardPresenter, cardNumberCheckDelagate: nil)
        cardPresenter?.view = storedCardView
        cardPresenter?.attachView(view: storedCardView!)
        
        cardPresenter?.storeCard(ipgStoreCardModel: model)
    }
    
    func checkCardPan(pan: String, orderId: String, storeCardDelegate: CardStoreDelegate?, cardNumberCheckDelagate: CardNumberCheckDelagate?) {
        if cardPresenter == nil {
            self.serviceLocator?.setupCardPresenter()
        }
        cardPresenter = serviceLocator?.getCardPresenter
        storedCardView = ICStoreCardView(delegate: storeCardDelegate, storeCardPresenter: self.cardPresenter, cardNumberCheckDelagate: cardNumberCheckDelagate)
        cardPresenter?.view = storedCardView
        cardPresenter?.attachView(view: storedCardView!)
        
        cardPresenter?.checkCard(cardNumber: pan, orderId: orderId)
    }
    
    func purchase(model: IPGPurchaseModel, delegate: ICCheckoutSdkPurchaseDelegate) {
        if purchasePresenter == nil {
            self.serviceLocator?.setupPurchasePresenter()
        }
        purchasePresenter = serviceLocator?.getPurchasePresenter
        purchaseView = ICPurchaseView(delegate: delegate, presenter: self.purchasePresenter)
        purchasePresenter?.view = purchaseView
        purchasePresenter?.attachView(view: purchaseView!)
        purchasePresenter?.purchase(ipgPurchaseModel: model)
    }
    
    func updateStoredCard(model: IPGStoredCardUpdate, updateCardDelegate: ICCheckoutSdkUpdateCardDelegate?) {
        if cardPresenter == nil {
            self.serviceLocator?.setupCardPresenter()
        }
        cardPresenter = serviceLocator?.getCardPresenter
        updateCardView = ICUpdateCardView(delegate: updateCardDelegate, cardPresenter: self.cardPresenter)
        cardPresenter?.view = updateCardView
        cardPresenter?.attachView(view: updateCardView!)
        cardPresenter?.updateCard(ipgStoredCardUpdate: model)
    }
}

// MARK: Delegates for client apps

public protocol GetTransactionStatusDelegate {
    func transactionStatusSuccess(transactionStatus: Int, transactionReference: String)
    func errorWithTransactionStatus(status: Int)
}

public protocol ICCheckoutSdkUpdateCardDelegate {
    
    func cardUpdated(storedCardModel: StoredCardModel)
    func errorWithCardUpdate(status: Int)
    
}

public protocol CardStoreDelegate {
    
    func cardStored(storedCardModel: ICStoredCard)
    func errorWithCardStore(status: Int)
    func cardStoredAndPurchaseFinished(storedCardModel: ICStoredCard)
}


protocol CardNumberCheckDelagate {
    
    func cardDetails(checkCardModel: CheckCardModel)
    func invalidPan()
    
}
    
public protocol ICCheckoutSdkPurchaseDelegate {
    
    func transactionReference(transactionRefModel: ICTransactionRefModel)
    func errorWithTransactionReference(status: Int)
    
}

protocol ICCheckoutSdkPurchaseInternalDelegate : ICCheckoutSdkPurchaseDelegate {
    
    func onTaxAvailable(taxModel: TaxModel)
    
}

public protocol RefundDelegate {
    func refundSuccess(transactionReference: String, amount: Double, currency: String)
    func errorWithRefund(status: Int)
}

public protocol ICStoreCardForTransferDelegate {
    func storeCardSuccess(storedCardForTransfer: ICStoredCardForTransferModel)
    func errorWithStoreCard(status: Int)
}

protocol ICStoreCardForTransferInternalDelegate {
    
    func invalidPan()
}

// MARK: Models

public class ICTransactionRefModel : TransactionRefModel {
    
}

public class ICStoredCardForTransferModel: StoredCardForTransferModel {
    
}

public class ICStoreCardModel : IPGStoreCardModel {
    
    static func fromIPGModel(ipgModel: IPGStoreCardModel, clearTextPan: String, clearTextCvc: String) -> ICStoreCardModel {
        let orderId = Date().timeIntervalSince1970
        let model = ICStoreCardModel(cardholderName: ipgModel.cardholderName, customName: ipgModel.customName, expiryMonth: ipgModel.expiryMonth, expiryYear: ipgModel.expiryYear, eci: ipgModel.eci, avv: ipgModel.avv, xid: ipgModel.xid, secure3dTransactionId: ipgModel.secure3dTransactionId, cardVerification: ipgModel.cardVerification, orderId: "\(orderId)", amount: ipgModel.amount, cardItems: ipgModel.cardItems, method: ipgModel.method)
        model.currency = ICardDirectSDK.shared.sdkCurrency()
        model.pan = clearTextPan
        model.cvc = clearTextCvc
        
        return model
    }
}

public class ICClientDetails {
    
    public var name                     : String?
    public var billingAddressCity       : String?
    public var billingAddressCountry    : String?
    public var billingAddress           : String?
    public var emailAddress             : String?
    public var billingAddressPostCode   : String?
    
    public init() {
        
    }
}

public class ICRefundModel : IPGRefundModel {
    
}

public class ICCartItemModel {
    
    public var article     : String         = ""
    public var quantity    : Int           = 0
    public var price       : Double           = 0.0
    public var currency    : String        = ""

    public init() {
        
    }
    
    func mapToCartItemModel() -> CartItemModel {
        let amount = Double(quantity) * price
        let model = CartItemModel(article: article, quantity: Int32(quantity), price: price)
        model.amount = amount
        return model
    }
}

public class ICPurchaseModel : IPGPurchaseModel {

    public init(cards: [CartItemModel], totalAmount: Double, orderId: String, expiryMonth: String, expiryYear: String, eci: String, avv: String, xid: String, secure3dTransactionId: String, method: String, cardHolderName: String) {
        
        super.init(cardItems: cards, orderId: orderId, expiryMonth: expiryMonth, expiryYear: expiryYear, eci: eci, avv: avv, xid: xid, secure3dTransactionId: secure3dTransactionId, method: method, cardholderName: cardHolderName)
        self.totalAmount = totalAmount
        
    }

}

public class ICStoredCard: StoredCardModel {
    
    public init(model: StoredCardModel) {
        super.init(status: model.status, statusMessage: model.statusMessage, signature: model.signature)
        
        self.cardToken = model.cardToken
        self.cardCustomName = model.cardCustomName
        self.cardType = model.cardType
        // self.cardPanLastDigits = model.cardPanLastDigits
        self.maskedPan = model.maskedPan
        self.cardExpDate = model.cardExpDate
        self.approval = model.approval
        self.signature = model.signature
        self.status = model.status
        self.transactionReference = self.transactionReference
    }
    
    public override init(status: Int32, statusMessage: String, signature: String) {
        super.init(status: status, statusMessage: statusMessage, signature: signature)
    }
    
}

public class ICNavigationViewController: UINavigationController {
    
    public override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
}


// MARK: SDK Language Handling
var bundleKey: UInt8 = 0
class AnyLanguageBundle: Bundle {

    override func localizedString(forKey key: String,
                                  value: String?,
                                  table tableName: String?) -> String {

        let bundle = Utils.frameworkBundle()
        if let lang = ServiceLocator().getIcardModel?.language {
            if let path = bundle?.path(forResource: lang, ofType: "lproj") {
                if let bundle = Bundle(path: path) {
                    return bundle.localizedString(forKey: key, value: value, table: tableName)
                }
            }
        }
        return super.localizedString(forKey: key, value: value, table: tableName)
    }
}

extension Bundle {

    class func setLanguage(_ language: String) {

        defer {

            object_setClass(Utils.frameworkBundle(), AnyLanguageBundle.self)
        }
        let bundle = Utils.frameworkBundle()
        let path = bundle?.path(forResource: language, ofType: "lproj")
        objc_setAssociatedObject(Bundle.main, &bundleKey,    path, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
    }
}

public enum ICCardType: Int {
    
    case cardTypeMastercard         = 1
    case cardTypeMaestro            = 2
    case cardTypeVisa               = 3
    case cardTypeElectron           = 4
    case cardTypeVpay               = 5
    case cardTypeJcb                = 6
    case cardTypeBanContact         = 7
    case cardTypeAmericanExpress    = 8
    case cardTypeUnionPay           = 9
    
}
