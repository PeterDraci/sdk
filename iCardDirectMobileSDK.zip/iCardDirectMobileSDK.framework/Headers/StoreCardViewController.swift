import Foundation
import IPGSharedCode
import UIKit

public class StoreCardViewController: BaseViewController {
    
    // MARK: Outlets
    @IBOutlet private weak var cardNumberTextField          : ICTextField!
    @IBOutlet private weak var expDateTextField             : ICTextField!
    @IBOutlet private weak var cvcTextField                 : ICTextField!
    @IBOutlet private weak var cardHolderNameTextField      : ICTextField!
    @IBOutlet private weak var customNameTextField          : ICTextField!
    @IBOutlet private weak var bottomLogoView               : UIImageView!
    @IBOutlet private weak var bottomLabelText              : UILabel!
    @IBOutlet private weak var actionButton                 : UIButton!
    @IBOutlet private weak var logosHolder                  : UIImageView!
    @IBOutlet private weak var bankCardImageView            : UIImageView!
    @IBOutlet private weak var scrollView                   : UIScrollView!
    @IBOutlet private weak var icardLogoHeight              : NSLayoutConstraint!
    @IBOutlet private weak var customNameHeightConstraint   : NSLayoutConstraint!
    
    
    // MARK: Constants
    private let _currentYear                                : Int = Calendar.current.component(.year, from: Date())
    private let kYears                                      : Int = 10
    private let kCvcLength                                  : Int = 3
    
    // MARK: Variables
    private var _selectedYear                               : Int = 0
    private var _selectedMonth                              : Int = 0
    private var _months                                     : [String] = []
    private var avv                                         : String = ""
    private var eci                                         : String = ""
    private var xid                                         : String = ""
    private var dsTransID                                   : String = ""
    private var lastCardScheme                              : String = ""
    var verificationAmount                                  : String = ICardDirectSDK.DefaultVerificationAmount
    var cardTokenClearText                                  : String = ""
    var storeCardAndPurchaseOperation                       : Bool = false
    var cardHolderName                                      : String = ""
    var customName                                          : String = ""
    var storeCardOrderId                                    : String = ""
    
    private var currentMonth : Int {
        return Calendar.current.component(.month, from: Date())
    }

    private var isCurrentYearSelected: Bool {
        return _selectedYear == _currentYear
    }
    
    private var expiryDatePickerView: UIPickerView {
        let pickerView        = UIPickerView()
        pickerView.delegate   = self
        pickerView.dataSource = self
        
        return pickerView
    }

    private var localizedMonths: [String] {
        var months = [String]()
        let dateFormatter = DateFormatter()
        
        for i in 0..<12 {
            months.append(dateFormatter.monthSymbols[i].capitalized)
        }
        
        return months
    }
    
    // MARK: Enums
    
    enum ICPickerComponent: Int {
        case month
        case year
        case count
    }
    
    
    // If the View Controller is part of update stored card flow
    var storedCardUpdate                                    : IPGStoredCardUpdate?
    var updateCardDelegate                                  : ICCheckoutSdkUpdateCardDelegate?
    
    // If the View Controller is part of purchase flow these need to be set
    var purchaseModel                                       : IPGPurchaseModel?
    var purchasePresenter                                   : PurchasePresenter?
    var purchaseDelegate                                    : ICCheckoutSdkPurchaseDelegate?
    
    // If the View Controller is part of store card flow these need to be set
    var storeCardDelegate                                   : CardStoreDelegate?
    
    public static func inistantiate() -> StoreCardViewController? {
        let bundle = Bundle(identifier: "com.icard.iccheckout.ICCheckout")
        return StoreCardViewController(nibName: "StoreCardViewController", bundle: bundle)
    }
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        
        _selectedYear  = _currentYear
        _selectedMonth = self.currentMonth
        _months        = self.localizedMonths
        
        self.cardNumberTextField.addTarget(self, action: #selector(reformatAsCardNumber), for: .editingChanged)
        
        let themeManager = ICardDirectSDK.shared.currentThemeManager()
        
        let cardTypesSuffix = themeManager.darkMode ? "-dark" : ""
        self.logosHolder.image = ThemeManager.loadImage(name: "stored-card-types\(cardTypesSuffix)")
        self.bankCardImageView.image = ThemeManager.loadImage(name: "bank-card")
        
        self.expDateTextField.inputView = self.expiryDatePickerView
        
        
        self.navigationController?.navigationBar.tintColor = themeManager.currentToolbarTextColor()
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(image: ThemeManager.loadImage(name: "back-arrow")?.withRenderingMode(.alwaysTemplate), landscapeImagePhone: nil, style: .plain, target: self, action: #selector(closeViewController))
        
        if let logo = themeManager.merchantLogo?.withRenderingMode(.alwaysOriginal) {
            self.navigationItem.rightBarButtonItem = UIBarButtonItem(image: logo, landscapeImagePhone: logo, style: UIBarButtonItem.Style.plain, target: self, action: #selector(onMerchantLogoTapped))
            
        }
        
        self.view.backgroundColor = themeManager.defaultBackgroundColor()
        
        self.title                                      = "creditDebitCard".localized()
        self.cardNumberTextField                        .delegate = self
        self.expDateTextField                           .delegate = self
        self.cvcTextField                               .delegate = self
        self.cardHolderNameTextField                    .delegate = self
        self.customNameTextField                        .delegate = self
        
        self.cardNumberTextField                        .setPlaceHolder("cardNumber".localized())
        self.expDateTextField                           .setPlaceHolder("mmYy".localized())
        self.cvcTextField                               .setPlaceHolder("cvc".localized())
        self.cardHolderNameTextField                    .setPlaceHolder("cardholderName".localized())
        self.customNameTextField                        .setPlaceHolder("customName".localized())
        
        self.cardNumberTextField                        .setupFont(fontType: .light, fontSize: 14.0)
        self.expDateTextField                           .setupFont(fontType: .light, fontSize: 14.0)
        self.cvcTextField                               .setupFont(fontType: .light, fontSize: 14.0)
        self.cardHolderNameTextField                    .setupFont(fontType: .light, fontSize: 14.0)
        self.customNameTextField                        .setupFont(fontType: .light, fontSize: 14.0)
        
        
        self.cardNumberTextField.textColor              = themeManager.currentFormTextColor()
        self.expDateTextField.textColor                 = themeManager.currentFormTextColor()
        self.cvcTextField.textColor                     = themeManager.currentFormTextColor()
        self.cardHolderNameTextField.textColor          = themeManager.currentFormTextColor()
        self.customNameTextField.textColor              = themeManager.currentFormTextColor()
        
        self.actionButton.backgroundColor = themeManager.currentButtonBackground()
        self.actionButton.setTitle("next".localized(), for: .normal)
        self.actionButton.setTitleColor(themeManager.currentButtonTextColor(), for: UIControl.State.normal)
        self.actionButton.titleLabel?.font = UIFont(name: self.actionButton.appFontName(fontType: .regular), size: 17.0)
        self.actionButton.layer.cornerRadius = 8.0
        self.actionButton.addTarget(self, action: #selector(onActionButtonPressed), for: .touchUpInside)
        
        self.view.backgroundColor = themeManager.defaultBackgroundColor()
        
        self.cardNumberTextField                        .setRightImage(imageName: "card_number")
        self.expDateTextField                           .setRightImage(imageName: "card_exp_date")
        self.cvcTextField                               .setRightImage(imageName: "card_cvc")
        self.cardHolderNameTextField                    .setRightImage(imageName: "card_cardholder_name")

        let bottomLogoImageNameSuffix = themeManager.darkMode ? "_dark" : ""
        self.bottomLogoView.image                       = ThemeManager.loadImage(name: "icard_direct\(bottomLogoImageNameSuffix)")
        self.bottomLabelText.text                       = "icardDirectDetails".localized() //themeManager.merchantText
        self.bottomLabelText.textColor                  = themeManager.currentFormTextColor()
        self.bottomLabelText.font                       = UIFont(name: self.actionButton.appFontName(fontType: .regular), size: 12.0)
        
        self.addInputAccessoryForTextFields(textFields:
            [self.cardNumberTextField, self.expDateTextField, self.cvcTextField, self.cardHolderNameTextField, self.customNameTextField],
                                       dismissable: true, previousNextable: true)
        
        if let name = ICardDirectSDK.shared.icardModel()?.name, !name.isEmpty {
            self.cardHolderNameTextField.text = name
        }
        else if !self.cardHolderName.isEmpty {
            self.cardHolderNameTextField.text = self.cardHolderName
        }
        
        if ServiceLocator().getIcardModel?.isICardDigitalWallet() ?? false {
            self.bottomLogoView.isHidden    = true
            self.bottomLabelText.isHidden   = true
            self.icardLogoHeight.constant   = 0
        }
        
        if !storeCardAndPurchaseOperation && cardTokenClearText.isEmpty && storeCardDelegate == nil {
            customNameHeightConstraint.constant = 0
            customNameTextField.isEnabled = false
            customNameTextField.isHidden = true
        }
        
        LogHandler(logType: LogHandler.Companion().LOG_TYPE_TRACE_LOG, orderId: currentOrderId(), request: "StoreCardViewController -> viewDidLoad", exception: "").log()
    }
    
    @objc override func onKeyboardDonePressed(sender: Any) {
        
        if self.expDateTextField.isFirstResponder {
            self.expDateTextField.text = String(format: "%02d/%d", _selectedMonth, _selectedYear % 100)
        }
        
        super.onKeyboardDonePressed(sender: sender)
    }
    
    @objc private func onMerchantLogoTapped() {
        
    }
    
    public override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    @objc private func closeViewController() {
        let orderId = currentOrderId()
        LogHandler(logType: LogHandler.Companion().LOG_TYPE_BACK_FROM_CARD_DETAILS_SCREEN, orderId: orderId, request: nil, exception: "User pressed back on Card details screen screen and cancelled process").log()
        
        self.navigationController?.dismiss(animated: true, completion: nil)
    }
    
    @objc private func onRightBarButtonItemClick() {
        log("on merchant logo clicked")
    }
    
    private func getPan() -> String {
        return (self.cardNumberTextField.text ?? "").replacingOccurrences(of: " ", with: "")
    }
    
    @objc private func onActionButtonPressed() {
        let expiryDate = self.expDateTextField.text ?? ""
        let pan = self.getPan()
        let cvc = self.cvcTextField.text ?? ""
        let comps = expiryDate.split(separator: "/")
        let cardholder = self.cardHolderNameTextField.text ?? ""
        
        if pan.count < 9 || pan.count > 16 {
            self.showMessage(message: "invalidPanMessage".localized())
            return
        }
        if comps.count < 2 {
            self.showMessage(message: "enter_expiry_date".localized())
            return
        }
        if cvc.isEmpty {
            self.showMessage(message: "enter_cvc_code".localized())
            return
        }
        if cardholder.isEmpty {
            self.showMessage(message: "enterCardHolderName".localized())
            return
        }
        self.purchaseModel?.cardholderName = self.cardNumberTextField.text ?? ""
        
        self.checkCardNumber()
    }
    
    private func currentOrderId() -> String {
        var orderId = self.purchaseModel?.orderId ?? ""
        if orderId.isEmpty {
            orderId = self.storeCardOrderId
        }
        if orderId.isEmpty {
            orderId = "\(NSDate().timeIntervalSince1970)"
        }
        
        return orderId
    }
    
    private func check3DS() {
        let pan = getPan()
        let expDate = self.expDateTextField.text ?? ""
        if expDate.count < 5 || pan.isEmpty {
            return
        }
        let cvc = self.cvcTextField.text ?? ""
        
        if let vc3ds = IC3DSViewController.inistantiate() {
            let month = expDate.substring(to: 2)
            let year = expDate.substring(from: 3)
            let method = IPGProtocol.Companion().METHOD_3DS
            let orderId = currentOrderId()
            
            let model = IPG3dsModel(cardholderName: "", expiryMonth: month, expiryYear: year, orderId: orderId, amount: ICardDirectSDK.DefaultVerificationAmount, method: method)
            model.pan           = pan
            model.cvc           = cvc
            model.currency      = ICardDirectSDK.shared.sdkCurrency()
            model.cardToken     = self.cardTokenClearText
            vc3ds.model         = model
            vc3ds.callback      = { dict in
                self.navigationController?.popViewController(animated: true)
                
                self.avv        = (dict["avv"] as? String) ?? ""
                self.eci        = (dict["eci"] as? String) ?? ""
                self.xid        = (dict["xid"] as? String) ?? ""
                self.dsTransID  = (dict["dsTransID"] as? String) ?? ""
                let status      = Int((dict["status"] as? String) ?? "0") ?? 0
                
                if status != IC3DSViewController.STATUS_SUCCESS {
                    var message = "operationFailed".localized()
                    if status == IC3DSViewController.STATUS_INVALID_PARAMS || status == IC3DSViewController.STATUS_INVALID_PARAMS {
                        message = "invalidCardDetails".localized()
                    }
                    
                    if status == IC3DSViewController.STATUS_UNKNOWN_ERROR {
                        self.dismiss(animated: true) {
                            self.storeCardDelegate?.errorWithCardStore(status: status)
                        }
                    }
                    else {
                        self.showMessage(message: message, callback: {
                            self.dismiss(animated: true) {
                                self.storeCardDelegate?.errorWithCardStore(status: status)
                            }
                        })
                    }
                    
                    return
                }
                
                if let updateModel = self.storedCardUpdate, let updateDelegate = self.updateCardDelegate {
                    ICardDirectSDK.shared.updateStoredCard(model: updateModel, updateCardDelegate: updateDelegate)
                }
                else {
                    self.doStoreCard(avv: self.avv, eci: self.eci, xid: self.xid, dsTransID: self.dsTransID)
                }
            }
            LogHandler(logType: LogHandler.Companion().LOG_TYPE_TRACE_LOG, orderId: currentOrderId(), request: "PerformPaymentViewController -> goToSecure3D", exception: "").log()
            self.navigationController?.pushViewController(vc3ds, animated: true)
        }
    }
    
    private func checkCardNumber() {
        let pan = self.getPan()
        if pan.isEmpty {
            return
        }
        showLoadingHUD()
        
        var orderId: String = ""
        if let purchaseModel = self.purchaseModel, !purchaseModel.orderId.isEmpty {
            orderId = purchaseModel.orderId
        }
        
        if orderId.isEmpty {
            orderId = "\(NSDate().timeIntervalSince1970)"
        }
        ICardDirectSDK.shared.checkCardPan(pan: pan, orderId: orderId, storeCardDelegate: self, cardNumberCheckDelagate: self)
    }
    
    
    private func prepareStoreCardModel() -> IPGStoreCardModel? {
        let cardholder = self.cardHolderNameTextField.text ?? ""
        
        var customName = self.customNameTextField.text ?? ""
        if customName.isEmpty {
            customName = self.lastCardScheme
        }
        
        let expiryDate = self.expDateTextField.text ?? ""
        let pan = self.getPan()
        let cvc = self.cvcTextField.text ?? ""
        let comps = expiryDate.split(separator: "/")
        if comps.count < 2 {
            hideLoadingHUD()
            return nil
        }
        let storeCardMethodName = IPGProtocol.Companion().METHOD_STORE_CARD
        
        var orderId: String = ""
        if let purchaseModel = self.purchaseModel, !purchaseModel.orderId.isEmpty {
            orderId = purchaseModel.orderId
        }
        
        if orderId.isEmpty {
            orderId = "\(NSDate().timeIntervalSince1970)"
        }
        
        let model = IPGStoreCardModel(cardholderName: cardholder, customName: customName, expiryMonth: String(comps[0]), expiryYear: String(comps[1]), eci: "", avv: "", xid: "", secure3dTransactionId: "", cardVerification: "", orderId: orderId, amount: String(0.0), cardItems: [], method: storeCardMethodName)
        model.pan = pan
        if let sdkCurrency = ServiceLocator().getIcardModel?.currency {
            model.currency = sdkCurrency
        }
        model.cvc = cvc
        
        return model
    }
    
    private func doStoreCard(avv: String, eci: String, xid: String, dsTransID: String) {
        if let model = prepareStoreCardModel() {
            model.avv                   = avv
            model.eci                   = eci
            model.xid                   = xid
            model.secure3dTransactionId = dsTransID
            if !self.storeCardOrderId.isEmpty {
                model.orderId   = self.storeCardOrderId
            }
            
            showLoadingHUD()
            ICardDirectSDK.shared.storeCard(model: model, storeCardDelegate: self, amount: self.verificationAmount)
        }
    }
    
    @IBAction func textFieldDidChangeText(_ sender: UITextField) {
        let pan = self.getPan()
        let schema = BaseExtKt.checkCardNumberType(pan)
        let schemeName = schema?.schemeName ?? ""
        
        let size = CGSize(width: 41, height: 36)
        if schema == AcqSchemeEnum.visa {
            self.cardNumberTextField.rightViewWithImage(ThemeManager.loadImage(name: "visa-color"), size: size, rounded: false)
            self.lastCardScheme = schemeName
        }
        else if schema == AcqSchemeEnum.mastercard {
            self.cardNumberTextField.rightViewWithImage(ThemeManager.loadImage(name: "mastercard-color"), size: size, rounded: false)
            self.lastCardScheme = schemeName
        }
        else if schema == AcqSchemeEnum.maestro {
            self.cardNumberTextField.rightViewWithImage(ThemeManager.loadImage(name: "maestro"), size: size, rounded: false)
            self.lastCardScheme = schemeName
        }
        else {
            self.cardNumberTextField.rightViewWithImage(ThemeManager.loadImage(name: "card_number"))
            self.lastCardScheme = ""
        }
    }
    
    
    override func onKeyboardShown(keyboardHeight: CGFloat) {
        if let textField = self.selectedTextField() {
            let scrollViewY = self.scrollView.frame.origin.y
            let textFieldY = textField.frame.origin.y
            
            let totalY = self.view.frame.size.height
        
            let hiddenY = totalY - keyboardHeight
            let textFieldGlobalY = scrollViewY + textFieldY + textField.frame.size.height
            
            let diff = hiddenY - textFieldGlobalY - 50 // 50 is enough to cover the toolbar height difference
            if diff < 0 {
                self.scrollView.contentInset = UIEdgeInsets(top: diff, left: 0, bottom: 0, right: 0)
            }
        }
    }
    
    override func onKeyboardHidden() {
        self.scrollView.contentInset = .zero
    }
    
    
    func selectedTextField() -> UITextField? {

        let totalTextFields : [ICTextField] = [
                cardNumberTextField, expDateTextField, cvcTextField, cardHolderNameTextField, customNameTextField
        ]

        for textField in totalTextFields{
            if textField.isFirstResponder{
                return textField
            }
        }

        return nil

    }
    
}

extension UITextField {
    
    func rightViewWithImage(_ image: UIImage?, size: CGSize? = nil, rounded: Bool = false) {
        self.rightViewMode = .always
        self.rightView     = self.sideViewWithImage(image, size: size, rounded: rounded)
    }
    
    private func sideViewWithImage(_ image: UIImage?, size: CGSize? = nil, rounded: Bool = false) -> UIView {
        var imageSize = CGSize.zero

        if let theSize = size, theSize.width > 0, theSize.height > 0 {
            imageSize = theSize
        }
        else {
            imageSize = image?.size ?? CGSize.zero
        }
        
        let view        = UIView(frame: CGRect(x: 0.0, y: 0.0, width: imageSize.width, height: imageSize.height))
        let imageView   = UIImageView(frame: CGRect(x: 0.0, y: 0.0, width: imageSize.width, height: imageSize.height))
        imageView.image = image
        
        if rounded {
            imageView.clipsToBounds = true
            imageView.layer.cornerRadius = imageView.bounds.width / 2
        }
        
        view.addSubview(imageView)
        
        return view
    }
}

extension StoreCardViewController: UIPickerViewDataSource {
    
    // MARK: Picker View Data Source
    
    public func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return ICPickerComponent.count.rawValue
    }
    
    public func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if component == ICPickerComponent.month.rawValue {
            if self.isCurrentYearSelected {
                return 12 - self.currentMonth + 1
            }
            
            return _months.count
        }
        
        return kYears
    }
    
    public func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if component == ICPickerComponent.month.rawValue {
            if self.isCurrentYearSelected {
                return _months[row + self.currentMonth - 1]
            }
            
            return _months[row]
        }
        
        return String(format: "%d", _currentYear + row)
    }
    
}

extension StoreCardViewController: UIPickerViewDelegate {
    
    // MARK: Picker View Delegate
    
    public func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if component == ICPickerComponent.month.rawValue {
            if self.isCurrentYearSelected {
                _selectedMonth = row + self.currentMonth
            }
            else {
                _selectedMonth = row + 1
            }
        }
        else {
            _selectedYear = _currentYear + row
            
            pickerView.reloadComponent(ICPickerComponent.month.rawValue)
            
            var monthToSelect: Int!
            
            if _selectedMonth >= currentMonth {
                monthToSelect = _selectedMonth - (self.isCurrentYearSelected ? self.currentMonth : 1)
            }
            else {
                monthToSelect = self.isCurrentYearSelected ? 0 : _selectedMonth - 1
            }
            
            pickerView.selectRow(monthToSelect, inComponent: ICPickerComponent.month.rawValue, animated: true)
            
            _selectedMonth = _selectedMonth < currentMonth && self.isCurrentYearSelected ? currentMonth : _selectedMonth
        }
        
        self.expDateTextField.text = String(format: "%02d/%d", _selectedMonth, _selectedYear % 100)
    }
    
}

extension StoreCardViewController: CardStoreDelegate {
    
    public func cardStored(storedCardModel: ICStoredCard) {
        LogHandler(logType: LogHandler.Companion().LOG_TYPE_TRACE_LOG, orderId: currentOrderId(), request: "StoreCardViewController -> cardStored transRef=\(storedCardModel.transactionReference)", exception: "").log()
        
        self.hideLoadingHUD()
        if let model = self.purchaseModel, let presenter = self.purchasePresenter {
            if let viewController = PerformPaymentViewController.instantiate() {
                viewController.panClearText                     = self.getPan()
                viewController.customName                       = self.customNameTextField.text ?? self.customName
                viewController.cardHolderName                   = self.cardHolderNameTextField.text ?? self.cardHolderName
                viewController.cvcClearText                     = self.cvcTextField.text ?? ""
                viewController.presenter                        = presenter
                viewController.cardStoreDelegate                = storeCardDelegate
                viewController.model                            = model
                viewController.cardToken                        = storedCardModel.cardToken ?? ""
                viewController.delegate                         = purchaseDelegate
                viewController.cardStoreDelegate                = self
                if let storeCardModel = prepareStoreCardModel() {
                    viewController.storeCardModel                   = ICStoreCardModel.fromIPGModel(ipgModel: storeCardModel, clearTextPan: getPan(), clearTextCvc: self.cvcTextField.text ?? "")
                }
                viewController.storeCardAndPurchaseOperation    = self.storeCardAndPurchaseOperation
                
                self.navigationController?.pushViewController(viewController, animated: true)
            }
        }
        else {
            LogHandler(logType: LogHandler.Companion().LOG_TYPE_TRACE_LOG, orderId: currentOrderId(), request: "PerformPaymentViewController -> storeCard", exception: "").log()
            self.dismiss(animated: true) {
                self.storeCardDelegate?.cardStored(storedCardModel: storedCardModel)
            }
        }
    }
    
    public func errorWithCardStore(status: Int) {
        LogHandler(logType: LogHandler.Companion().LOG_TYPE_TRACE_LOG, orderId: currentOrderId(), request: "StoreCardViewController -> errorWithCardStore status=\(status)", exception: "").log()
        log("errorWithCardStore \(status)")
        self.hideLoadingHUD()
        let ipgProtocol = IPGProtocol.Companion()
        if status == ipgProtocol.STATUS_ERROR_MISSING_REQ_PARAMS {
            self.showMessage(message: "invalidCardDetails".localized(), callback: {
                self.dismiss(animated: true) {
                    self.storeCardDelegate?.errorWithCardStore(status: status)
                }
            })
        }
        else if status == ipgProtocol.STATUS_ERROR_INVALID_PARAMS {
            self.showMessage(message: "invalidCardDetails".localized(), callback: {
                self.dismiss(animated: true) {
                    self.storeCardDelegate?.errorWithCardStore(status: status)
                }
            })
        }
        else {
            self.dismiss(animated: true) {
                self.storeCardDelegate?.errorWithCardStore(status: status)
            }
        }
    }
    
    public func cardStoredAndPurchaseFinished(storedCardModel: ICStoredCard) {
        log("cardStoredAndPurchaseFinished \(storedCardModel.transactionReference)")
        self.dismiss(animated: true) {
            self.storeCardDelegate?.cardStoredAndPurchaseFinished(storedCardModel: storedCardModel)
        }
    }
}

extension StoreCardViewController {
    
    public func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        return true
    }
    
    public override func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let currentString: NSString = textField.text! as NSString
        
        let newString: NSString = currentString.replacingCharacters(in: range, with: string) as NSString
        
        if textField == self.cardNumberTextField {
            let result = super.textField(textField, shouldChangeCharactersIn: range, replacementString: string)
            if !result {
                return result
            }
        }
        
        if textField == self.cardHolderNameTextField {
            let str = newString as String
            for chr in str {
                if ((chr >= "A" && chr <= "Z") || (chr <= "9" && chr >= "0") || chr == " ") {
                  
                }
                else {
                    return false
                }
            }
        }
        
        if textField == self.customNameTextField {
            let maxLength = 30
            return newString.length <= maxLength
        }
        
        if string == "" {
            return true
        }
        
        if textField == self.cvcTextField {
            if self.cvcTextField.text?.count ?? 0 == kCvcLength {
                return false
            }
        }
        
        return true
    }
    
}

extension StoreCardViewController : CardNumberCheckDelagate {
    
    func cardDetails(checkCardModel: CheckCardModel) {
        LogHandler(logType: LogHandler.Companion().LOG_TYPE_TRACE_LOG, orderId: currentOrderId(), request: "StoreCardViewController -> pan is valid cardDetails", exception: "").log()
        self.hideLoadingHUD()
        if let model = self.purchaseModel, let presenter = self.purchasePresenter, let storeCardModel = prepareStoreCardModel() {
            if let viewController = PerformPaymentViewController.instantiate() {
                let expiryDate                                  = self.expDateTextField.text ?? ""
                let pan                                         = self.getPan()
                let cvc                                         = self.cvcTextField.text ?? ""
                let comps                                       = expiryDate.split(separator: "/")
                
                if comps.count < 2 {
                    return
                }
                
                model.expiryMonth                               = String(comps[0])
                model.expiryYear                                = String(comps[1])
                model.pan                                       = pan
                model.cvc                                       = cvc
                if let sdkCurrency = ServiceLocator().getIcardModel?.currency {
                    model.currency                              = sdkCurrency
                }
                viewController.cardToken                        = self.cardTokenClearText
                viewController.panClearText                     = getPan()
                viewController.customName                       = self.customNameTextField.text ?? self.customName
                viewController.cvcClearText                     = self.cvcTextField.text ?? ""
                viewController.presenter                        = presenter
                viewController.cardHolderName                   = self.cardHolderNameTextField.text ?? self.cardHolderName
                viewController.model                            = model
                viewController.cardStoreDelegate                = storeCardDelegate
                viewController.storeCardModel                   = ICStoreCardModel.fromIPGModel(ipgModel: storeCardModel, clearTextPan: getPan(), clearTextCvc: self.cvcTextField.text ?? "")
                viewController.cardStoreDelegate                = self
                viewController.storeCardAndPurchaseOperation    = self.storeCardAndPurchaseOperation
                viewController.delegate                         = self.purchaseDelegate
                
                self.navigationController?.pushViewController(viewController, animated: true)
            }
        }
        else {
            self.check3DS()
        }
    }
    
    func invalidPan() {
        LogHandler(logType: LogHandler.Companion().LOG_TYPE_TRACE_LOG, orderId: currentOrderId(), request: "StoreCardViewController -> invalidPan", exception: "").log()
        self.hideLoadingHUD()
        let alertController = UIAlertController(title: "iCard", message: "invalidPanMessage".localized(), preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "close".localized(), style: UIAlertAction.Style.default, handler: { (_) in
            alertController.dismiss(animated: true, completion: nil)
        }))
        self.present(alertController, animated: true, completion: nil)
    }
    
    
}
