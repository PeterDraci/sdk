import Foundation
import IPGSharedCode
import UIKit

class PerformPaymentViewController: BaseViewController {
    
    // MARK: Outlets
    @IBOutlet private weak var topLabel                     : ICLabel!
    @IBOutlet private weak var expDateLabel                 : ICLabel!
    @IBOutlet private weak var expDateValueLabel            : ICLabel!
    @IBOutlet private weak var totalValueLabel              : ICLabel!
    @IBOutlet private weak var totalLabel                   : ICLabel!
    @IBOutlet private weak var feeValueLabel                : ICLabel!
    @IBOutlet private weak var feeLabel                     : ICLabel!
    @IBOutlet private weak var amountValueLabel             : ICLabel!
    @IBOutlet private weak var amountLabel                  : ICLabel!
    @IBOutlet private weak var sectionSeparatorView         : UIView!
    @IBOutlet private weak var customNameValueLabel         : ICLabel!
    @IBOutlet private weak var customNameLabel              : ICLabel!
    @IBOutlet private weak var cardHolderValueLabel         : ICLabel!
    @IBOutlet private weak var cardHolderNameLabel          : ICLabel!
    @IBOutlet private weak var cardNumberLabel              : ICLabel!
    @IBOutlet private weak var cardNumberValueLabel         : ICLabel!
    @IBOutlet private weak var topImageView                 : UIImageView!
    @IBOutlet private weak var actionButton                 : UIButton!
    @IBOutlet private weak var detailsLabel                 : ICLabel!
    @IBOutlet private weak var logoImageView                : UIImageView!
    @IBOutlet private weak var headerContainerView          : UIView!
    
    // Constraints
    @IBOutlet private weak var cardNumberHeight             : NSLayoutConstraint!
    @IBOutlet private weak var cardNumberValueHeight        : NSLayoutConstraint!
    @IBOutlet private weak var expDateHeight                : NSLayoutConstraint!
    @IBOutlet private weak var expDateValueHeight           : NSLayoutConstraint!
    @IBOutlet private weak var cardholderNameHeight         : NSLayoutConstraint!
    @IBOutlet private weak var cardholderNameValueHeight    : NSLayoutConstraint!
    @IBOutlet private weak var customNameHeight             : NSLayoutConstraint!
    @IBOutlet private weak var customNameValueHeight        : NSLayoutConstraint!
    @IBOutlet private weak var expiryDateTopMargin          : NSLayoutConstraint!
    @IBOutlet private weak var cardholderNameTopMargin      : NSLayoutConstraint!
    @IBOutlet private weak var customNameTopMargin          : NSLayoutConstraint!
    @IBOutlet private weak var logoImageViewHeight          : NSLayoutConstraint!
    
    
    
    // MARK: Variables
    var model                                               : IPGPurchaseModel?
    var storeCardModel                                      : ICStoreCardModel?
    var presenter                                           : PurchasePresenter?
    var delegate                                            : ICCheckoutSdkPurchaseDelegate?
    var cardStoreDelegate                                   : CardStoreDelegate?
    var panClearText                                        : String    = ""
    var cvcClearText                                        : String    = ""
    var cardToken                                           : String    = ""
    var storeCardAndPurchaseOperation                       : Bool      = false
    var cardHolderName                                      : String?   = nil
    var customName                                          : String    = ""
    var taxModel                                            : TaxModel?
    
    public static func instantiate() -> PerformPaymentViewController? {
        let bundle = Bundle(identifier: "com.icard.iccheckout.ICCheckout")
        return PerformPaymentViewController(nibName: "PerformPaymentViewController", bundle: bundle)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let themeManager = ICardDirectSDK.shared.currentThemeManager()
        
        self.topImageView.image = ThemeManager.loadImage(name: "wallet")?.withRenderingMode(.alwaysTemplate)
        self.topImageView.contentMode = .scaleAspectFit
        self.topImageView.tintColor    = themeManager.darkMode ? .white : .darkGray
        
        self.headerContainerView.backgroundColor = themeManager.darkMode ? UIColor.clear : UIColor(hex: "#F7F7F7FF")!
        
        if let logo = themeManager.merchantLogo?.withRenderingMode(.alwaysOriginal) {
            self.navigationItem.rightBarButtonItem = UIBarButtonItem(image: logo, landscapeImagePhone: logo, style: UIBarButtonItem.Style.plain, target: self, action: #selector(onMerchantLogoTapped))
            
        }
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(image: ThemeManager.loadImage(name: "back-arrow")?.withRenderingMode(.alwaysTemplate), landscapeImagePhone: nil, style: .plain, target: self, action: #selector(closeViewController))
        
        self.detailsLabel.text                                  = themeManager.merchantText
        self.topLabel.textColor                                 = themeManager.currentFormTextColor()
        self.cardNumberLabel.textColor                          = themeManager.currentFormTextColor()
        self.cardNumberValueLabel.textColor                     = themeManager.currentFormTextColor()
        self.expDateLabel.textColor                             = themeManager.currentFormTextColor()
        self.expDateValueLabel.textColor                        = themeManager.currentFormTextColor()
        self.cardHolderNameLabel.textColor                      = themeManager.currentFormTextColor()
        self.cardHolderValueLabel.textColor                     = themeManager.currentFormTextColor()
        self.customNameLabel.textColor                          = themeManager.currentFormTextColor()
        self.customNameValueLabel.textColor                     = themeManager.currentFormTextColor()
        self.amountLabel.textColor                              = themeManager.currentFormTextColor()
        self.amountValueLabel.textColor                         = themeManager.currentFormTextColor()
        self.feeLabel.textColor                                 = themeManager.currentFormTextColor()
        self.feeValueLabel.textColor                            = themeManager.currentFormTextColor()
        self.totalLabel.textColor                               = themeManager.currentFormTextColor()
        self.totalValueLabel.textColor                          = themeManager.currentFormTextColor()
        
        self.view.backgroundColor = themeManager.defaultBackgroundColor()
        
        self.actionButton.addTarget(self, action: #selector(onActionButtonPressed), for: .touchUpInside)
        
        self.topLabel                               .setupFont(fontType: .regular, fontSize: 14)
        self.cardNumberLabel                        .setupFont(fontType: .extralight, fontSize: 14)
        self.cardNumberValueLabel                   .setupFont(fontType: .regular, fontSize: 14)
        self.expDateLabel                           .setupFont(fontType: .extralight, fontSize: 14)
        self.expDateValueLabel                      .setupFont(fontType: .regular, fontSize: 14)
        self.cardHolderNameLabel                    .setupFont(fontType: .extralight, fontSize: 14)
        self.cardHolderValueLabel                   .setupFont(fontType: .regular, fontSize: 14)
        self.customNameLabel                        .setupFont(fontType: .extralight, fontSize: 14)
        self.customNameValueLabel                   .setupFont(fontType: .regular, fontSize: 14)
        self.amountLabel                            .setupFont(fontType: .extralight, fontSize: 14)
        self.amountValueLabel                       .setupFont(fontType: .regular, fontSize: 14)
        self.feeLabel                               .setupFont(fontType: .extralight, fontSize: 14)
        self.feeValueLabel                          .setupFont(fontType: .regular, fontSize: 14)
        self.totalLabel                             .setupFont(fontType: .extralight, fontSize: 14)
        self.totalValueLabel                        .setupFont(fontType: .regular, fontSize: 14)
        
        self.topLabel.text              = "fundingDetails".localized()
        self.cardNumberLabel.text       = "cardNumberCol".localized()
        self.expDateLabel.text          = "expiryDateCol".localized()
        self.cardHolderNameLabel.text   = "cardHolderNameCol".localized()
        self.customNameLabel.text       = "cardCustomNameCol".localized()
        self.amountLabel.text           = "\("amount".localized()):"
        self.feeLabel.text              = "fee".localized()
        self.totalLabel.text            = "totalFromYourCard".localized()
        
        self.title                      = themeManager.confirmPaymentTitle
        
        self.actionButton.layer.cornerRadius = 8.0
        self.actionButton.setTitle("next".localized(), for: .normal)
        self.actionButton.setTitleColor(themeManager.currentButtonTextColor(), for: .normal)
        self.actionButton.backgroundColor = themeManager.currentButtonBackground()
        
        
        let purchaseView = ICPurchaseView(delegate: self, presenter: self.presenter)
        self.presenter?.view = purchaseView
        self.presenter?.attachView(view: purchaseView)
        
        self.cardHolderValueLabel.text = self.cardHolderName ?? ""
        if let model = self.model {
            
            if !model.expiryMonth.isEmpty && !model.expiryYear.isEmpty {
                self.expDateValueLabel.text = "\(model.expiryMonth)/\(model.expiryYear)"
            }
            else {
                self.expDateHeight.constant = 0
                self.expDateValueHeight.constant = 0
                self.expiryDateTopMargin.constant = 0
            }
            
            if self.panClearText.count >= 4 {
                let lastFourDigits =  self.panClearText.substring(from: self.panClearText.count - 4)
                self.cardNumberValueLabel.text = "*\(lastFourDigits)"
            }
            else if let pan = ICardDirectSDK.shared.requestSigner.rsaManager.decryptedString(model.pan), pan.count > 4 {
                let panMasked = pan.substring(from: pan.count - 5)
                if panMasked.hasPrefix("*") {
                    self.cardNumberValueLabel.text = panMasked
                }
                else {
                    self.cardNumberValueLabel.text = "*\(panMasked)"
                }
            }
            else {
                self.cardNumberValueLabel.text = ""
                self.cardNumberValueHeight.constant = 0
                self.cardNumberHeight.constant = 0
            }
            self.updateTotals(tax: 0.0)
        }
        else {
            self.expDateLabel.text      = ""
            self.expDateValueLabel.text = ""
            
            self.expDateHeight.constant = 0
            self.expDateValueHeight.constant = 0
        }
        
        if ServiceLocator().getIcardModel?.isICardDigitalWallet() ?? false {
            self.logoImageView.isHidden = true
            self.detailsLabel.isHidden  = true
            self.logoImageViewHeight.constant = 0
        }
        
        
        // Form colors
        self.topLabel.textColor             = themeManager.currentFormTextColor()
        self.amountValueLabel.textColor     = themeManager.currentFormTextColor()
        self.amountLabel.textColor          = themeManager.currentFormTextColor()
        self.amountValueLabel.textColor     = themeManager.currentFormTextColor()
        self.expDateLabel.textColor         = themeManager.currentFormTextColor()
        self.expDateValueLabel.textColor    = themeManager.currentFormTextColor()
        
        self.expDateValueLabel.textColor    = themeManager.currentFormTextColor()
        self.detailsLabel.textColor         = themeManager.currentFormTextColor()
        
        
        let bottomLogoImageNameSuffix = themeManager.darkMode ? "_dark" : ""
        self.logoImageView.image            = ThemeManager.loadImage(name: "icard_direct\(bottomLogoImageNameSuffix)")
        self.detailsLabel.text              = "icardDirectDetails".localized()
        self.detailsLabel.textColor         = themeManager.currentFormTextColor()
        self.detailsLabel.font              = UIFont(name: self.actionButton.appFontName(fontType: .regular), size: 12.0)
     
        if let taxUrl = ServiceLocator().getIcardModel?.taxUrl, !taxUrl.isEmpty {
            showLoadingHUD()
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                var orderId: String = self.model?.orderId ?? ""
                self.log("orderId 1 \(orderId)")
                if orderId.isEmpty {
                    orderId = self.storeCardModel?.orderId ?? ""
                    self.log("orderId 2 \(orderId)")
                }
                
                if orderId.isEmpty {
                    orderId = "\(NSDate().timeIntervalSince1970)"
                    self.log("orderId 3 \(orderId)")
                }
                self.log("taxUrl open taxUrl=\(taxUrl) cardToken=\(self.cardToken)")
                self.presenter?.getMerchantTax(orderId: "\(orderId)", token: self.cardToken, pan: self.panClearText)
            }
        } else {
            self.feeValueLabel.text = ""
            self.feeLabel.text = ""
        }
        
        self.customNameValueLabel.text = self.customName
        
        LogHandler(logType: LogHandler.Companion().LOG_TYPE_TRACE_LOG, orderId: currentOrderId(), request: "PerformPaymentViewController -> viewDidLoad", exception: "").log()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        let themeManager = ICardDirectSDK.shared.currentThemeManager()
        self.navigationController?.navigationBar.tintColor = themeManager.currentToolbarTextColor()
        let mainColor = themeManager.currentToolbarColor()
        self.navigationController?.navigationBar.backgroundColor = mainColor
        self.navigationController?.navigationBar.barTintColor = mainColor
        if let navViewController = self.navigationController {
            ICardDirectSDK.shared.setDefaultStyle(navViewController: navViewController)
        }
        
        
        if self.cardHolderName?.isEmpty ?? true {
            self.cardholderNameHeight.constant = 0
            self.cardholderNameValueHeight.constant = 0
            self.cardholderNameTopMargin.constant = 0
        }
        else {
            let heightCardholderName = self.cardHolderNameLabel.text?.height(withConstrainedWidth: self.cardHolderNameLabel.frame.width, font: self.cardHolderNameLabel.font) ?? 16.0
            let heightCardholderValue = self.cardHolderValueLabel.text?.height(withConstrainedWidth: self.cardHolderValueLabel.frame.width, font: self.cardHolderValueLabel.font) ?? 16.0
            let cardholderHeight = max(heightCardholderName, heightCardholderValue)
            
            self.cardholderNameHeight.constant = cardholderHeight
            self.cardholderNameValueHeight.constant = cardholderHeight
        }
        
        if self.customName.isEmpty {
            self.customNameHeight.constant = 0
            self.customNameValueHeight.constant = 0
            self.customNameTopMargin.constant = 0
        }
        else {
            let heightCustomName = self.customNameLabel.text?.height(withConstrainedWidth: self.customNameLabel.frame.size.width, font: self.customNameLabel.font) ?? 16.0
            
            let heightCustomNameValue = self.customNameValueLabel.text?.height(withConstrainedWidth: self.customNameValueLabel.frame.size.width, font: self.customNameValueLabel.font) ?? 16.0
            let customNameHeight = max(heightCustomName, heightCustomNameValue)
            
            self.customNameHeight.constant = customNameHeight
            self.customNameValueHeight.constant = customNameHeight
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let navViewController = self.navigationController {
            ICardDirectSDK.shared.setDefaultStyle(navViewController: navViewController)
        }
    }
    
    @objc private func closeViewController() {
        let orderId = currentOrderId()
        LogHandler(logType: LogHandler.Companion().LOG_TYPE_BACK_FROM_PAYMENT_PREVIEW_SCREEN, orderId: orderId, request: nil, exception: "User pressed back on Payment preview screen screen and cancelled process").log()
        if self.storeCardAndPurchaseOperation {
            self.navigationController?.popViewController(animated: true)
        }
        else {
            self.navigationController?.dismiss(animated: true, completion: nil)
        }
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    private func currentOrderId() -> String {
        var orderId: String = self.model?.orderId ?? ""
        if orderId.isEmpty {
            orderId = self.storeCardModel?.orderId ?? ""
        }
        if orderId.isEmpty {
            orderId = "\(Date().timeIntervalSince1970)"
        }
        
        return orderId
    }
    
    @objc private func onActionButtonPressed() {
        if let model = self.model {
            if let viewController = IC3DSViewController.inistantiate() {
                
                let model3ds = IPG3dsModel(cardholderName: "", expiryMonth: "", expiryYear: "", orderId: "", amount: "", method: "")
                model3ds.cardholderName = self.cardHolderName ?? ""
                model3ds.orderId        = "\(currentOrderId())"
                model3ds.expiryMonth    = model.expiryMonth
                model3ds.expiryYear     = model.expiryYear
                model3ds.amount         = String(format: "%.2f", model.totalAmount)
                model3ds.cardToken      = self.cardToken
                model3ds.currency       = ICardDirectSDK.shared.sdkCurrency()
                model3ds.pan            = self.panClearText
                model3ds.cvc            = self.cvcClearText
                model3ds.method         = IPGProtocol.Companion().METHOD_3DS
                
                viewController.model    = model3ds
                viewController.callback = { dict in
                    self.navigationController?.popViewController(animated: true)
                    let avv         = (dict["avv"] as? String) ?? ""
                    let eci         = (dict["eci"] as? String) ?? ""
                    let xid         = (dict["xid"] as? String) ?? ""
                    let dsTransID   = (dict["dsTransID"] as? String) ?? ""
                    let status      = Int((dict["status"] as? String) ?? "0") ?? 0
                    
                    if !self.cardToken.isEmpty {
                        LogHandler(logType: LogHandler.Companion().LOG_TYPE_TRACE_LOG, orderId: self.currentOrderId(), request: "PerformPaymentViewController -> purchaseWithToken", exception: "").log()
                    } else {
                        LogHandler(logType: LogHandler.Companion().LOG_TYPE_TRACE_LOG, orderId: self.currentOrderId(), request: "PerformPaymentViewController -> purchaseWithNewCard", exception: "").log()
                    }
                    
                    if status != IC3DSViewController.STATUS_SUCCESS {
                        var message = "operationFailed".localized()
                        if status == IC3DSViewController.STATUS_INVALID_PARAMS || status == IC3DSViewController.STATUS_INVALID_PARAMS {
                            message = "invalidCardDetails".localized()
                        }
                        
                        if status == IC3DSViewController.STATUS_UNKNOWN_ERROR {
                            self.dismiss(animated: true) {
                                self.delegate?.errorWithTransactionReference(status: status)
                            }
                        }
                        else {
                            self.showMessage(message: message) {
                                self.dismiss(animated: true) {
                                    self.delegate?.errorWithTransactionReference(status: status)
                                }
                            }
                        }
                        
                        return
                    }
                    
                    if let model = self.model {
                        model.avv           = avv
                        model.eci           = eci
                        model.xid           = xid
                        self.log("self.cardToken clear text \(self.cardToken) ___ \(model.cardToken ?? "")")
                        if !self.cardToken.isEmpty {
                            model.cardToken     = self.cardToken
                        }
                        model.pan                       = self.panClearText
                        model.cvc                       = self.cvcClearText
                        model.currency                  = ICardDirectSDK.shared.sdkCurrency()
                        model.secure3dTransactionId     = dsTransID
                            
                        if self.storeCardAndPurchaseOperation, let storeCardModel = self.storeCardModel,
                            let cardStoreDelegate = self.cardStoreDelegate {
                            storeCardModel.eci                      = eci
                            storeCardModel.avv                      = avv
                            storeCardModel.xid                      = xid
                            storeCardModel.orderId                  = self.currentOrderId()
                            storeCardModel.secure3dTransactionId    = dsTransID
                            self.log("PerformPaymentViewController storeCardAndPurchaseOperation")
                            self.showLoadingHUD()
                            ICardDirectSDK.shared.storeCard(model: storeCardModel,
                                                            storeCardDelegate: cardStoreDelegate,
                                                            amount: "\(model.totalAmount)")
                            
                        }
                        else {
                             self.log("PerformPaymentViewController purchase")
                            self.showLoadingHUD()
                            self.presenter?.purchase(ipgPurchaseModel: model)
                        }
                    }
                    else {
                        self.log("PerformPaymentViewController no model")
                    }
                }
                LogHandler(logType: LogHandler.Companion().LOG_TYPE_TRACE_LOG, orderId: currentOrderId(), request: "PerformPaymentViewController -> goToSecure3D", exception: "").log()
                self.navigationController?.pushViewController(viewController, animated: true)
            }
        } else {
            let alertViewController = UIAlertController(title: "iCard", message: "errNoPurchaseData".localized(), preferredStyle: .alert)
            self.present(alertViewController, animated: true, completion: nil)
        }
    }
    
    private func updateTotals(tax: Double) {
        guard let model = self.model else {
            self.totalLabel.text = ""
            self.totalValueLabel.text = ""
            return
        }
        let currencyValue = currencyForSymbol(model.currency)
        let totalAmountPurchase = model.totalAmount + tax
        
        let totalAmountPurchaseFormatted = String(format: "%.2f", totalAmountPurchase)
        let totalAmountFormatted = String(format: "%.2f", model.totalAmount)
        
        self.totalValueLabel.text = "\(totalAmountPurchaseFormatted) \(currencyValue)"
        self.amountValueLabel.text = "\(totalAmountFormatted) \(currencyValue)"
        model.totalAmount = totalAmountPurchase
        
        let currentAmountStoreCardModel = Double(self.storeCardModel?.amount ?? "0.0") ?? 0.0
        self.log("currentAmountStoreCardModel \(currentAmountStoreCardModel)")
        let storeCardTotalAmount = currentAmountStoreCardModel + tax
        self.log("storeCardTotalAmount \(storeCardTotalAmount)")
        self.storeCardModel?.amount = "\(storeCardTotalAmount)"
    }
    
    @objc func onMerchantLogoTapped() {
        
    }
    
}

extension PerformPaymentViewController : ICCheckoutSdkPurchaseInternalDelegate {
    
    func transactionReference(transactionRefModel: ICTransactionRefModel) {
        self.hideLoadingHUD()
        self.dismiss(animated: true) {
            self.delegate?.transactionReference(transactionRefModel: transactionRefModel)
        }
    }
    
    func errorWithTransactionReference(status: Int) {
        self.hideLoadingHUD()
        self.dismiss(animated: true) {
            self.delegate?.errorWithTransactionReference(status: status)
        }
    }
    
    private func currencyForSymbol(_ symbol: String) -> String {
        let currency            = symbol
        var currencySymbol = ""
        if currency == CurrencyEnum.bgn.currency || currency == CurrencyEnum.bgn.isoCode {
            currencySymbol      = CurrencyEnum.bgn.currency
        }
        else if currency == CurrencyEnum.eur.currency || currency == CurrencyEnum.eur.isoCode {
            currencySymbol      = CurrencyEnum.eur.currency
        }
        else if currency == CurrencyEnum.usd.currency || currency == CurrencyEnum.usd.isoCode {
            currencySymbol      = CurrencyEnum.usd.currency
        }
        else if currency == CurrencyEnum.gbp.currency || currency == CurrencyEnum.gbp.isoCode {
            currencySymbol      = CurrencyEnum.gbp.currency
        }
        else if currency == CurrencyEnum.hrk.currency || currency == CurrencyEnum.hrk.isoCode {
            currencySymbol      = CurrencyEnum.hrk.currency
        }
        else if currency == CurrencyEnum.ron.currency || currency == CurrencyEnum.ron.isoCode {
            currencySymbol      = CurrencyEnum.ron.currency
        }
        else if currency == CurrencyEnum.chf.currency || currency == CurrencyEnum.chf.isoCode {
            currencySymbol      = CurrencyEnum.chf.currency
        }
        else if currency == CurrencyEnum.jpy.currency || currency == CurrencyEnum.jpy.isoCode {
            currencySymbol      = CurrencyEnum.jpy.currency
        }
        else if currency == CurrencyEnum.pln.currency || currency == CurrencyEnum.pln.isoCode {
            currencySymbol      = CurrencyEnum.pln.currency
        }
        else if currency == CurrencyEnum.czk.currency || currency == CurrencyEnum.czk.isoCode {
            currencySymbol      = CurrencyEnum.czk.currency
        }
        
        return currencySymbol
    }
    
    func onTaxAvailable(taxModel: TaxModel) {
        self.log("onTaxAvailable")
        self.taxModel           = taxModel
        self.hideLoadingHUD()
        let currency            = ServiceLocator().getIcardModel?.currency ?? ""
        let currencySymbol      = currencyForSymbol(currency)
        self.log("onTaxAvailable \(currencySymbol)")
        
        let taxFormatted = String(format: "%.2f", taxModel.tax)
        self.feeValueLabel.text = "\(taxFormatted) \(currencySymbol)"
        self.updateTotals(tax: taxModel.tax)
        let elems = taxModel.maskedPan.split(separator: "*")
        if !elems.isEmpty {
            let elem = String(elems[elems.count - 1])
            self.cardNumberValueLabel.text = "*\(elem)"
            self.cardNumberValueHeight.constant = 16
            self.cardNumberHeight.constant = 16
        }
        else {
            self.cardNumberHeight.constant = 0
            self.cardNumberValueHeight.constant = 0
        }
    }
    
    
}
