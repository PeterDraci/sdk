#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class IPGSCKotlinEnumCompanion, IPGSCKotlinEnum<E>, IPGSCCurrencyEnum, IPGSCKotlinArray<T>, IPGSCIPGProtocolCompanion, IPGSCLogHandlerCompanion, IPGSCKotlinUnit, IPGSCPlatformServiceLocator, IPGSCKtor_client_coreHttpClient, IPGSCServiceLocator, IPGSCCardPresenter, IPGSCIcard, IPGSCPurchasePresenter, IPGSCRefundPresenter, IPGSCTransactionStatusPresenter, IPGSCIPGDatabaseCompanion, IPGSCLogsEntity, IPGSCRuntimeQuery<__covariant RowType>, IPGSCPresenterCoroutineScope, IPGSCBaseResponseModel, IPGSCKotlinThrowable, IPGSCCheckCardModel, IPGSCStoredCardModel, IPGSCBasePresenter<T>, IPGSCStoreCardUseCase, IPGSCStoredCardUpdateUseCase, IPGSCCheckCardUseCase, IPGSCIPGStoreCardModel, IPGSCIPGStoredCardUpdate, IPGSCPurchaseUseCase, IPGSCGetMerchantTaxUseCase, IPGSCIPGPurchaseModel, IPGSCTaxModel, IPGSCTransactionRefModel, IPGSCRefundUseCase, IPGSCIPGRefundModel, IPGSCGetTransactionStatusUseCase, IPGSCTransactionStatusModel, IPGSCKotlinx_serialization_jsonJson, IPGSCBaseApi<ResponseModel, RequestModel>, IPGSCIPGCheckCardModel, IPGSCIPGLogModel, IPGSCLogResponseModel, IPGSCRefundTransactionModel, IPGSCIPGGetMerchantTax, IPGSCIPGTransactionStatusModel, IPGSCKotlinException, IPGSCEither<__covariant F, __covariant S, __covariant E>, IPGSCBaseUseCaseNone, IPGSCBaseUseCase<__covariant Type, __contravariant Params>, IPGSCCheckCardApi, IPGSCTaxApi, IPGSCTransactionStatusApi, IPGSCLogApi, IPGSCPurchaseApi, IPGSCRefundApi, IPGSCStoreCardApi, IPGSCUpdateCardApi, IPGSCAcqSchemeEnum, IPGSCCartItemModelCompanion, IPGSCCheckCardModelCompanion, IPGSCEitherError<__covariant E>, IPGSCKotlinNothing, IPGSCEitherFailure<__covariant F>, IPGSCEitherSuccess<__covariant S>, IPGSCIcardCompanion, IPGSCLogResponseModelCompanion, IPGSCRefundTransactionModelCompanion, IPGSCStoredCardModelCompanion, IPGSCTaxModelCompanion, IPGSCTransactionRefModelCompanion, IPGSCTransactionStatusModelCompanion, IPGSCBaseRequestModelCompanion, IPGSCBaseRequestParametersCompanion, IPGSCBaseRequestParameters, IPGSCBaseRequestModel, IPGSCIPG3dsModelCompanion, IPGSCIPGCheckCardModelCompanion, IPGSCIPGGetMerchantTaxCompanion, IPGSCIPGLogModelCompanion, IPGSCCartItemModel, IPGSCIPGPurchaseModelCompanion, IPGSCIPGRefundModelCompanion, IPGSCIPGStoreCardModelCompanion, IPGSCIPGStoredCardUpdateCompanion, IPGSCIPGTransactionStatusModelCompanion, IPGSCDatabaseDriverFactory, IPGSCKodein_diDIModule, IPGSCRuntimeTransacterTransaction, IPGSCKotlinRuntimeException, IPGSCKotlinIllegalStateException, IPGSCKtor_client_coreHttpClientEngineConfig, IPGSCKtor_client_coreHttpClientConfig<T>, IPGSCKtor_eventsEvents, IPGSCKtor_client_coreHttpReceivePipeline, IPGSCKtor_client_coreHttpRequestPipeline, IPGSCKtor_client_coreHttpResponsePipeline, IPGSCKtor_client_coreHttpSendPipeline, IPGSCKodein_diDITrigger, IPGSCKotlinx_serialization_coreSerializersModule, IPGSCKotlinx_serialization_jsonJsonConfiguration, IPGSCKotlinx_serialization_jsonJsonDefault, IPGSCKotlinx_serialization_jsonJsonElement, IPGSCKotlinByteArray, IPGSCKtor_client_coreHttpRequestData, IPGSCKtor_client_coreHttpResponseData, IPGSCKotlinx_coroutines_coreCoroutineDispatcher, IPGSCKtor_client_coreProxyConfig, IPGSCKtor_utilsAttributeKey<T>, IPGSCKtor_eventsEventDefinition<T>, IPGSCKtor_utilsPipelinePhase, IPGSCKtor_utilsPipeline<TSubject, TContext>, IPGSCKtor_client_coreHttpReceivePipelinePhases, IPGSCKtor_client_coreHttpResponse, IPGSCKtor_client_coreHttpRequestPipelinePhases, IPGSCKtor_client_coreHttpRequestBuilder, IPGSCKtor_client_coreHttpResponsePipelinePhases, IPGSCKtor_client_coreHttpResponseContainer, IPGSCKtor_client_coreHttpClientCall, IPGSCKtor_client_coreHttpSendPipelinePhases, IPGSCKodein_diDIKey<__contravariant C, __contravariant A, __covariant T>, IPGSCKodein_typeTypeToken<T>, IPGSCKotlinx_serialization_jsonJsonElementCompanion, IPGSCKotlinx_serialization_coreSerialKind, IPGSCKotlinByteIterator, IPGSCKtor_httpUrl, IPGSCKtor_httpHttpMethod, IPGSCKtor_httpOutgoingContent, IPGSCKtor_httpHttpStatusCode, IPGSCKtor_utilsGMTDate, IPGSCKtor_httpHttpProtocolVersion, IPGSCKotlinAbstractCoroutineContextElement, IPGSCKotlinx_coroutines_coreCoroutineDispatcherKey, IPGSCKtor_httpHeadersBuilder, IPGSCKtor_client_coreHttpRequestBuilderCompanion, IPGSCKtor_httpURLBuilder, IPGSCKtor_utilsTypeInfo, IPGSCKtor_client_coreHttpClientCallCompanion, IPGSCKodein_diDIDefinition<C, A, T>, IPGSCKotlinTriple<__covariant A, __covariant B, __covariant C>, IPGSCKodein_diSearchSpecs, IPGSCKodein_typeTypeTokenCompanion, IPGSCKodein_diScopeRegistry, IPGSCKtor_httpUrlCompanion, IPGSCKtor_httpURLProtocol, IPGSCKtor_httpHttpMethodCompanion, IPGSCKtor_httpContentType, IPGSCKotlinCancellationException, IPGSCKtor_httpHttpStatusCodeCompanion, IPGSCKtor_utilsGMTDateCompanion, IPGSCKtor_utilsWeekDay, IPGSCKtor_utilsMonth, IPGSCKtor_httpHttpProtocolVersionCompanion, IPGSCKotlinAbstractCoroutineContextKey<B, E>, IPGSCKtor_ioMemory, IPGSCKtor_ioChunkBuffer, IPGSCKtor_ioBuffer, IPGSCKtor_ioByteReadPacket, IPGSCKtor_utilsStringValuesBuilderImpl, IPGSCKtor_httpURLBuilderCompanion, IPGSCKodein_diDIDefining<C, A, T>, IPGSCKodein_diReference<__covariant T>, IPGSCKtor_httpURLProtocolCompanion, IPGSCKtor_httpHeaderValueParam, IPGSCKtor_httpHeaderValueWithParametersCompanion, IPGSCKtor_httpHeaderValueWithParameters, IPGSCKtor_httpContentTypeCompanion, IPGSCKtor_utilsWeekDayCompanion, IPGSCKtor_utilsMonthCompanion, IPGSCKtor_ioMemoryCompanion, IPGSCKtor_ioBufferCompanion, IPGSCKtor_ioChunkBufferCompanion, IPGSCKtor_ioInputCompanion, IPGSCKtor_ioInput, IPGSCKtor_ioByteReadPacketCompanion, IPGSCKotlinKTypeProjection, IPGSCKotlinx_coroutines_coreAtomicDesc, IPGSCKotlinx_coroutines_coreLockFreeLinkedListNodePrepareOp, IPGSCKotlinKVariance, IPGSCKotlinKTypeProjectionCompanion, IPGSCKotlinx_coroutines_coreAtomicOp<__contravariant T>, IPGSCKotlinx_coroutines_coreOpDescriptor, IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode, IPGSCKotlinx_coroutines_coreLockFreeLinkedListNodeAbstractAtomicDesc, IPGSCKotlinx_coroutines_coreLockFreeLinkedListNodeAddLastDesc<T>, IPGSCKotlinx_coroutines_coreLockFreeLinkedListNodeRemoveFirstDesc<T>;

@protocol IPGSCKotlinComparable, IPGSCRuntimeSqlDriver, IPGSCIPGDatabase, IPGSCICNativeConnector, IPGSCKodein_diDI, IPGSCLogsEntityQueries, IPGSCRuntimeTransactionWithoutReturn, IPGSCRuntimeTransactionWithReturn, IPGSCRuntimeTransacter, IPGSCRuntimeSqlDriverSchema, IPGSCKotlinCoroutineContext, IPGSCBaseView, IPGSCCardDetailsView, IPGSCKotlinx_coroutines_coreCoroutineScope, IPGSCPurchaseView, IPGSCRefundView, IPGSCTransactionStatusView, IPGSCKtor_httpParameters, IPGSCAndroidParcel, IPGSCKotlinx_serialization_coreKSerializer, IPGSCKotlinIterator, IPGSCRuntimeSqlPreparedStatement, IPGSCRuntimeSqlCursor, IPGSCRuntimeCloseable, IPGSCKtor_ioCloseable, IPGSCKtor_client_coreHttpClientEngine, IPGSCKtor_client_coreHttpClientEngineCapability, IPGSCKtor_utilsAttributes, IPGSCKodein_diDIContainer, IPGSCKodein_diDIContext, IPGSCKodein_diDIAware, IPGSCRuntimeTransactionCallbacks, IPGSCRuntimeQueryListener, IPGSCKotlinCoroutineContextElement, IPGSCKotlinCoroutineContextKey, IPGSCKotlinMapEntry, IPGSCKtor_utilsStringValues, IPGSCKotlinx_serialization_coreDeserializationStrategy, IPGSCKotlinx_serialization_coreSerializationStrategy, IPGSCKotlinx_serialization_coreSerialFormat, IPGSCKotlinx_serialization_coreStringFormat, IPGSCKotlinx_serialization_coreEncoder, IPGSCKotlinx_serialization_coreSerialDescriptor, IPGSCKotlinx_serialization_coreDecoder, IPGSCKodein_diDIBuilder, IPGSCKtor_client_coreHttpClientPlugin, IPGSCKotlinx_coroutines_coreDisposableHandle, IPGSCKotlinSuspendFunction2, IPGSCKodein_diDITree, IPGSCKotlinLazy, IPGSCKotlinx_serialization_coreSerializersModuleCollector, IPGSCKotlinKClass, IPGSCKotlinx_serialization_coreCompositeEncoder, IPGSCKotlinAnnotation, IPGSCKotlinx_serialization_coreCompositeDecoder, IPGSCKodein_diDIBuilderDirectBinder, IPGSCKodein_diDIBuilderTypeBinder, IPGSCKodein_diContextTranslator, IPGSCKodein_diDIBuilderConstantBinder, IPGSCKodein_diDirectDI, IPGSCKodein_diDIContainerBuilder, IPGSCKodein_diDIBindBuilder, IPGSCKodein_diScope, IPGSCKodein_diDIBindBuilderWithScope, IPGSCKtor_httpHeaders, IPGSCKotlinx_coroutines_coreJob, IPGSCKotlinContinuation, IPGSCKotlinContinuationInterceptor, IPGSCKotlinx_coroutines_coreRunnable, IPGSCKotlinFunction, IPGSCKtor_httpHttpMessage, IPGSCKtor_ioByteReadChannel, IPGSCKtor_httpHttpMessageBuilder, IPGSCKtor_client_coreHttpRequest, IPGSCKodein_diExternalSource, IPGSCKotlinKDeclarationContainer, IPGSCKotlinKAnnotatedElement, IPGSCKotlinKClassifier, IPGSCKodein_diDIBinding, IPGSCKodein_diDirectDIAware, IPGSCKodein_diDirectDIBase, IPGSCKotlinx_coroutines_coreChildHandle, IPGSCKotlinx_coroutines_coreChildJob, IPGSCKotlinSequence, IPGSCKotlinx_coroutines_coreSelectClause0, IPGSCKtor_ioReadSession, IPGSCKotlinSuspendFunction1, IPGSCKotlinAppendable, IPGSCKtor_utilsStringValuesBuilder, IPGSCKtor_httpParametersBuilder, IPGSCKotlinKType, IPGSCKodein_diBindingDI, IPGSCKodein_diDIBindingCopier, IPGSCKodein_diBinding, IPGSCKodein_diScopeCloseable, IPGSCKotlinx_coroutines_coreParentJob, IPGSCKotlinx_coroutines_coreSelectInstance, IPGSCKotlinSuspendFunction0, IPGSCKtor_ioObjectPool, IPGSCKodein_diWithContext;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wincompatible-property-type"
#pragma clang diagnostic ignored "-Wnullability"

#pragma push_macro("_Nullable_result")
#if !__has_feature(nullability_nullable_result)
#undef _Nullable_result
#define _Nullable_result _Nullable
#endif

__attribute__((swift_name("KotlinBase")))
@interface IPGSCBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end;

@interface IPGSCBase (IPGSCBaseCopying) <NSCopying>
@end;

__attribute__((swift_name("KotlinMutableSet")))
@interface IPGSCMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end;

__attribute__((swift_name("KotlinMutableDictionary")))
@interface IPGSCMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end;

@interface NSError (NSErrorIPGSCKotlinException)
@property (readonly) id _Nullable kotlinException;
@end;

__attribute__((swift_name("KotlinNumber")))
@interface IPGSCNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end;

__attribute__((swift_name("KotlinByte")))
@interface IPGSCByte : IPGSCNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end;

__attribute__((swift_name("KotlinUByte")))
@interface IPGSCUByte : IPGSCNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end;

__attribute__((swift_name("KotlinShort")))
@interface IPGSCShort : IPGSCNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end;

__attribute__((swift_name("KotlinUShort")))
@interface IPGSCUShort : IPGSCNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end;

__attribute__((swift_name("KotlinInt")))
@interface IPGSCInt : IPGSCNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end;

__attribute__((swift_name("KotlinUInt")))
@interface IPGSCUInt : IPGSCNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end;

__attribute__((swift_name("KotlinLong")))
@interface IPGSCLong : IPGSCNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end;

__attribute__((swift_name("KotlinULong")))
@interface IPGSCULong : IPGSCNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end;

__attribute__((swift_name("KotlinFloat")))
@interface IPGSCFloat : IPGSCNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end;

__attribute__((swift_name("KotlinDouble")))
@interface IPGSCDouble : IPGSCNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end;

__attribute__((swift_name("KotlinBoolean")))
@interface IPGSCBoolean : IPGSCNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end;

__attribute__((swift_name("KotlinComparable")))
@protocol IPGSCKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end;

__attribute__((swift_name("KotlinEnum")))
@interface IPGSCKotlinEnum<E> : IPGSCBase <IPGSCKotlinComparable>
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) IPGSCKotlinEnumCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(E)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CurrencyEnum")))
@interface IPGSCCurrencyEnum : IPGSCKotlinEnum<IPGSCCurrencyEnum *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) IPGSCCurrencyEnum *eur __attribute__((swift_name("eur")));
@property (class, readonly) IPGSCCurrencyEnum *usd __attribute__((swift_name("usd")));
@property (class, readonly) IPGSCCurrencyEnum *bgn __attribute__((swift_name("bgn")));
@property (class, readonly) IPGSCCurrencyEnum *gbp __attribute__((swift_name("gbp")));
@property (class, readonly) IPGSCCurrencyEnum *hrk __attribute__((swift_name("hrk")));
@property (class, readonly) IPGSCCurrencyEnum *ron __attribute__((swift_name("ron")));
@property (class, readonly) IPGSCCurrencyEnum *chf __attribute__((swift_name("chf")));
@property (class, readonly) IPGSCCurrencyEnum *jpy __attribute__((swift_name("jpy")));
@property (class, readonly) IPGSCCurrencyEnum *pln __attribute__((swift_name("pln")));
@property (class, readonly) IPGSCCurrencyEnum *czk __attribute__((swift_name("czk")));
+ (IPGSCKotlinArray<IPGSCCurrencyEnum *> *)values __attribute__((swift_name("values()")));
@property (readonly) NSString *currency __attribute__((swift_name("currency")));
@property (readonly) BOOL isLeft __attribute__((swift_name("isLeft")));
@property (readonly) NSString *isoCode __attribute__((swift_name("isoCode")));
@property (readonly) NSString *symbol __attribute__((swift_name("symbol")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DatabaseDriverFactory")))
@interface IPGSCDatabaseDriverFactory : IPGSCBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (id<IPGSCRuntimeSqlDriver>)createDriver __attribute__((swift_name("createDriver()")));
@end;

__attribute__((swift_name("ICNativeConnector")))
@protocol IPGSCICNativeConnector
@required
- (NSString *)encryptPKCS1PaddingEncodeBase64TextForEncryption:(NSString *)textForEncryption __attribute__((swift_name("encryptPKCS1PaddingEncodeBase64(textForEncryption:)")));
- (NSString * _Nullable)generateSignaturePostParams:(NSString *)postParams __attribute__((swift_name("generateSignature(postParams:)")));
- (BOOL)verifySignatureResponse:(NSString *)response __attribute__((swift_name("verifySignature(response:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IPGProtocol")))
@interface IPGSCIPGProtocol : IPGSCBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) IPGSCIPGProtocolCompanion *companion __attribute__((swift_name("companion")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IPGProtocol.Companion")))
@interface IPGSCIPGProtocolCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCIPGProtocolCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) int32_t ANDROID __attribute__((swift_name("ANDROID")));
@property (readonly) NSString *DEBUG_HOST __attribute__((swift_name("DEBUG_HOST")));
@property (readonly) NSString *DEBUG_HOST_ONLY __attribute__((swift_name("DEBUG_HOST_ONLY")));
@property (readonly) int32_t DEFAULT_KEY_INDEX __attribute__((swift_name("DEFAULT_KEY_INDEX")));
@property (readonly) NSString *ICARD_DIGITAL_WALLET_BACKEND_URL_DEBUG __attribute__((swift_name("ICARD_DIGITAL_WALLET_BACKEND_URL_DEBUG")));
@property (readonly) NSString *ICARD_DIGITAL_WALLET_BACKEND_URL_PROD __attribute__((swift_name("ICARD_DIGITAL_WALLET_BACKEND_URL_PROD")));
@property (readonly) int32_t IOS __attribute__((swift_name("IOS")));
@property (readonly) NSString *IPG_OLD_VERSION __attribute__((swift_name("IPG_OLD_VERSION")));
@property (readonly) NSString *IPG_VERSION __attribute__((swift_name("IPG_VERSION")));
@property (readonly) NSString *METHOD_3DS __attribute__((swift_name("METHOD_3DS")));
@property (readonly) NSString *METHOD_CHECK_CARD __attribute__((swift_name("METHOD_CHECK_CARD")));
@property (readonly) NSString *METHOD_GET_MERCHANT_TAX __attribute__((swift_name("METHOD_GET_MERCHANT_TAX")));
@property (readonly) NSString *METHOD_GET_TRANSACTION_STATUS __attribute__((swift_name("METHOD_GET_TRANSACTION_STATUS")));
@property (readonly) NSString *METHOD_IPG_SAVE_SDK_LOG __attribute__((swift_name("METHOD_IPG_SAVE_SDK_LOG")));
@property (readonly) NSString *METHOD_PURCHASE __attribute__((swift_name("METHOD_PURCHASE")));
@property (readonly) NSString *METHOD_REFUND __attribute__((swift_name("METHOD_REFUND")));
@property (readonly) NSString *METHOD_STORE_CARD __attribute__((swift_name("METHOD_STORE_CARD")));
@property (readonly) NSString *METHOD_STORE_CARD_UPDATE __attribute__((swift_name("METHOD_STORE_CARD_UPDATE")));
@property (readonly) NSString *PROD_HOST __attribute__((swift_name("PROD_HOST")));
@property (readonly) NSString *PROD_HOST_ONLY __attribute__((swift_name("PROD_HOST_ONLY")));
@property (readonly) NSString *SDK_VERSION __attribute__((swift_name("SDK_VERSION")));
@property (readonly) int32_t STATUS_ERROR_DUPLICATED __attribute__((swift_name("STATUS_ERROR_DUPLICATED")));
@property (readonly) int32_t STATUS_ERROR_EXCEEDED_LIMIT __attribute__((swift_name("STATUS_ERROR_EXCEEDED_LIMIT")));
@property (readonly) int32_t STATUS_ERROR_EXEECED_ACCOUNT_LIMITS __attribute__((swift_name("STATUS_ERROR_EXEECED_ACCOUNT_LIMITS")));
@property (readonly) int32_t STATUS_ERROR_INACTIVE_ACCOUNT_IDENTIFIER __attribute__((swift_name("STATUS_ERROR_INACTIVE_ACCOUNT_IDENTIFIER")));
@property (readonly) int32_t STATUS_ERROR_INACTIVE_MANDATE_REFERENCE __attribute__((swift_name("STATUS_ERROR_INACTIVE_MANDATE_REFERENCE")));
@property (readonly) int32_t STATUS_ERROR_INVALID_ACCOUNT_IDENTIFIER __attribute__((swift_name("STATUS_ERROR_INVALID_ACCOUNT_IDENTIFIER")));
@property (readonly) int32_t STATUS_ERROR_INVALID_MANDATE_REFERENCE __attribute__((swift_name("STATUS_ERROR_INVALID_MANDATE_REFERENCE")));
@property (readonly) int32_t STATUS_ERROR_INVALID_PARAMS __attribute__((swift_name("STATUS_ERROR_INVALID_PARAMS")));
@property (readonly) int32_t STATUS_ERROR_INVALID_REFERER __attribute__((swift_name("STATUS_ERROR_INVALID_REFERER")));
@property (readonly) int32_t STATUS_ERROR_INVALID_SID __attribute__((swift_name("STATUS_ERROR_INVALID_SID")));
@property (readonly) int32_t STATUS_ERROR_IPAY __attribute__((swift_name("STATUS_ERROR_IPAY")));
@property (readonly) int32_t STATUS_ERROR_MANDATE_ALREADY_REGISTERED __attribute__((swift_name("STATUS_ERROR_MANDATE_ALREADY_REGISTERED")));
@property (readonly) int32_t STATUS_ERROR_MISSING_REQ_PARAMS __attribute__((swift_name("STATUS_ERROR_MISSING_REQ_PARAMS")));
@property (readonly) int32_t STATUS_ERROR_NOT_SUFFICIENT_FUNDS __attribute__((swift_name("STATUS_ERROR_NOT_SUFFICIENT_FUNDS")));
@property (readonly) int32_t STATUS_ERROR_SIGNATURE_FAILED __attribute__((swift_name("STATUS_ERROR_SIGNATURE_FAILED")));
@property (readonly) int32_t STATUS_ERROR_TRANSACTION_AUTH_FAIL __attribute__((swift_name("STATUS_ERROR_TRANSACTION_AUTH_FAIL")));
@property (readonly) int32_t STATUS_ERROR_TRANSACTION_NOT_PERMITTED __attribute__((swift_name("STATUS_ERROR_TRANSACTION_NOT_PERMITTED")));
@property (readonly) int32_t STATUS_ERROR_UNDEFINED_ERROR __attribute__((swift_name("STATUS_ERROR_UNDEFINED_ERROR")));
@property (readonly) int32_t STATUS_ERROR_UNSUPPORTED_CALL __attribute__((swift_name("STATUS_ERROR_UNSUPPORTED_CALL")));
@property (readonly) int32_t STATUS_ERROR_WRONG_AMOUNT __attribute__((swift_name("STATUS_ERROR_WRONG_AMOUNT")));
@property (readonly) int32_t STATUS_INTERNAL_API_ERROR __attribute__((swift_name("STATUS_INTERNAL_API_ERROR")));
@property (readonly) int32_t STATUS_INTERNAL_COMMUNICATION_ERROR __attribute__((swift_name("STATUS_INTERNAL_COMMUNICATION_ERROR")));
@property (readonly) int32_t STATUS_INTERNAL_INVALID_PARAMS __attribute__((swift_name("STATUS_INTERNAL_INVALID_PARAMS")));
@property (readonly) int32_t STATUS_INTERNAL_SDK_NOT_INITIALIZED __attribute__((swift_name("STATUS_INTERNAL_SDK_NOT_INITIALIZED")));
@property (readonly) int32_t STATUS_INTERNAL_SIGNATURE_FAILED __attribute__((swift_name("STATUS_INTERNAL_SIGNATURE_FAILED")));
@property (readonly) int32_t STATUS_INTERNAL_TIMEOUT __attribute__((swift_name("STATUS_INTERNAL_TIMEOUT")));
@property (readonly) int32_t STATUS_SUCCESS __attribute__((swift_name("STATUS_SUCCESS")));
@property (readonly) NSString *TAG_BACKEND __attribute__((swift_name("TAG_BACKEND")));
@property (readonly) NSString *TAG_FROM_MOBILE __attribute__((swift_name("TAG_FROM_MOBILE")));
@property (readonly) NSString *TAG_IPG_VERSION __attribute__((swift_name("TAG_IPG_VERSION")));
@property (readonly) NSString *TAG_KEY_INDEX __attribute__((swift_name("TAG_KEY_INDEX")));
@property (readonly) NSString *TAG_LANGUAGE __attribute__((swift_name("TAG_LANGUAGE")));
@property (readonly) NSString *TAG_METHOD __attribute__((swift_name("TAG_METHOD")));
@property (readonly) NSString *TAG_MID __attribute__((swift_name("TAG_MID")));
@property (readonly) NSString *TAG_ORIGINATOR __attribute__((swift_name("TAG_ORIGINATOR")));
@property (readonly) NSString *TAG_OUTPUT_FORMAT __attribute__((swift_name("TAG_OUTPUT_FORMAT")));
@property (readonly) NSString *TAG_SDK_VERSION __attribute__((swift_name("TAG_SDK_VERSION")));
@property (readonly) NSString *TAG_SIGNATURE __attribute__((swift_name("TAG_SIGNATURE")));
@property (readonly) NSString *TAG_STATUS __attribute__((swift_name("TAG_STATUS")));
@property (readonly) NSString *TAG_STATUS_MSG __attribute__((swift_name("TAG_STATUS_MSG")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LogHandler")))
@interface IPGSCLogHandler : IPGSCBase
- (instancetype)initWithLogType:(int32_t)logType orderId:(NSString * _Nullable)orderId request:(NSString * _Nullable)request exception:(NSString * _Nullable)exception __attribute__((swift_name("init(logType:orderId:request:exception:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) IPGSCLogHandlerCompanion *companion __attribute__((swift_name("companion")));
- (void)log __attribute__((swift_name("log()")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)sendSavedLogsWithCompletionHandler:(void (^)(IPGSCKotlinUnit * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("sendSavedLogs(completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LogHandler.Companion")))
@interface IPGSCLogHandlerCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCLogHandlerCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) int32_t LOG_TYPE_BACK_FROM_CARD_DETAILS_SCREEN __attribute__((swift_name("LOG_TYPE_BACK_FROM_CARD_DETAILS_SCREEN")));
@property (readonly) int32_t LOG_TYPE_BACK_FROM_PAYMENT_PREVIEW_SCREEN __attribute__((swift_name("LOG_TYPE_BACK_FROM_PAYMENT_PREVIEW_SCREEN")));
@property (readonly) int32_t LOG_TYPE_BACK_FROM_SECURE_3D_SCREEN __attribute__((swift_name("LOG_TYPE_BACK_FROM_SECURE_3D_SCREEN")));
@property (readonly) int32_t LOG_TYPE_EXCEPTION __attribute__((swift_name("LOG_TYPE_EXCEPTION")));
@property (readonly) int32_t LOG_TYPE_SIGNATURE_FAILED __attribute__((swift_name("LOG_TYPE_SIGNATURE_FAILED")));
@property (readonly) int32_t LOG_TYPE_TIME_OUT __attribute__((swift_name("LOG_TYPE_TIME_OUT")));
@property (readonly) int32_t LOG_TYPE_TRACE_LOG __attribute__((swift_name("LOG_TYPE_TRACE_LOG")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PlatformServiceLocator")))
@interface IPGSCPlatformServiceLocator : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)platformServiceLocator __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCPlatformServiceLocator *shared __attribute__((swift_name("shared")));
- (IPGSCKtor_client_coreHttpClient *)getHttpClientEngine __attribute__((swift_name("getHttpClientEngine()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ServiceLocator")))
@interface IPGSCServiceLocator : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)serviceLocator __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCServiceLocator *shared __attribute__((swift_name("shared")));
- (void)setupCardPresenter __attribute__((swift_name("setupCardPresenter()")));
- (void)setupGetTransactionPresenter __attribute__((swift_name("setupGetTransactionPresenter()")));
- (void)setupIcardModel __attribute__((swift_name("setupIcardModel()")));
- (void)setupKodeinContainerSqlDriver:(id<IPGSCRuntimeSqlDriver>)sqlDriver __attribute__((swift_name("setupKodeinContainer(sqlDriver:)")));
- (void)setupPurchasePresenter __attribute__((swift_name("setupPurchasePresenter()")));
- (void)setupRefundPresenter __attribute__((swift_name("setupRefundPresenter()")));
@property id<IPGSCIPGDatabase> _Nullable database __attribute__((swift_name("database")));
@property IPGSCCardPresenter * _Nullable getCardPresenter __attribute__((swift_name("getCardPresenter")));
@property IPGSCIcard * _Nullable getIcardModel __attribute__((swift_name("getIcardModel")));
@property IPGSCPurchasePresenter * _Nullable getPurchasePresenter __attribute__((swift_name("getPurchasePresenter")));
@property IPGSCRefundPresenter * _Nullable getRefundPresenter __attribute__((swift_name("getRefundPresenter")));
@property IPGSCTransactionStatusPresenter * _Nullable getTransactionStatusPresenter __attribute__((swift_name("getTransactionStatusPresenter")));
@property id<IPGSCICNativeConnector> _Nullable icNativeConnector __attribute__((swift_name("icNativeConnector")));
@property id<IPGSCKodein_diDI> _Nullable kodeinContainer __attribute__((swift_name("kodeinContainer")));
@end;

__attribute__((swift_name("RuntimeTransacter")))
@protocol IPGSCRuntimeTransacter
@required
- (void)transactionNoEnclosing:(BOOL)noEnclosing body:(void (^)(id<IPGSCRuntimeTransactionWithoutReturn>))body __attribute__((swift_name("transaction(noEnclosing:body:)")));
- (id _Nullable)transactionWithResultNoEnclosing:(BOOL)noEnclosing bodyWithReturn:(id _Nullable (^)(id<IPGSCRuntimeTransactionWithReturn>))bodyWithReturn __attribute__((swift_name("transactionWithResult(noEnclosing:bodyWithReturn:)")));
@end;

__attribute__((swift_name("IPGDatabase")))
@protocol IPGSCIPGDatabase <IPGSCRuntimeTransacter>
@required
@property (readonly) id<IPGSCLogsEntityQueries> logsEntityQueries __attribute__((swift_name("logsEntityQueries")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IPGDatabaseCompanion")))
@interface IPGSCIPGDatabaseCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCIPGDatabaseCompanion *shared __attribute__((swift_name("shared")));
- (id<IPGSCIPGDatabase>)invokeDriver:(id<IPGSCRuntimeSqlDriver>)driver __attribute__((swift_name("invoke(driver:)")));
@property (readonly) id<IPGSCRuntimeSqlDriverSchema> Schema __attribute__((swift_name("Schema")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LogsEntity")))
@interface IPGSCLogsEntity : IPGSCBase
- (instancetype)initWithOperation_id:(NSString *)operation_id log_type:(int64_t)log_type order_id:(NSString * _Nullable)order_id request_timestamp:(IPGSCLong * _Nullable)request_timestamp request:(NSString * _Nullable)request exception:(NSString * _Nullable)exception __attribute__((swift_name("init(operation_id:log_type:order_id:request_timestamp:request:exception:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (int64_t)component2 __attribute__((swift_name("component2()")));
- (NSString * _Nullable)component3 __attribute__((swift_name("component3()")));
- (IPGSCLong * _Nullable)component4 __attribute__((swift_name("component4()")));
- (NSString * _Nullable)component5 __attribute__((swift_name("component5()")));
- (NSString * _Nullable)component6 __attribute__((swift_name("component6()")));
- (IPGSCLogsEntity *)doCopyOperation_id:(NSString *)operation_id log_type:(int64_t)log_type order_id:(NSString * _Nullable)order_id request_timestamp:(IPGSCLong * _Nullable)request_timestamp request:(NSString * _Nullable)request exception:(NSString * _Nullable)exception __attribute__((swift_name("doCopy(operation_id:log_type:order_id:request_timestamp:request:exception:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable exception __attribute__((swift_name("exception")));
@property (readonly) int64_t log_type __attribute__((swift_name("log_type")));
@property (readonly) NSString *operation_id __attribute__((swift_name("operation_id")));
@property (readonly) NSString * _Nullable order_id __attribute__((swift_name("order_id")));
@property (readonly) NSString * _Nullable request __attribute__((swift_name("request")));
@property (readonly) IPGSCLong * _Nullable request_timestamp __attribute__((swift_name("request_timestamp")));
@end;

__attribute__((swift_name("LogsEntityQueries")))
@protocol IPGSCLogsEntityQueries <IPGSCRuntimeTransacter>
@required
- (void)deleteLogByOperationIdOperation_id:(NSString *)operation_id __attribute__((swift_name("deleteLogByOperationId(operation_id:)")));
- (void)insertLogOperation_id:(NSString *)operation_id log_type:(int64_t)log_type order_id:(NSString * _Nullable)order_id request_timestamp:(IPGSCLong * _Nullable)request_timestamp request:(NSString * _Nullable)request exception:(NSString * _Nullable)exception __attribute__((swift_name("insertLog(operation_id:log_type:order_id:request_timestamp:request:exception:)")));
- (IPGSCRuntimeQuery<IPGSCLogsEntity *> *)selectAllLogs __attribute__((swift_name("selectAllLogs()")));
- (IPGSCRuntimeQuery<id> *)selectAllLogsMapper:(id (^)(NSString *, IPGSCLong *, NSString * _Nullable, IPGSCLong * _Nullable, NSString * _Nullable, NSString * _Nullable))mapper __attribute__((swift_name("selectAllLogs(mapper:)")));
@end;

__attribute__((swift_name("BasePresenter")))
@interface IPGSCBasePresenter<T> : IPGSCBase
- (instancetype)initWithCoroutineContext:(id<IPGSCKotlinCoroutineContext>)coroutineContext __attribute__((swift_name("init(coroutineContext:)"))) __attribute__((objc_designated_initializer));
- (void)attachViewView:(T _Nullable)view __attribute__((swift_name("attachView(view:)")));
- (void)detachView __attribute__((swift_name("detachView()")));
- (void)onViewAttachedView:(T _Nullable)view __attribute__((swift_name("onViewAttached(view:)")));
- (void)onViewDetached __attribute__((swift_name("onViewDetached()")));
@property IPGSCPresenterCoroutineScope *scope __attribute__((swift_name("scope")));
@property T _Nullable view __attribute__((swift_name("view")));
@end;

__attribute__((swift_name("BaseView")))
@protocol IPGSCBaseView
@required
- (void)onErrorResponseModel:(IPGSCBaseResponseModel *)responseModel __attribute__((swift_name("onError(responseModel:)")));
- (void)onExceptionThrowable:(IPGSCKotlinThrowable *)throwable __attribute__((swift_name("onException(throwable:)")));
- (void)setProgressShow:(BOOL)show __attribute__((swift_name("setProgress(show:)")));
@end;

__attribute__((swift_name("CardDetailsView")))
@protocol IPGSCCardDetailsView <IPGSCBaseView>
@required
- (void)cardDetailsCheckCardModel:(IPGSCCheckCardModel *)checkCardModel __attribute__((swift_name("cardDetails(checkCardModel:)")));
- (void)cardStoredStoredCardModel:(IPGSCStoredCardModel *)storedCardModel __attribute__((swift_name("cardStored(storedCardModel:)")));
- (void)cardUpdatedStoredCardModel:(IPGSCStoredCardModel *)storedCardModel __attribute__((swift_name("cardUpdated(storedCardModel:)")));
- (void)invalidPan __attribute__((swift_name("invalidPan()")));
- (void)storeCardAndPurchaseStoredCardModel:(IPGSCStoredCardModel *)storedCardModel __attribute__((swift_name("storeCardAndPurchase(storedCardModel:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CardPresenter")))
@interface IPGSCCardPresenter : IPGSCBasePresenter<id<IPGSCCardDetailsView>>
- (instancetype)initWithStoreCardUseCase:(IPGSCStoreCardUseCase *)storeCardUseCase updateCardUseCase:(IPGSCStoredCardUpdateUseCase *)updateCardUseCase checkCardUseCase:(IPGSCCheckCardUseCase *)checkCardUseCase coroutineContext:(id<IPGSCKotlinCoroutineContext>)coroutineContext __attribute__((swift_name("init(storeCardUseCase:updateCardUseCase:checkCardUseCase:coroutineContext:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCoroutineContext:(id<IPGSCKotlinCoroutineContext>)coroutineContext __attribute__((swift_name("init(coroutineContext:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (void)checkCardCardNumber:(NSString *)cardNumber orderId:(NSString *)orderId __attribute__((swift_name("checkCard(cardNumber:orderId:)")));
- (void)logBackPressedFromCardDetailsOrderId:(NSString *)orderId __attribute__((swift_name("logBackPressedFromCardDetails(orderId:)")));
- (void)storeCardIpgStoreCardModel:(IPGSCIPGStoreCardModel *)ipgStoreCardModel __attribute__((swift_name("storeCard(ipgStoreCardModel:)")));
- (void)updateCardIpgStoredCardUpdate:(IPGSCIPGStoredCardUpdate *)ipgStoredCardUpdate __attribute__((swift_name("updateCard(ipgStoredCardUpdate:)")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineScope")))
@protocol IPGSCKotlinx_coroutines_coreCoroutineScope
@required
@property (readonly) id<IPGSCKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PresenterCoroutineScope")))
@interface IPGSCPresenterCoroutineScope : IPGSCBase <IPGSCKotlinx_coroutines_coreCoroutineScope>
- (instancetype)initWithContext:(id<IPGSCKotlinCoroutineContext>)context __attribute__((swift_name("init(context:)"))) __attribute__((objc_designated_initializer));
- (void)viewDetached __attribute__((swift_name("viewDetached()")));
@property (readonly) id<IPGSCKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PurchasePresenter")))
@interface IPGSCPurchasePresenter : IPGSCBasePresenter<id<IPGSCPurchaseView>>
- (instancetype)initWithPurchaseUseCase:(IPGSCPurchaseUseCase *)purchaseUseCase getMerchantTaxUseCase:(IPGSCGetMerchantTaxUseCase *)getMerchantTaxUseCase coroutineContext:(id<IPGSCKotlinCoroutineContext>)coroutineContext __attribute__((swift_name("init(purchaseUseCase:getMerchantTaxUseCase:coroutineContext:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCoroutineContext:(id<IPGSCKotlinCoroutineContext>)coroutineContext __attribute__((swift_name("init(coroutineContext:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (void)getMerchantTaxOrderId:(NSString * _Nullable)orderId token:(NSString * _Nullable)token pan:(NSString * _Nullable)pan __attribute__((swift_name("getMerchantTax(orderId:token:pan:)")));
- (void)logBackPressedFromPaymentPreviewOrderId:(NSString *)orderId __attribute__((swift_name("logBackPressedFromPaymentPreview(orderId:)")));
- (void)purchaseIpgPurchaseModel:(IPGSCIPGPurchaseModel *)ipgPurchaseModel __attribute__((swift_name("purchase(ipgPurchaseModel:)")));
@end;

__attribute__((swift_name("PurchaseView")))
@protocol IPGSCPurchaseView <IPGSCBaseView>
@required
- (void)taxReceivedTaxModel:(IPGSCTaxModel *)taxModel __attribute__((swift_name("taxReceived(taxModel:)")));
- (void)transactionReferenceTransactionRefModel:(IPGSCTransactionRefModel *)transactionRefModel __attribute__((swift_name("transactionReference(transactionRefModel:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RefundPresenter")))
@interface IPGSCRefundPresenter : IPGSCBasePresenter<id<IPGSCRefundView>>
- (instancetype)initWithRefundUseCase:(IPGSCRefundUseCase *)refundUseCase coroutineContext:(id<IPGSCKotlinCoroutineContext>)coroutineContext __attribute__((swift_name("init(refundUseCase:coroutineContext:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCoroutineContext:(id<IPGSCKotlinCoroutineContext>)coroutineContext __attribute__((swift_name("init(coroutineContext:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (void)onViewAttachedView:(id<IPGSCRefundView>)view __attribute__((swift_name("onViewAttached(view:)")));
- (void)refundIpgRefundModel:(IPGSCIPGRefundModel *)ipgRefundModel __attribute__((swift_name("refund(ipgRefundModel:)")));
@end;

__attribute__((swift_name("RefundView")))
@protocol IPGSCRefundView <IPGSCBaseView>
@required
- (void)transactionReferenceReceivedTransactionRefModel:(IPGSCTransactionRefModel *)transactionRefModel __attribute__((swift_name("transactionReferenceReceived(transactionRefModel:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TransactionStatusPresenter")))
@interface IPGSCTransactionStatusPresenter : IPGSCBasePresenter<id<IPGSCTransactionStatusView>>
- (instancetype)initWithGetTransactionStatusUseCase:(IPGSCGetTransactionStatusUseCase *)getTransactionStatusUseCase coroutineContext:(id<IPGSCKotlinCoroutineContext>)coroutineContext __attribute__((swift_name("init(getTransactionStatusUseCase:coroutineContext:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCoroutineContext:(id<IPGSCKotlinCoroutineContext>)coroutineContext __attribute__((swift_name("init(coroutineContext:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (void)getTransactionStatusOrderId:(NSString *)orderId __attribute__((swift_name("getTransactionStatus(orderId:)")));
@end;

__attribute__((swift_name("TransactionStatusView")))
@protocol IPGSCTransactionStatusView <IPGSCBaseView>
@required
- (void)transactionStatusTransactionStatus:(IPGSCTransactionStatusModel *)transactionStatus __attribute__((swift_name("transactionStatus(transactionStatus:)")));
@end;

__attribute__((swift_name("BaseApi")))
@interface IPGSCBaseApi<ResponseModel, RequestModel> : IPGSCBase
- (instancetype)initWithClient:(IPGSCKtor_client_coreHttpClient *)client __attribute__((swift_name("init(client:)"))) __attribute__((objc_designated_initializer));
- (id<IPGSCKtor_httpParameters>)createFormParametersRequestModel:(RequestModel)requestModel __attribute__((swift_name("createFormParameters(requestModel:)")));
- (NSString *)createUrlEncodedParametersRequestModel:(RequestModel)requestModel __attribute__((swift_name("createUrlEncodedParameters(requestModel:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)processRequestRequestModel:(RequestModel)requestModel completionHandler:(void (^)(ResponseModel _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("processRequest(requestModel:completionHandler:)")));
- (ResponseModel)processResponseBody:(NSString *)body __attribute__((swift_name("processResponse(body:)")));
@property (readonly) id<IPGSCICNativeConnector> _Nullable iCNativeConnector __attribute__((swift_name("iCNativeConnector")));
@property (readonly) IPGSCKotlinx_serialization_jsonJson *json __attribute__((swift_name("json")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CheckCardApi")))
@interface IPGSCCheckCardApi : IPGSCBaseApi<IPGSCCheckCardModel *, IPGSCIPGCheckCardModel *>
- (instancetype)initWithClient:(IPGSCKtor_client_coreHttpClient *)client __attribute__((swift_name("init(client:)"))) __attribute__((objc_designated_initializer));
- (id<IPGSCKtor_httpParameters>)createFormParametersRequestModel:(IPGSCIPGCheckCardModel *)requestModel __attribute__((swift_name("createFormParameters(requestModel:)")));
- (NSString *)createUrlEncodedParametersRequestModel:(IPGSCIPGCheckCardModel *)requestModel __attribute__((swift_name("createUrlEncodedParameters(requestModel:)")));
- (IPGSCCheckCardModel *)processResponseBody:(NSString *)body __attribute__((swift_name("processResponse(body:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LogApi")))
@interface IPGSCLogApi : IPGSCBaseApi<IPGSCLogResponseModel *, IPGSCIPGLogModel *>
- (instancetype)initWithClient:(IPGSCKtor_client_coreHttpClient *)client __attribute__((swift_name("init(client:)"))) __attribute__((objc_designated_initializer));
- (id<IPGSCKtor_httpParameters>)createFormParametersRequestModel:(IPGSCIPGLogModel *)requestModel __attribute__((swift_name("createFormParameters(requestModel:)")));
- (NSString *)createUrlEncodedParametersRequestModel:(IPGSCIPGLogModel *)requestModel __attribute__((swift_name("createUrlEncodedParameters(requestModel:)")));
- (IPGSCLogResponseModel *)processResponseBody:(NSString *)body __attribute__((swift_name("processResponse(body:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PurchaseApi")))
@interface IPGSCPurchaseApi : IPGSCBaseApi<IPGSCTransactionRefModel *, IPGSCIPGPurchaseModel *>
- (instancetype)initWithClient:(IPGSCKtor_client_coreHttpClient *)client __attribute__((swift_name("init(client:)"))) __attribute__((objc_designated_initializer));
- (id<IPGSCKtor_httpParameters>)createFormParametersRequestModel:(IPGSCIPGPurchaseModel *)requestModel __attribute__((swift_name("createFormParameters(requestModel:)")));
- (NSString *)createUrlEncodedParametersRequestModel:(IPGSCIPGPurchaseModel *)requestModel __attribute__((swift_name("createUrlEncodedParameters(requestModel:)")));
- (IPGSCTransactionRefModel *)processResponseBody:(NSString *)body __attribute__((swift_name("processResponse(body:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RefundApi")))
@interface IPGSCRefundApi : IPGSCBaseApi<IPGSCRefundTransactionModel *, IPGSCIPGRefundModel *>
- (instancetype)initWithClient:(IPGSCKtor_client_coreHttpClient *)client __attribute__((swift_name("init(client:)"))) __attribute__((objc_designated_initializer));
- (id<IPGSCKtor_httpParameters>)createFormParametersRequestModel:(IPGSCIPGRefundModel *)requestModel __attribute__((swift_name("createFormParameters(requestModel:)")));
- (NSString *)createUrlEncodedParametersRequestModel:(IPGSCIPGRefundModel *)requestModel __attribute__((swift_name("createUrlEncodedParameters(requestModel:)")));
- (IPGSCRefundTransactionModel *)processResponseBody:(NSString *)body __attribute__((swift_name("processResponse(body:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StoreCardApi")))
@interface IPGSCStoreCardApi : IPGSCBaseApi<IPGSCStoredCardModel *, IPGSCIPGStoreCardModel *>
- (instancetype)initWithClient:(IPGSCKtor_client_coreHttpClient *)client __attribute__((swift_name("init(client:)"))) __attribute__((objc_designated_initializer));
- (id<IPGSCKtor_httpParameters>)createFormParametersRequestModel:(IPGSCIPGStoreCardModel *)requestModel __attribute__((swift_name("createFormParameters(requestModel:)")));
- (NSString *)createUrlEncodedParametersRequestModel:(IPGSCIPGStoreCardModel *)requestModel __attribute__((swift_name("createUrlEncodedParameters(requestModel:)")));
- (IPGSCStoredCardModel *)processResponseBody:(NSString *)body __attribute__((swift_name("processResponse(body:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)storeCardIpgStoreCardModel:(IPGSCIPGStoreCardModel *)ipgStoreCardModel completionHandler:(void (^)(IPGSCStoredCardModel * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("storeCard(ipgStoreCardModel:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TaxApi")))
@interface IPGSCTaxApi : IPGSCBaseApi<IPGSCTaxModel *, IPGSCIPGGetMerchantTax *>
- (instancetype)initWithClient:(IPGSCKtor_client_coreHttpClient *)client __attribute__((swift_name("init(client:)"))) __attribute__((objc_designated_initializer));
- (id<IPGSCKtor_httpParameters>)createFormParametersRequestModel:(IPGSCIPGGetMerchantTax *)requestModel __attribute__((swift_name("createFormParameters(requestModel:)")));
- (NSString *)createUrlEncodedParametersRequestModel:(IPGSCIPGGetMerchantTax *)requestModel __attribute__((swift_name("createUrlEncodedParameters(requestModel:)")));
- (IPGSCTaxModel *)processResponseBody:(NSString *)body __attribute__((swift_name("processResponse(body:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TransactionStatusApi")))
@interface IPGSCTransactionStatusApi : IPGSCBaseApi<IPGSCTransactionStatusModel *, IPGSCIPGTransactionStatusModel *>
- (instancetype)initWithClient:(IPGSCKtor_client_coreHttpClient *)client __attribute__((swift_name("init(client:)"))) __attribute__((objc_designated_initializer));
- (id<IPGSCKtor_httpParameters>)createFormParametersRequestModel:(IPGSCIPGTransactionStatusModel *)requestModel __attribute__((swift_name("createFormParameters(requestModel:)")));
- (NSString *)createUrlEncodedParametersRequestModel:(IPGSCIPGTransactionStatusModel *)requestModel __attribute__((swift_name("createUrlEncodedParameters(requestModel:)")));
- (IPGSCTransactionStatusModel *)processResponseBody:(NSString *)body __attribute__((swift_name("processResponse(body:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UpdateCardApi")))
@interface IPGSCUpdateCardApi : IPGSCBaseApi<IPGSCStoredCardModel *, IPGSCIPGStoredCardUpdate *>
- (instancetype)initWithClient:(IPGSCKtor_client_coreHttpClient *)client __attribute__((swift_name("init(client:)"))) __attribute__((objc_designated_initializer));
- (id<IPGSCKtor_httpParameters>)createFormParametersRequestModel:(IPGSCIPGStoredCardUpdate *)requestModel __attribute__((swift_name("createFormParameters(requestModel:)")));
- (NSString *)createUrlEncodedParametersRequestModel:(IPGSCIPGStoredCardUpdate *)requestModel __attribute__((swift_name("createUrlEncodedParameters(requestModel:)")));
- (IPGSCStoredCardModel *)processResponseBody:(NSString *)body __attribute__((swift_name("processResponse(body:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateCardIpgStoreCardModel:(IPGSCIPGStoredCardUpdate *)ipgStoreCardModel completionHandler:(void (^)(IPGSCStoredCardModel * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("updateCard(ipgStoreCardModel:completionHandler:)")));
@end;

__attribute__((swift_name("AndroidParcel")))
@protocol IPGSCAndroidParcel
@required
@end;

__attribute__((swift_name("BaseUseCase")))
@interface IPGSCBaseUseCase<__covariant Type, __contravariant Params> : IPGSCBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeParams:(Params)params onSuccess:(void (^)(Type))onSuccess onError:(void (^)(IPGSCBaseResponseModel *))onError onFailure:(void (^)(IPGSCKotlinException *))onFailure completionHandler:(void (^)(IPGSCKotlinUnit * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(params:onSuccess:onError:onFailure:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)runParams:(Params)params completionHandler:(void (^)(IPGSCEither<IPGSCKotlinException *, Type, IPGSCBaseResponseModel *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("run(params:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BaseUseCaseNone")))
@interface IPGSCBaseUseCaseNone : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)none __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCBaseUseCaseNone *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CheckCardUseCase")))
@interface IPGSCCheckCardUseCase : IPGSCBaseUseCase<IPGSCCheckCardModel *, IPGSCIPGCheckCardModel *>
- (instancetype)initWithCheckCardApi:(IPGSCCheckCardApi *)checkCardApi __attribute__((swift_name("init(checkCardApi:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)runParams:(IPGSCIPGCheckCardModel *)params completionHandler:(void (^)(IPGSCEither<IPGSCKotlinException *, IPGSCCheckCardModel *, IPGSCBaseResponseModel *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("run(params:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetMerchantTaxUseCase")))
@interface IPGSCGetMerchantTaxUseCase : IPGSCBaseUseCase<IPGSCTaxModel *, IPGSCIPGGetMerchantTax *>
- (instancetype)initWithTaxApi:(IPGSCTaxApi *)taxApi __attribute__((swift_name("init(taxApi:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)runParams:(IPGSCIPGGetMerchantTax *)params completionHandler:(void (^)(IPGSCEither<IPGSCKotlinException *, IPGSCTaxModel *, IPGSCBaseResponseModel *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("run(params:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetTransactionStatusUseCase")))
@interface IPGSCGetTransactionStatusUseCase : IPGSCBaseUseCase<IPGSCTransactionStatusModel *, IPGSCIPGTransactionStatusModel *>
- (instancetype)initWithTransactionStatusApi:(IPGSCTransactionStatusApi *)transactionStatusApi __attribute__((swift_name("init(transactionStatusApi:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)runParams:(IPGSCIPGTransactionStatusModel *)params completionHandler:(void (^)(IPGSCEither<IPGSCKotlinException *, IPGSCTransactionStatusModel *, IPGSCBaseResponseModel *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("run(params:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LogUseCase")))
@interface IPGSCLogUseCase : IPGSCBaseUseCase<IPGSCLogResponseModel *, IPGSCIPGLogModel *>
- (instancetype)initWithLogApi:(IPGSCLogApi *)logApi __attribute__((swift_name("init(logApi:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)runParams:(IPGSCIPGLogModel *)params completionHandler:(void (^)(IPGSCEither<IPGSCKotlinException *, IPGSCLogResponseModel *, IPGSCBaseResponseModel *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("run(params:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PurchaseUseCase")))
@interface IPGSCPurchaseUseCase : IPGSCBaseUseCase<IPGSCTransactionRefModel *, IPGSCIPGPurchaseModel *>
- (instancetype)initWithPurchaseApi:(IPGSCPurchaseApi *)purchaseApi __attribute__((swift_name("init(purchaseApi:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)runParams:(IPGSCIPGPurchaseModel *)params completionHandler:(void (^)(IPGSCEither<IPGSCKotlinException *, IPGSCTransactionRefModel *, IPGSCBaseResponseModel *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("run(params:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RefundUseCase")))
@interface IPGSCRefundUseCase : IPGSCBaseUseCase<IPGSCRefundTransactionModel *, IPGSCIPGRefundModel *>
- (instancetype)initWithRefundApi:(IPGSCRefundApi *)refundApi __attribute__((swift_name("init(refundApi:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)runParams:(IPGSCIPGRefundModel *)params completionHandler:(void (^)(IPGSCEither<IPGSCKotlinException *, IPGSCRefundTransactionModel *, IPGSCRefundTransactionModel *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("run(params:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StoreCardUseCase")))
@interface IPGSCStoreCardUseCase : IPGSCBaseUseCase<IPGSCStoredCardModel *, IPGSCIPGStoreCardModel *>
- (instancetype)initWithStoreCardApi:(IPGSCStoreCardApi *)storeCardApi __attribute__((swift_name("init(storeCardApi:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)runParams:(IPGSCIPGStoreCardModel *)params completionHandler:(void (^)(IPGSCEither<IPGSCKotlinException *, IPGSCStoredCardModel *, IPGSCStoredCardModel *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("run(params:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StoredCardUpdateUseCase")))
@interface IPGSCStoredCardUpdateUseCase : IPGSCBaseUseCase<IPGSCStoredCardModel *, IPGSCIPGStoredCardUpdate *>
- (instancetype)initWithUpdateCardApi:(IPGSCUpdateCardApi *)updateCardApi __attribute__((swift_name("init(updateCardApi:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)runParams:(IPGSCIPGStoredCardUpdate *)params completionHandler:(void (^)(IPGSCEither<IPGSCKotlinException *, IPGSCStoredCardModel *, IPGSCStoredCardModel *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("run(params:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AcqSchemeEnum")))
@interface IPGSCAcqSchemeEnum : IPGSCKotlinEnum<IPGSCAcqSchemeEnum *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) IPGSCAcqSchemeEnum *mastercard __attribute__((swift_name("mastercard")));
@property (class, readonly) IPGSCAcqSchemeEnum *visa __attribute__((swift_name("visa")));
@property (class, readonly) IPGSCAcqSchemeEnum *maestro __attribute__((swift_name("maestro")));
+ (IPGSCKotlinArray<IPGSCAcqSchemeEnum *> *)values __attribute__((swift_name("values()")));
@property (readonly) NSString *acqName __attribute__((swift_name("acqName")));
@property (readonly) NSString *schemeName __attribute__((swift_name("schemeName")));
@end;

__attribute__((swift_name("BaseResponseModel")))
@interface IPGSCBaseResponseModel : IPGSCBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property NSString *signature __attribute__((swift_name("signature")));
@property int32_t status __attribute__((swift_name("status")));
@property NSString *statusMessage __attribute__((swift_name("statusMessage")));
@end;

__attribute__((swift_name("CartItemModel")))
@interface IPGSCCartItemModel : IPGSCBase <IPGSCAndroidParcel>
- (instancetype)initWithArticle:(NSString *)article quantity:(int32_t)quantity price:(double)price __attribute__((swift_name("init(article:quantity:price:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) IPGSCCartItemModelCompanion *companion __attribute__((swift_name("companion")));
@property double amount __attribute__((swift_name("amount")));
@property NSString *article __attribute__((swift_name("article")));
@property NSString *currency __attribute__((swift_name("currency")));
@property double price __attribute__((swift_name("price")));
@property int32_t quantity __attribute__((swift_name("quantity")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CartItemModel.Companion")))
@interface IPGSCCartItemModelCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCCartItemModelCompanion *shared __attribute__((swift_name("shared")));
- (id<IPGSCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("CheckCardModel")))
@interface IPGSCCheckCardModel : IPGSCBaseResponseModel
- (instancetype)initWithStatus:(int32_t)status statusMessage:(NSString *)statusMessage signature:(NSString *)signature __attribute__((swift_name("init(status:statusMessage:signature:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@property (class, readonly, getter=companion) IPGSCCheckCardModelCompanion *companion __attribute__((swift_name("companion")));
@property NSString * _Nullable acqScheme __attribute__((swift_name("acqScheme")));
@property NSString * _Nullable brand __attribute__((swift_name("brand")));
@property NSString * _Nullable issueCountry __attribute__((swift_name("issueCountry")));
@property NSString * _Nullable issueRegion __attribute__((swift_name("issueRegion")));
@property NSString * _Nullable productId __attribute__((swift_name("productId")));
@property NSString *qualifier __attribute__((swift_name("qualifier")));
@property NSString *signature __attribute__((swift_name("signature")));
@property int32_t status __attribute__((swift_name("status")));
@property NSString *statusMessage __attribute__((swift_name("statusMessage")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CheckCardModel.Companion")))
@interface IPGSCCheckCardModelCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCCheckCardModelCompanion *shared __attribute__((swift_name("shared")));
- (id<IPGSCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("Either")))
@interface IPGSCEither<__covariant F, __covariant S, __covariant E> : IPGSCBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (id _Nullable)foldFailed:(id _Nullable (^)(F _Nullable))failed succeeded:(id _Nullable (^)(S _Nullable))succeeded errorr:(id _Nullable (^)(E _Nullable))errorr __attribute__((swift_name("fold(failed:succeeded:errorr:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EitherError")))
@interface IPGSCEitherError<__covariant E> : IPGSCEither<IPGSCKotlinNothing *, IPGSCKotlinNothing *, E>
- (instancetype)initWithError:(E _Nullable)error __attribute__((swift_name("init(error:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (E _Nullable)component1 __attribute__((swift_name("component1()")));
- (IPGSCEitherError<E> *)doCopyError:(E _Nullable)error __attribute__((swift_name("doCopy(error:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) E _Nullable error __attribute__((swift_name("error")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EitherFailure")))
@interface IPGSCEitherFailure<__covariant F> : IPGSCEither<F, IPGSCKotlinNothing *, IPGSCKotlinNothing *>
- (instancetype)initWithFailure:(F _Nullable)failure __attribute__((swift_name("init(failure:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (F _Nullable)component1 __attribute__((swift_name("component1()")));
- (IPGSCEitherFailure<F> *)doCopyFailure:(F _Nullable)failure __attribute__((swift_name("doCopy(failure:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) F _Nullable failure __attribute__((swift_name("failure")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EitherSuccess")))
@interface IPGSCEitherSuccess<__covariant S> : IPGSCEither<IPGSCKotlinNothing *, S, IPGSCKotlinNothing *>
- (instancetype)initWithSuccess:(S _Nullable)success __attribute__((swift_name("init(success:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (S _Nullable)component1 __attribute__((swift_name("component1()")));
- (IPGSCEitherSuccess<S> *)doCopySuccess:(S _Nullable)success __attribute__((swift_name("doCopy(success:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) S _Nullable success __attribute__((swift_name("success")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Icard")))
@interface IPGSCIcard : IPGSCBase
- (instancetype)initWithMid:(NSString * _Nullable)mid currency:(NSString * _Nullable)currency clientPrivateKey:(NSString * _Nullable)clientPrivateKey iCardPublicKey:(NSString * _Nullable)iCardPublicKey taxUrl:(NSString *)taxUrl isSandbox:(BOOL)isSandbox originator:(NSString * _Nullable)originator backendUrl:(NSString *)backendUrl billingAddressCity:(NSString *)billingAddressCity billingAddressCountry:(NSString *)billingAddressCountry billingAddress1:(NSString *)billingAddress1 billingAddress2:(NSString *)billingAddress2 billingAddress3:(NSString *)billingAddress3 name:(NSString *)name emailAddress:(NSString *)emailAddress billingAddressPostCode:(NSString *)billingAddressPostCode customerIdentifier:(NSString *)customerIdentifier language:(NSString *)language keyIndex:(int32_t)keyIndex __attribute__((swift_name("init(mid:currency:clientPrivateKey:iCardPublicKey:taxUrl:isSandbox:originator:backendUrl:billingAddressCity:billingAddressCountry:billingAddress1:billingAddress2:billingAddress3:name:emailAddress:billingAddressPostCode:customerIdentifier:language:keyIndex:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) IPGSCIcardCompanion *companion __attribute__((swift_name("companion")));
- (NSString * _Nullable)component1 __attribute__((swift_name("component1()")));
- (NSString *)component10 __attribute__((swift_name("component10()")));
- (NSString *)component11 __attribute__((swift_name("component11()")));
- (NSString *)component12 __attribute__((swift_name("component12()")));
- (NSString *)component13 __attribute__((swift_name("component13()")));
- (NSString *)component14 __attribute__((swift_name("component14()")));
- (NSString *)component15 __attribute__((swift_name("component15()")));
- (NSString *)component16 __attribute__((swift_name("component16()")));
- (NSString *)component17 __attribute__((swift_name("component17()")));
- (NSString *)component18 __attribute__((swift_name("component18()")));
- (int32_t)component19 __attribute__((swift_name("component19()")));
- (NSString * _Nullable)component2 __attribute__((swift_name("component2()")));
- (NSString * _Nullable)component3 __attribute__((swift_name("component3()")));
- (NSString * _Nullable)component4 __attribute__((swift_name("component4()")));
- (NSString *)component5 __attribute__((swift_name("component5()")));
- (BOOL)component6 __attribute__((swift_name("component6()")));
- (NSString * _Nullable)component7 __attribute__((swift_name("component7()")));
- (NSString *)component8 __attribute__((swift_name("component8()")));
- (NSString *)component9 __attribute__((swift_name("component9()")));
- (IPGSCIcard *)doCopyMid:(NSString * _Nullable)mid currency:(NSString * _Nullable)currency clientPrivateKey:(NSString * _Nullable)clientPrivateKey iCardPublicKey:(NSString * _Nullable)iCardPublicKey taxUrl:(NSString *)taxUrl isSandbox:(BOOL)isSandbox originator:(NSString * _Nullable)originator backendUrl:(NSString *)backendUrl billingAddressCity:(NSString *)billingAddressCity billingAddressCountry:(NSString *)billingAddressCountry billingAddress1:(NSString *)billingAddress1 billingAddress2:(NSString *)billingAddress2 billingAddress3:(NSString *)billingAddress3 name:(NSString *)name emailAddress:(NSString *)emailAddress billingAddressPostCode:(NSString *)billingAddressPostCode customerIdentifier:(NSString *)customerIdentifier language:(NSString *)language keyIndex:(int32_t)keyIndex __attribute__((swift_name("doCopy(mid:currency:clientPrivateKey:iCardPublicKey:taxUrl:isSandbox:originator:backendUrl:billingAddressCity:billingAddressCountry:billingAddress1:billingAddress2:billingAddress3:name:emailAddress:billingAddressPostCode:customerIdentifier:language:keyIndex:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)isICardDigitalWallet __attribute__((swift_name("isICardDigitalWallet()")));
- (BOOL)isInitialized __attribute__((swift_name("isInitialized()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString *backendUrl __attribute__((swift_name("backendUrl")));
@property NSString *billingAddress1 __attribute__((swift_name("billingAddress1")));
@property NSString *billingAddress2 __attribute__((swift_name("billingAddress2")));
@property NSString *billingAddress3 __attribute__((swift_name("billingAddress3")));
@property NSString *billingAddressCity __attribute__((swift_name("billingAddressCity")));
@property NSString *billingAddressCountry __attribute__((swift_name("billingAddressCountry")));
@property NSString *billingAddressPostCode __attribute__((swift_name("billingAddressPostCode")));
@property NSString * _Nullable clientPrivateKey __attribute__((swift_name("clientPrivateKey")));
@property NSString * _Nullable currency __attribute__((swift_name("currency")));
@property NSString *customerIdentifier __attribute__((swift_name("customerIdentifier")));
@property NSString *emailAddress __attribute__((swift_name("emailAddress")));
@property NSString * _Nullable iCardPublicKey __attribute__((swift_name("iCardPublicKey")));
@property BOOL isSandbox __attribute__((swift_name("isSandbox")));
@property int32_t keyIndex __attribute__((swift_name("keyIndex")));
@property NSString *language __attribute__((swift_name("language")));
@property NSString * _Nullable mid __attribute__((swift_name("mid")));
@property NSString *name __attribute__((swift_name("name")));
@property NSString * _Nullable originator __attribute__((swift_name("originator")));
@property NSString *taxUrl __attribute__((swift_name("taxUrl")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Icard.Companion")))
@interface IPGSCIcardCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCIcardCompanion *shared __attribute__((swift_name("shared")));
- (id<IPGSCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LogResponseModel")))
@interface IPGSCLogResponseModel : IPGSCBaseResponseModel
- (instancetype)initWithOperationId:(NSString *)operationId status:(int32_t)status statusMessage:(NSString *)statusMessage signature:(NSString *)signature __attribute__((swift_name("init(operationId:status:statusMessage:signature:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@property (class, readonly, getter=companion) IPGSCLogResponseModelCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (int32_t)component2 __attribute__((swift_name("component2()")));
- (NSString *)component3 __attribute__((swift_name("component3()")));
- (NSString *)component4 __attribute__((swift_name("component4()")));
- (IPGSCLogResponseModel *)doCopyOperationId:(NSString *)operationId status:(int32_t)status statusMessage:(NSString *)statusMessage signature:(NSString *)signature __attribute__((swift_name("doCopy(operationId:status:statusMessage:signature:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *operationId __attribute__((swift_name("operationId")));
@property NSString *signature __attribute__((swift_name("signature")));
@property int32_t status __attribute__((swift_name("status")));
@property NSString *statusMessage __attribute__((swift_name("statusMessage")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LogResponseModel.Companion")))
@interface IPGSCLogResponseModelCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCLogResponseModelCompanion *shared __attribute__((swift_name("shared")));
- (id<IPGSCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("RefundTransactionModel")))
@interface IPGSCRefundTransactionModel : IPGSCBaseResponseModel
- (instancetype)initWithStatus:(int32_t)status statusMessage:(NSString *)statusMessage signature:(NSString *)signature __attribute__((swift_name("init(status:statusMessage:signature:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@property (class, readonly, getter=companion) IPGSCRefundTransactionModelCompanion *companion __attribute__((swift_name("companion")));
@property double amount __attribute__((swift_name("amount")));
@property NSString *currency __attribute__((swift_name("currency")));
@property NSString *method __attribute__((swift_name("method")));
@property NSString *signature __attribute__((swift_name("signature")));
@property int32_t status __attribute__((swift_name("status")));
@property NSString *statusMessage __attribute__((swift_name("statusMessage")));
@property NSString *transactionReference __attribute__((swift_name("transactionReference")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RefundTransactionModel.Companion")))
@interface IPGSCRefundTransactionModelCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCRefundTransactionModelCompanion *shared __attribute__((swift_name("shared")));
- (id<IPGSCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("StoredCardModel")))
@interface IPGSCStoredCardModel : IPGSCBaseResponseModel <IPGSCAndroidParcel>
- (instancetype)initWithStatus:(int32_t)status statusMessage:(NSString *)statusMessage signature:(NSString *)signature __attribute__((swift_name("init(status:statusMessage:signature:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@property (class, readonly, getter=companion) IPGSCStoredCardModelCompanion *companion __attribute__((swift_name("companion")));
@property NSString *approval __attribute__((swift_name("approval")));
@property NSString * _Nullable cardCustomName __attribute__((swift_name("cardCustomName")));
@property NSString * _Nullable cardExpDate __attribute__((swift_name("cardExpDate")));
@property NSString * _Nullable cardToken __attribute__((swift_name("cardToken")));
@property int32_t cardType __attribute__((swift_name("cardType")));
@property NSString * _Nullable maskedPan __attribute__((swift_name("maskedPan")));
@property NSString *signature __attribute__((swift_name("signature")));
@property int32_t status __attribute__((swift_name("status")));
@property NSString *statusMessage __attribute__((swift_name("statusMessage")));
@property NSString *transactionReference __attribute__((swift_name("transactionReference")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StoredCardModel.Companion")))
@interface IPGSCStoredCardModelCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCStoredCardModelCompanion *shared __attribute__((swift_name("shared")));
- (id<IPGSCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("TaxModel")))
@interface IPGSCTaxModel : IPGSCBaseResponseModel
- (instancetype)initWithStatus:(int32_t)status statusMessage:(NSString *)statusMessage signature:(NSString *)signature __attribute__((swift_name("init(status:statusMessage:signature:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@property (class, readonly, getter=companion) IPGSCTaxModelCompanion *companion __attribute__((swift_name("companion")));
@property NSString *maskedPan __attribute__((swift_name("maskedPan")));
@property NSString *signature __attribute__((swift_name("signature")));
@property int32_t status __attribute__((swift_name("status")));
@property NSString *statusMessage __attribute__((swift_name("statusMessage")));
@property double tax __attribute__((swift_name("tax")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TaxModel.Companion")))
@interface IPGSCTaxModelCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCTaxModelCompanion *shared __attribute__((swift_name("shared")));
- (id<IPGSCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("TransactionRefModel")))
@interface IPGSCTransactionRefModel : IPGSCBaseResponseModel
- (instancetype)initWithStatus:(int32_t)status statusMessage:(NSString *)statusMessage signature:(NSString *)signature __attribute__((swift_name("init(status:statusMessage:signature:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@property (class, readonly, getter=companion) IPGSCTransactionRefModelCompanion *companion __attribute__((swift_name("companion")));
- (void)setTransReferenceValue:(NSString *)value __attribute__((swift_name("setTransReference(value:)")));
@property double amount __attribute__((swift_name("amount")));
@property NSString *currency __attribute__((swift_name("currency")));
@property NSString *method __attribute__((swift_name("method")));
@property NSString *signature __attribute__((swift_name("signature")));
@property int32_t status __attribute__((swift_name("status")));
@property NSString *statusMessage __attribute__((swift_name("statusMessage")));
@property NSString *transactionReference __attribute__((swift_name("transactionReference")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TransactionRefModel.Companion")))
@interface IPGSCTransactionRefModelCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCTransactionRefModelCompanion *shared __attribute__((swift_name("shared")));
- (id<IPGSCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TransactionStatusModel")))
@interface IPGSCTransactionStatusModel : IPGSCBaseResponseModel
- (instancetype)initWithTranStatus:(int32_t)tranStatus transactionReference:(NSString *)transactionReference status:(int32_t)status statusMessage:(NSString *)statusMessage signature:(NSString *)signature __attribute__((swift_name("init(tranStatus:transactionReference:status:statusMessage:signature:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@property (class, readonly, getter=companion) IPGSCTransactionStatusModelCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)component1 __attribute__((swift_name("component1()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (int32_t)component3 __attribute__((swift_name("component3()")));
- (NSString *)component4 __attribute__((swift_name("component4()")));
- (NSString *)component5 __attribute__((swift_name("component5()")));
- (IPGSCTransactionStatusModel *)doCopyTranStatus:(int32_t)tranStatus transactionReference:(NSString *)transactionReference status:(int32_t)status statusMessage:(NSString *)statusMessage signature:(NSString *)signature __attribute__((swift_name("doCopy(tranStatus:transactionReference:status:statusMessage:signature:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString *signature __attribute__((swift_name("signature")));
@property int32_t status __attribute__((swift_name("status")));
@property NSString *statusMessage __attribute__((swift_name("statusMessage")));
@property int32_t tranStatus __attribute__((swift_name("tranStatus")));
@property NSString *transactionReference __attribute__((swift_name("transactionReference")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TransactionStatusModel.Companion")))
@interface IPGSCTransactionStatusModelCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCTransactionStatusModelCompanion *shared __attribute__((swift_name("shared")));
- (id<IPGSCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("BaseRequestModel")))
@interface IPGSCBaseRequestModel : IPGSCBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) IPGSCBaseRequestModelCompanion *companion __attribute__((swift_name("companion")));
@property NSString *cardholderName __attribute__((swift_name("cardholderName")));
@property NSString *method __attribute__((swift_name("method")));
@property NSString *orderId __attribute__((swift_name("orderId")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BaseRequestModel.Companion")))
@interface IPGSCBaseRequestModelCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCBaseRequestModelCompanion *shared __attribute__((swift_name("shared")));
- (id<IPGSCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
- (id<IPGSCKotlinx_serialization_coreKSerializer>)serializerTypeParamsSerializers:(IPGSCKotlinArray<id<IPGSCKotlinx_serialization_coreKSerializer>> *)typeParamsSerializers __attribute__((swift_name("serializer(typeParamsSerializers:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BaseRequestParameters")))
@interface IPGSCBaseRequestParameters : IPGSCBase
- (instancetype)initWithIpgVersion:(NSString *)ipgVersion sdkVersion:(NSString * _Nullable)sdkVersion outputFormat:(NSString *)outputFormat backEnd:(NSString *)backEnd deviceName:(int32_t)deviceName deviceOsVersion:(NSString *)deviceOsVersion deviceModel:(NSString *)deviceModel __attribute__((swift_name("init(ipgVersion:sdkVersion:outputFormat:backEnd:deviceName:deviceOsVersion:deviceModel:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) IPGSCBaseRequestParametersCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (NSString * _Nullable)component2 __attribute__((swift_name("component2()")));
- (NSString *)component3 __attribute__((swift_name("component3()")));
- (NSString *)component4 __attribute__((swift_name("component4()")));
- (int32_t)component5 __attribute__((swift_name("component5()")));
- (NSString *)component6 __attribute__((swift_name("component6()")));
- (NSString *)component7 __attribute__((swift_name("component7()")));
- (IPGSCBaseRequestParameters *)doCopyIpgVersion:(NSString *)ipgVersion sdkVersion:(NSString * _Nullable)sdkVersion outputFormat:(NSString *)outputFormat backEnd:(NSString *)backEnd deviceName:(int32_t)deviceName deviceOsVersion:(NSString *)deviceOsVersion deviceModel:(NSString *)deviceModel __attribute__((swift_name("doCopy(ipgVersion:sdkVersion:outputFormat:backEnd:deviceName:deviceOsVersion:deviceModel:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *backEnd __attribute__((swift_name("backEnd")));
@property (readonly) NSString *deviceModel __attribute__((swift_name("deviceModel")));
@property (readonly) int32_t deviceName __attribute__((swift_name("deviceName")));
@property (readonly) NSString *deviceOsVersion __attribute__((swift_name("deviceOsVersion")));
@property (readonly) NSString *ipgVersion __attribute__((swift_name("ipgVersion")));
@property (readonly) NSString *outputFormat __attribute__((swift_name("outputFormat")));
@property (readonly) NSString * _Nullable sdkVersion __attribute__((swift_name("sdkVersion")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BaseRequestParameters.Companion")))
@interface IPGSCBaseRequestParametersCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCBaseRequestParametersCompanion *shared __attribute__((swift_name("shared")));
- (id<IPGSCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("IPG3dsModel")))
@interface IPGSCIPG3dsModel : IPGSCBaseRequestModel
- (instancetype)initWithCardholderName:(NSString *)cardholderName expiryMonth:(NSString *)expiryMonth expiryYear:(NSString *)expiryYear orderId:(NSString *)orderId amount:(NSString *)amount method:(NSString *)method __attribute__((swift_name("init(cardholderName:expiryMonth:expiryYear:orderId:amount:method:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@property (class, readonly, getter=companion) IPGSCIPG3dsModelCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)toFormData __attribute__((swift_name("toFormData()")));
@property NSString *amount __attribute__((swift_name("amount")));
@property NSString *cardToken __attribute__((swift_name("cardToken")));
@property NSString *cardholderName __attribute__((swift_name("cardholderName")));
@property NSString *currency __attribute__((swift_name("currency")));
@property NSString *cvc __attribute__((swift_name("cvc")));
@property NSString *expiryMonth __attribute__((swift_name("expiryMonth")));
@property NSString *expiryYear __attribute__((swift_name("expiryYear")));
@property NSString *method __attribute__((swift_name("method")));
@property NSString *orderId __attribute__((swift_name("orderId")));
@property NSString *pan __attribute__((swift_name("pan")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IPG3dsModel.Companion")))
@interface IPGSCIPG3dsModelCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCIPG3dsModelCompanion *shared __attribute__((swift_name("shared")));
- (id<IPGSCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("IPGCheckCardModel")))
@interface IPGSCIPGCheckCardModel : IPGSCBaseRequestModel
- (instancetype)initWithMethod:(NSString *)method orderId:(NSString *)orderId cardholderName:(NSString *)cardholderName __attribute__((swift_name("init(method:orderId:cardholderName:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@property (class, readonly, getter=companion) IPGSCIPGCheckCardModelCompanion *companion __attribute__((swift_name("companion")));
@property NSString *cardholderName __attribute__((swift_name("cardholderName")));
@property NSString *method __attribute__((swift_name("method")));
@property NSString *orderId __attribute__((swift_name("orderId")));
@property NSString *pan __attribute__((swift_name("pan")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IPGCheckCardModel.Companion")))
@interface IPGSCIPGCheckCardModelCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCIPGCheckCardModelCompanion *shared __attribute__((swift_name("shared")));
- (id<IPGSCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("IPGGetMerchantTax")))
@interface IPGSCIPGGetMerchantTax : IPGSCBaseRequestModel
- (instancetype)initWithOrderId:(NSString *)orderId method:(NSString *)method cardholderName:(NSString *)cardholderName __attribute__((swift_name("init(orderId:method:cardholderName:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@property (class, readonly, getter=companion) IPGSCIPGGetMerchantTaxCompanion *companion __attribute__((swift_name("companion")));
@property NSString *cardholderName __attribute__((swift_name("cardholderName")));
@property NSString *method __attribute__((swift_name("method")));
@property NSString *orderId __attribute__((swift_name("orderId")));
@property NSString *pan __attribute__((swift_name("pan")));
@property NSString *token __attribute__((swift_name("token")));
@property (readonly) NSString *urlTax __attribute__((swift_name("urlTax")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IPGGetMerchantTax.Companion")))
@interface IPGSCIPGGetMerchantTaxCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCIPGGetMerchantTaxCompanion *shared __attribute__((swift_name("shared")));
- (id<IPGSCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IPGLogModel")))
@interface IPGSCIPGLogModel : IPGSCBaseRequestModel
- (instancetype)initWithMethod:(NSString *)method orderId:(NSString *)orderId cardholderName:(NSString *)cardholderName logType:(int32_t)logType operationId:(NSString *)operationId requestTimestamp:(int64_t)requestTimestamp request:(NSString *)request exceptionStackTrace:(NSString *)exceptionStackTrace __attribute__((swift_name("init(method:orderId:cardholderName:logType:operationId:requestTimestamp:request:exceptionStackTrace:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@property (class, readonly, getter=companion) IPGSCIPGLogModelCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (NSString *)component3 __attribute__((swift_name("component3()")));
- (int32_t)component4 __attribute__((swift_name("component4()")));
- (NSString *)component5 __attribute__((swift_name("component5()")));
- (int64_t)component6 __attribute__((swift_name("component6()")));
- (NSString *)component7 __attribute__((swift_name("component7()")));
- (NSString *)component8 __attribute__((swift_name("component8()")));
- (IPGSCIPGLogModel *)doCopyMethod:(NSString *)method orderId:(NSString *)orderId cardholderName:(NSString *)cardholderName logType:(int32_t)logType operationId:(NSString *)operationId requestTimestamp:(int64_t)requestTimestamp request:(NSString *)request exceptionStackTrace:(NSString *)exceptionStackTrace __attribute__((swift_name("doCopy(method:orderId:cardholderName:logType:operationId:requestTimestamp:request:exceptionStackTrace:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString *cardholderName __attribute__((swift_name("cardholderName")));
@property NSString *exceptionStackTrace __attribute__((swift_name("exceptionStackTrace")));
@property int32_t logType __attribute__((swift_name("logType")));
@property NSString *method __attribute__((swift_name("method")));
@property NSString *operationId __attribute__((swift_name("operationId")));
@property NSString *orderId __attribute__((swift_name("orderId")));
@property NSString *request __attribute__((swift_name("request")));
@property int64_t requestTimestamp __attribute__((swift_name("requestTimestamp")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IPGLogModel.Companion")))
@interface IPGSCIPGLogModelCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCIPGLogModelCompanion *shared __attribute__((swift_name("shared")));
- (id<IPGSCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("IPGPurchaseModel")))
@interface IPGSCIPGPurchaseModel : IPGSCBaseRequestModel <IPGSCAndroidParcel>
- (instancetype)initWithCardItems:(NSArray<IPGSCCartItemModel *> *)cardItems orderId:(NSString *)orderId expiryMonth:(NSString *)expiryMonth expiryYear:(NSString *)expiryYear eci:(NSString *)eci avv:(NSString *)avv xid:(NSString *)xid secure3dTransactionId:(NSString *)secure3dTransactionId method:(NSString *)method cardholderName:(NSString *)cardholderName __attribute__((swift_name("init(cardItems:orderId:expiryMonth:expiryYear:eci:avv:xid:secure3dTransactionId:method:cardholderName:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@property (class, readonly, getter=companion) IPGSCIPGPurchaseModelCompanion *companion __attribute__((swift_name("companion")));
@property NSString *avv __attribute__((swift_name("avv")));
@property NSArray<IPGSCCartItemModel *> *cardItems __attribute__((swift_name("cardItems")));
@property NSString * _Nullable cardToken __attribute__((swift_name("cardToken")));
@property NSString *cardholderName __attribute__((swift_name("cardholderName")));
@property NSString *currency __attribute__((swift_name("currency")));
@property NSString *cvc __attribute__((swift_name("cvc")));
@property NSString *eci __attribute__((swift_name("eci")));
@property NSString *expiryMonth __attribute__((swift_name("expiryMonth")));
@property NSString *expiryYear __attribute__((swift_name("expiryYear")));
@property NSString *method __attribute__((swift_name("method")));
@property NSString *orderId __attribute__((swift_name("orderId")));
@property NSString * _Nullable pan __attribute__((swift_name("pan")));
@property NSString *secure3dTransactionId __attribute__((swift_name("secure3dTransactionId")));
@property double totalAmount __attribute__((swift_name("totalAmount")));
@property NSString *xid __attribute__((swift_name("xid")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IPGPurchaseModel.Companion")))
@interface IPGSCIPGPurchaseModelCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCIPGPurchaseModelCompanion *shared __attribute__((swift_name("shared")));
- (id<IPGSCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("IPGRefundModel")))
@interface IPGSCIPGRefundModel : IPGSCBaseRequestModel
- (instancetype)initWithTransactionRef:(NSString *)transactionRef amount:(NSString *)amount orderId:(NSString *)orderId method:(NSString *)method cardholderName:(NSString *)cardholderName __attribute__((swift_name("init(transactionRef:amount:orderId:method:cardholderName:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@property (class, readonly, getter=companion) IPGSCIPGRefundModelCompanion *companion __attribute__((swift_name("companion")));
@property NSString *amount __attribute__((swift_name("amount")));
@property NSString *cardholderName __attribute__((swift_name("cardholderName")));
@property NSString *method __attribute__((swift_name("method")));
@property NSString *orderId __attribute__((swift_name("orderId")));
@property NSString *transactionRef __attribute__((swift_name("transactionRef")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IPGRefundModel.Companion")))
@interface IPGSCIPGRefundModelCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCIPGRefundModelCompanion *shared __attribute__((swift_name("shared")));
- (id<IPGSCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("IPGStoreCardModel")))
@interface IPGSCIPGStoreCardModel : IPGSCBaseRequestModel <IPGSCAndroidParcel>
- (instancetype)initWithCardholderName:(NSString *)cardholderName customName:(NSString *)customName expiryMonth:(NSString *)expiryMonth expiryYear:(NSString *)expiryYear eci:(NSString *)eci avv:(NSString *)avv xid:(NSString *)xid secure3dTransactionId:(NSString *)secure3dTransactionId cardVerification:(NSString *)cardVerification orderId:(NSString *)orderId amount:(NSString *)amount cardItems:(NSArray<IPGSCCartItemModel *> *)cardItems method:(NSString *)method __attribute__((swift_name("init(cardholderName:customName:expiryMonth:expiryYear:eci:avv:xid:secure3dTransactionId:cardVerification:orderId:amount:cardItems:method:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@property (class, readonly, getter=companion) IPGSCIPGStoreCardModelCompanion *companion __attribute__((swift_name("companion")));
@property NSString *amount __attribute__((swift_name("amount")));
@property NSString *avv __attribute__((swift_name("avv")));
@property NSArray<IPGSCCartItemModel *> *cardItems __attribute__((swift_name("cardItems")));
@property NSString *cardToken __attribute__((swift_name("cardToken")));
@property NSString *cardVerification __attribute__((swift_name("cardVerification")));
@property NSString *cardholderName __attribute__((swift_name("cardholderName")));
@property NSString *currency __attribute__((swift_name("currency")));
@property NSString *customName __attribute__((swift_name("customName")));
@property NSString *cvc __attribute__((swift_name("cvc")));
@property NSString *eci __attribute__((swift_name("eci")));
@property NSString *expiryMonth __attribute__((swift_name("expiryMonth")));
@property NSString *expiryYear __attribute__((swift_name("expiryYear")));
@property NSString *method __attribute__((swift_name("method")));
@property NSString *orderId __attribute__((swift_name("orderId")));
@property NSString *pan __attribute__((swift_name("pan")));
@property NSString *secure3dTransactionId __attribute__((swift_name("secure3dTransactionId")));
@property NSString *xid __attribute__((swift_name("xid")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IPGStoreCardModel.Companion")))
@interface IPGSCIPGStoreCardModelCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCIPGStoreCardModelCompanion *shared __attribute__((swift_name("shared")));
- (id<IPGSCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("IPGStoredCardUpdate")))
@interface IPGSCIPGStoredCardUpdate : IPGSCBaseRequestModel
- (instancetype)initWithNote:(NSString *)note token:(NSString *)token method:(NSString *)method cardholderName:(NSString *)cardholderName customName:(NSString *)customName eci:(NSString *)eci avv:(NSString *)avv xid:(NSString *)xid secure3dTransactionId:(NSString *)secure3dTransactionId cardVerification:(NSString *)cardVerification orderId:(NSString *)orderId amount:(NSString *)amount __attribute__((swift_name("init(note:token:method:cardholderName:customName:eci:avv:xid:secure3dTransactionId:cardVerification:orderId:amount:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@property (class, readonly, getter=companion) IPGSCIPGStoredCardUpdateCompanion *companion __attribute__((swift_name("companion")));
@property NSString *amount __attribute__((swift_name("amount")));
@property NSString *avv __attribute__((swift_name("avv")));
@property NSString *cardVerification __attribute__((swift_name("cardVerification")));
@property NSString *cardholderName __attribute__((swift_name("cardholderName")));
@property NSString *currency __attribute__((swift_name("currency")));
@property NSString *customName __attribute__((swift_name("customName")));
@property NSString *cvc __attribute__((swift_name("cvc")));
@property NSString *eci __attribute__((swift_name("eci")));
@property NSString *expDate __attribute__((swift_name("expDate")));
@property NSString *method __attribute__((swift_name("method")));
@property NSString *note __attribute__((swift_name("note")));
@property NSString *orderId __attribute__((swift_name("orderId")));
@property NSString *pan __attribute__((swift_name("pan")));
@property NSString *secure3dTransactionId __attribute__((swift_name("secure3dTransactionId")));
@property NSString *token __attribute__((swift_name("token")));
@property NSString *xid __attribute__((swift_name("xid")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IPGStoredCardUpdate.Companion")))
@interface IPGSCIPGStoredCardUpdateCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCIPGStoredCardUpdateCompanion *shared __attribute__((swift_name("shared")));
- (id<IPGSCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IPGTransactionStatusModel")))
@interface IPGSCIPGTransactionStatusModel : IPGSCBaseRequestModel
- (instancetype)initWithOrderId:(NSString *)orderId method:(NSString *)method cardholderName:(NSString *)cardholderName __attribute__((swift_name("init(orderId:method:cardholderName:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@property (class, readonly, getter=companion) IPGSCIPGTransactionStatusModelCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (NSString *)component3 __attribute__((swift_name("component3()")));
- (IPGSCIPGTransactionStatusModel *)doCopyOrderId:(NSString *)orderId method:(NSString *)method cardholderName:(NSString *)cardholderName __attribute__((swift_name("doCopy(orderId:method:cardholderName:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString *cardholderName __attribute__((swift_name("cardholderName")));
@property NSString *method __attribute__((swift_name("method")));
@property NSString *orderId __attribute__((swift_name("orderId")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IPGTransactionStatusModel.Companion")))
@interface IPGSCIPGTransactionStatusModelCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCIPGTransactionStatusModelCompanion *shared __attribute__((swift_name("shared")));
- (id<IPGSCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DatabaseDriverFactoryKt")))
@interface IPGSCDatabaseDriverFactoryKt : IPGSCBase
+ (id<IPGSCIPGDatabase>)createDatabaseDriverFactory:(IPGSCDatabaseDriverFactory *)driverFactory __attribute__((swift_name("createDatabase(driverFactory:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ModuleDIKt")))
@interface IPGSCModuleDIKt : IPGSCBase
+ (IPGSCKodein_diDIModule *)sharedModule __attribute__((swift_name("sharedModule()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BaseExtKt")))
@interface IPGSCBaseExtKt : IPGSCBase
+ (NSString *)asFormData:(id)receiver ICNativeConnector:(id<IPGSCICNativeConnector>)ICNativeConnector __attribute__((swift_name("asFormData(_:ICNativeConnector:)")));
+ (id<IPGSCKtor_httpParameters>)asParameters:(id)receiver ICNativeConnector:(id<IPGSCICNativeConnector> _Nullable)ICNativeConnector __attribute__((swift_name("asParameters(_:ICNativeConnector:)")));
+ (NSString *)asUrlEncodedParameters:(id)receiver ICNativeConnector:(id<IPGSCICNativeConnector> _Nullable)ICNativeConnector __attribute__((swift_name("asUrlEncodedParameters(_:ICNativeConnector:)")));
+ (IPGSCAcqSchemeEnum * _Nullable)checkCardNumberType:(NSString *)receiver __attribute__((swift_name("checkCardNumberType(_:)")));
+ (NSString *)encodeUrlUtf8:(NSString *)receiver __attribute__((swift_name("encodeUrlUtf8(_:)")));
+ (double)roundToDecimals:(double)receiver decimals:(int32_t)decimals __attribute__((swift_name("roundToDecimals(_:decimals:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CommonUtilsKt")))
@interface IPGSCCommonUtilsKt : IPGSCBase
+ (NSString *)urlEncodeUtf8:(NSString *)receiver __attribute__((swift_name("urlEncodeUtf8(_:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AppDispatcherKt")))
@interface IPGSCAppDispatcherKt : IPGSCBase
@property (class, readonly) id<IPGSCKotlinCoroutineContext> backgroundDispatcher __attribute__((swift_name("backgroundDispatcher")));
@property (class, readonly) id<IPGSCKotlinCoroutineContext> uiDispatcher __attribute__((swift_name("uiDispatcher")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinEnumCompanion")))
@interface IPGSCKotlinEnumCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCKotlinEnumCompanion *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface IPGSCKotlinArray<T> : IPGSCBase
+ (instancetype)arrayWithSize:(int32_t)size init:(T _Nullable (^)(IPGSCInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (T _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<IPGSCKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(T _Nullable)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end;

__attribute__((swift_name("RuntimeCloseable")))
@protocol IPGSCRuntimeCloseable
@required
- (void)close __attribute__((swift_name("close()")));
@end;

__attribute__((swift_name("RuntimeSqlDriver")))
@protocol IPGSCRuntimeSqlDriver <IPGSCRuntimeCloseable>
@required
- (IPGSCRuntimeTransacterTransaction * _Nullable)currentTransaction __attribute__((swift_name("currentTransaction()")));
- (void)executeIdentifier:(IPGSCInt * _Nullable)identifier sql:(NSString *)sql parameters:(int32_t)parameters binders:(void (^ _Nullable)(id<IPGSCRuntimeSqlPreparedStatement>))binders __attribute__((swift_name("execute(identifier:sql:parameters:binders:)")));
- (id<IPGSCRuntimeSqlCursor>)executeQueryIdentifier:(IPGSCInt * _Nullable)identifier sql:(NSString *)sql parameters:(int32_t)parameters binders:(void (^ _Nullable)(id<IPGSCRuntimeSqlPreparedStatement>))binders __attribute__((swift_name("executeQuery(identifier:sql:parameters:binders:)")));
- (IPGSCRuntimeTransacterTransaction *)doNewTransaction __attribute__((swift_name("doNewTransaction()")));
@end;

__attribute__((swift_name("KotlinThrowable")))
@interface IPGSCKotlinThrowable : IPGSCBase
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(IPGSCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(IPGSCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (IPGSCKotlinArray<NSString *> *)getStackTrace __attribute__((swift_name("getStackTrace()")));
- (void)printStackTrace __attribute__((swift_name("printStackTrace()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) IPGSCKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString * _Nullable message __attribute__((swift_name("message")));
- (NSError *)asError __attribute__((swift_name("asError()")));
@end;

__attribute__((swift_name("KotlinException")))
@interface IPGSCKotlinException : IPGSCKotlinThrowable
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(IPGSCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(IPGSCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
@end;

__attribute__((swift_name("KotlinRuntimeException")))
@interface IPGSCKotlinRuntimeException : IPGSCKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(IPGSCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(IPGSCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
@end;

__attribute__((swift_name("KotlinIllegalStateException")))
@interface IPGSCKotlinIllegalStateException : IPGSCKotlinRuntimeException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(IPGSCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(IPGSCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
@end;

__attribute__((swift_name("KotlinCancellationException")))
@interface IPGSCKotlinCancellationException : IPGSCKotlinIllegalStateException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(IPGSCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(IPGSCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinUnit")))
@interface IPGSCKotlinUnit : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unit __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCKotlinUnit *shared __attribute__((swift_name("shared")));
- (NSString *)description __attribute__((swift_name("description()")));
@end;

__attribute__((swift_name("Ktor_ioCloseable")))
@protocol IPGSCKtor_ioCloseable
@required
- (void)close __attribute__((swift_name("close()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClient")))
@interface IPGSCKtor_client_coreHttpClient : IPGSCBase <IPGSCKotlinx_coroutines_coreCoroutineScope, IPGSCKtor_ioCloseable>
- (instancetype)initWithEngine:(id<IPGSCKtor_client_coreHttpClientEngine>)engine userConfig:(IPGSCKtor_client_coreHttpClientConfig<IPGSCKtor_client_coreHttpClientEngineConfig *> *)userConfig __attribute__((swift_name("init(engine:userConfig:)"))) __attribute__((objc_designated_initializer));
- (void)close __attribute__((swift_name("close()")));
- (IPGSCKtor_client_coreHttpClient *)configBlock:(void (^)(IPGSCKtor_client_coreHttpClientConfig<id> *))block __attribute__((swift_name("config(block:)")));
- (BOOL)isSupportedCapability:(id<IPGSCKtor_client_coreHttpClientEngineCapability>)capability __attribute__((swift_name("isSupported(capability:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<IPGSCKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) id<IPGSCKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property (readonly) id<IPGSCKtor_client_coreHttpClientEngine> engine __attribute__((swift_name("engine")));
@property (readonly) IPGSCKtor_client_coreHttpClientEngineConfig *engineConfig __attribute__((swift_name("engineConfig")));
@property (readonly) IPGSCKtor_eventsEvents *monitor __attribute__((swift_name("monitor")));
@property (readonly) IPGSCKtor_client_coreHttpReceivePipeline *receivePipeline __attribute__((swift_name("receivePipeline")));
@property (readonly) IPGSCKtor_client_coreHttpRequestPipeline *requestPipeline __attribute__((swift_name("requestPipeline")));
@property (readonly) IPGSCKtor_client_coreHttpResponsePipeline *responsePipeline __attribute__((swift_name("responsePipeline")));
@property (readonly) IPGSCKtor_client_coreHttpSendPipeline *sendPipeline __attribute__((swift_name("sendPipeline")));
@end;

__attribute__((swift_name("Kodein_diDIAware")))
@protocol IPGSCKodein_diDIAware
@required
@property (readonly) id<IPGSCKodein_diDI> di __attribute__((swift_name("di")));
@property (readonly) id<IPGSCKodein_diDIContext> diContext __attribute__((swift_name("diContext")));
@property (readonly) IPGSCKodein_diDITrigger * _Nullable diTrigger __attribute__((swift_name("diTrigger")));
@end;

__attribute__((swift_name("Kodein_diDI")))
@protocol IPGSCKodein_diDI <IPGSCKodein_diDIAware>
@required
@property (readonly) id<IPGSCKodein_diDIContainer> container __attribute__((swift_name("container")));
@end;

__attribute__((swift_name("RuntimeTransactionCallbacks")))
@protocol IPGSCRuntimeTransactionCallbacks
@required
- (void)afterCommitFunction:(void (^)(void))function __attribute__((swift_name("afterCommit(function:)")));
- (void)afterRollbackFunction:(void (^)(void))function __attribute__((swift_name("afterRollback(function:)")));
@end;

__attribute__((swift_name("RuntimeTransactionWithoutReturn")))
@protocol IPGSCRuntimeTransactionWithoutReturn <IPGSCRuntimeTransactionCallbacks>
@required
- (void)rollback __attribute__((swift_name("rollback()")));
- (void)transactionBody:(void (^)(id<IPGSCRuntimeTransactionWithoutReturn>))body __attribute__((swift_name("transaction(body:)")));
@end;

__attribute__((swift_name("RuntimeTransactionWithReturn")))
@protocol IPGSCRuntimeTransactionWithReturn <IPGSCRuntimeTransactionCallbacks>
@required
- (void)rollbackReturnValue:(id _Nullable)returnValue __attribute__((swift_name("rollback(returnValue:)")));
- (id _Nullable)transactionBody_:(id _Nullable (^)(id<IPGSCRuntimeTransactionWithReturn>))body __attribute__((swift_name("transaction(body_:)")));
@end;

__attribute__((swift_name("RuntimeSqlDriverSchema")))
@protocol IPGSCRuntimeSqlDriverSchema
@required
- (void)createDriver:(id<IPGSCRuntimeSqlDriver>)driver __attribute__((swift_name("create(driver:)")));
- (void)migrateDriver:(id<IPGSCRuntimeSqlDriver>)driver oldVersion:(int32_t)oldVersion newVersion:(int32_t)newVersion __attribute__((swift_name("migrate(driver:oldVersion:newVersion:)")));
@property (readonly) int32_t version __attribute__((swift_name("version")));
@end;

__attribute__((swift_name("RuntimeQuery")))
@interface IPGSCRuntimeQuery<__covariant RowType> : IPGSCBase
- (instancetype)initWithQueries:(NSMutableArray<IPGSCRuntimeQuery<id> *> *)queries mapper:(RowType (^)(id<IPGSCRuntimeSqlCursor>))mapper __attribute__((swift_name("init(queries:mapper:)"))) __attribute__((objc_designated_initializer));
- (void)addListenerListener:(id<IPGSCRuntimeQueryListener>)listener __attribute__((swift_name("addListener(listener:)")));
- (id<IPGSCRuntimeSqlCursor>)execute __attribute__((swift_name("execute()")));
- (NSArray<RowType> *)executeAsList __attribute__((swift_name("executeAsList()")));
- (RowType)executeAsOne __attribute__((swift_name("executeAsOne()")));
- (RowType _Nullable)executeAsOneOrNull __attribute__((swift_name("executeAsOneOrNull()")));
- (void)notifyDataChanged __attribute__((swift_name("notifyDataChanged()")));
- (void)removeListenerListener:(id<IPGSCRuntimeQueryListener>)listener __attribute__((swift_name("removeListener(listener:)")));
@property (readonly) RowType (^mapper)(id<IPGSCRuntimeSqlCursor>) __attribute__((swift_name("mapper")));
@end;

__attribute__((swift_name("KotlinCoroutineContext")))
@protocol IPGSCKotlinCoroutineContext
@required
- (id _Nullable)foldInitial:(id _Nullable)initial operation:(id _Nullable (^)(id _Nullable, id<IPGSCKotlinCoroutineContextElement>))operation __attribute__((swift_name("fold(initial:operation:)")));
- (id<IPGSCKotlinCoroutineContextElement> _Nullable)getKey:(id<IPGSCKotlinCoroutineContextKey>)key __attribute__((swift_name("get(key:)")));
- (id<IPGSCKotlinCoroutineContext>)minusKeyKey:(id<IPGSCKotlinCoroutineContextKey>)key __attribute__((swift_name("minusKey(key:)")));
- (id<IPGSCKotlinCoroutineContext>)plusContext:(id<IPGSCKotlinCoroutineContext>)context __attribute__((swift_name("plus(context:)")));
@end;

__attribute__((swift_name("Ktor_utilsStringValues")))
@protocol IPGSCKtor_utilsStringValues
@required
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));
- (NSSet<id<IPGSCKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));
- (void)forEachBody:(void (^)(NSString *, NSArray<NSString *> *))body __attribute__((swift_name("forEach(body:)")));
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));
@end;

__attribute__((swift_name("Ktor_httpParameters")))
@protocol IPGSCKtor_httpParameters <IPGSCKtor_utilsStringValues>
@required
@end;

__attribute__((swift_name("Kotlinx_serialization_coreSerialFormat")))
@protocol IPGSCKotlinx_serialization_coreSerialFormat
@required
@property (readonly) IPGSCKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end;

__attribute__((swift_name("Kotlinx_serialization_coreStringFormat")))
@protocol IPGSCKotlinx_serialization_coreStringFormat <IPGSCKotlinx_serialization_coreSerialFormat>
@required
- (id _Nullable)decodeFromStringDeserializer:(id<IPGSCKotlinx_serialization_coreDeserializationStrategy>)deserializer string:(NSString *)string __attribute__((swift_name("decodeFromString(deserializer:string:)")));
- (NSString *)encodeToStringSerializer:(id<IPGSCKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeToString(serializer:value:)")));
@end;

__attribute__((swift_name("Kotlinx_serialization_jsonJson")))
@interface IPGSCKotlinx_serialization_jsonJson : IPGSCBase <IPGSCKotlinx_serialization_coreStringFormat>
- (instancetype)initWithConfiguration:(IPGSCKotlinx_serialization_jsonJsonConfiguration *)configuration serializersModule:(IPGSCKotlinx_serialization_coreSerializersModule *)serializersModule __attribute__((swift_name("init(configuration:serializersModule:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) IPGSCKotlinx_serialization_jsonJsonDefault *companion __attribute__((swift_name("companion")));
- (id _Nullable)decodeFromJsonElementDeserializer:(id<IPGSCKotlinx_serialization_coreDeserializationStrategy>)deserializer element:(IPGSCKotlinx_serialization_jsonJsonElement *)element __attribute__((swift_name("decodeFromJsonElement(deserializer:element:)")));
- (id _Nullable)decodeFromStringDeserializer:(id<IPGSCKotlinx_serialization_coreDeserializationStrategy>)deserializer string:(NSString *)string __attribute__((swift_name("decodeFromString(deserializer:string:)")));
- (IPGSCKotlinx_serialization_jsonJsonElement *)encodeToJsonElementSerializer:(id<IPGSCKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeToJsonElement(serializer:value:)")));
- (NSString *)encodeToStringSerializer:(id<IPGSCKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeToString(serializer:value:)")));
- (IPGSCKotlinx_serialization_jsonJsonElement *)parseToJsonElementString:(NSString *)string __attribute__((swift_name("parseToJsonElement(string:)")));
@property (readonly) IPGSCKotlinx_serialization_jsonJsonConfiguration *configuration __attribute__((swift_name("configuration")));
@property (readonly) IPGSCKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end;

__attribute__((swift_name("Kotlinx_serialization_coreSerializationStrategy")))
@protocol IPGSCKotlinx_serialization_coreSerializationStrategy
@required
- (void)serializeEncoder:(id<IPGSCKotlinx_serialization_coreEncoder>)encoder value:(id _Nullable)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<IPGSCKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end;

__attribute__((swift_name("Kotlinx_serialization_coreDeserializationStrategy")))
@protocol IPGSCKotlinx_serialization_coreDeserializationStrategy
@required
- (id _Nullable)deserializeDecoder:(id<IPGSCKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
@property (readonly) id<IPGSCKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end;

__attribute__((swift_name("Kotlinx_serialization_coreKSerializer")))
@protocol IPGSCKotlinx_serialization_coreKSerializer <IPGSCKotlinx_serialization_coreSerializationStrategy, IPGSCKotlinx_serialization_coreDeserializationStrategy>
@required
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinNothing")))
@interface IPGSCKotlinNothing : IPGSCBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kodein_diDIModule")))
@interface IPGSCKodein_diDIModule : IPGSCBase
- (instancetype)initWithAllowSilentOverride:(BOOL)allowSilentOverride init:(void (^)(id<IPGSCKodein_diDIBuilder>))init __attribute__((swift_name("init(allowSilentOverride:init:)"))) __attribute__((objc_designated_initializer)) __attribute__((deprecated("You should name your modules, for debug purposes.")));
- (instancetype)initWithName:(NSString *)name allowSilentOverride:(BOOL)allowSilentOverride prefix:(NSString *)prefix init:(void (^)(id<IPGSCKodein_diDIBuilder>))init __attribute__((swift_name("init(name:allowSilentOverride:prefix:init:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (BOOL)component2 __attribute__((swift_name("component2()")));
- (NSString *)component3 __attribute__((swift_name("component3()")));
- (void (^)(id<IPGSCKodein_diDIBuilder>))component4 __attribute__((swift_name("component4()")));
- (IPGSCKodein_diDIModule *)doCopyName:(NSString *)name allowSilentOverride:(BOOL)allowSilentOverride prefix:(NSString *)prefix init:(void (^)(id<IPGSCKodein_diDIBuilder>))init __attribute__((swift_name("doCopy(name:allowSilentOverride:prefix:init:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL allowSilentOverride __attribute__((swift_name("allowSilentOverride")));
@property (readonly, getter=doInit) void (^init)(id<IPGSCKodein_diDIBuilder>) __attribute__((swift_name("init")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSString *prefix __attribute__((swift_name("prefix")));
@end;

__attribute__((swift_name("KotlinIterator")))
@protocol IPGSCKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (id _Nullable)next __attribute__((swift_name("next()")));
@end;

__attribute__((swift_name("RuntimeTransacterTransaction")))
@interface IPGSCRuntimeTransacterTransaction : IPGSCBase <IPGSCRuntimeTransactionCallbacks>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)afterCommitFunction:(void (^)(void))function __attribute__((swift_name("afterCommit(function:)")));
- (void)afterRollbackFunction:(void (^)(void))function __attribute__((swift_name("afterRollback(function:)")));
- (void)endTransactionSuccessful:(BOOL)successful __attribute__((swift_name("endTransaction(successful:)")));
@property (readonly) IPGSCRuntimeTransacterTransaction * _Nullable enclosingTransaction __attribute__((swift_name("enclosingTransaction")));
@end;

__attribute__((swift_name("RuntimeSqlPreparedStatement")))
@protocol IPGSCRuntimeSqlPreparedStatement
@required
- (void)bindBytesIndex:(int32_t)index bytes:(IPGSCKotlinByteArray * _Nullable)bytes __attribute__((swift_name("bindBytes(index:bytes:)")));
- (void)bindDoubleIndex:(int32_t)index double:(IPGSCDouble * _Nullable)double_ __attribute__((swift_name("bindDouble(index:double:)")));
- (void)bindLongIndex:(int32_t)index long:(IPGSCLong * _Nullable)long_ __attribute__((swift_name("bindLong(index:long:)")));
- (void)bindStringIndex:(int32_t)index string:(NSString * _Nullable)string __attribute__((swift_name("bindString(index:string:)")));
@end;

__attribute__((swift_name("RuntimeSqlCursor")))
@protocol IPGSCRuntimeSqlCursor <IPGSCRuntimeCloseable>
@required
- (IPGSCKotlinByteArray * _Nullable)getBytesIndex:(int32_t)index __attribute__((swift_name("getBytes(index:)")));
- (IPGSCDouble * _Nullable)getDoubleIndex:(int32_t)index __attribute__((swift_name("getDouble(index:)")));
- (IPGSCLong * _Nullable)getLongIndex:(int32_t)index __attribute__((swift_name("getLong(index:)")));
- (NSString * _Nullable)getStringIndex:(int32_t)index __attribute__((swift_name("getString(index:)")));
- (BOOL)next_ __attribute__((swift_name("next_()")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpClientEngine")))
@protocol IPGSCKtor_client_coreHttpClientEngine <IPGSCKotlinx_coroutines_coreCoroutineScope, IPGSCKtor_ioCloseable>
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)executeData:(IPGSCKtor_client_coreHttpRequestData *)data completionHandler:(void (^)(IPGSCKtor_client_coreHttpResponseData * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("execute(data:completionHandler:)")));
- (void)installClient:(IPGSCKtor_client_coreHttpClient *)client __attribute__((swift_name("install(client:)")));
@property (readonly) IPGSCKtor_client_coreHttpClientEngineConfig *config __attribute__((swift_name("config")));
@property (readonly) IPGSCKotlinx_coroutines_coreCoroutineDispatcher *dispatcher __attribute__((swift_name("dispatcher")));
@property (readonly) NSSet<id<IPGSCKtor_client_coreHttpClientEngineCapability>> *supportedCapabilities __attribute__((swift_name("supportedCapabilities")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpClientEngineConfig")))
@interface IPGSCKtor_client_coreHttpClientEngineConfig : IPGSCBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property BOOL pipelining __attribute__((swift_name("pipelining")));
@property IPGSCKtor_client_coreProxyConfig * _Nullable proxy __attribute__((swift_name("proxy")));
@property int32_t threadsCount __attribute__((swift_name("threadsCount")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClientConfig")))
@interface IPGSCKtor_client_coreHttpClientConfig<T> : IPGSCBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (IPGSCKtor_client_coreHttpClientConfig<T> *)clone __attribute__((swift_name("clone()")));
- (void)engineBlock:(void (^)(T))block __attribute__((swift_name("engine(block:)")));
- (void)installClient:(IPGSCKtor_client_coreHttpClient *)client __attribute__((swift_name("install(client:)")));
- (void)installPlugin:(id<IPGSCKtor_client_coreHttpClientPlugin>)plugin configure:(void (^)(id))configure __attribute__((swift_name("install(plugin:configure:)")));
- (void)installKey:(NSString *)key block:(void (^)(IPGSCKtor_client_coreHttpClient *))block __attribute__((swift_name("install(key:block:)")));
- (void)plusAssignOther:(IPGSCKtor_client_coreHttpClientConfig<T> *)other __attribute__((swift_name("plusAssign(other:)")));
@property BOOL developmentMode __attribute__((swift_name("developmentMode")));
@property BOOL expectSuccess __attribute__((swift_name("expectSuccess")));
@property BOOL followRedirects __attribute__((swift_name("followRedirects")));
@property BOOL useDefaultTransformers __attribute__((swift_name("useDefaultTransformers")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpClientEngineCapability")))
@protocol IPGSCKtor_client_coreHttpClientEngineCapability
@required
@end;

__attribute__((swift_name("Ktor_utilsAttributes")))
@protocol IPGSCKtor_utilsAttributes
@required
- (id)computeIfAbsentKey:(IPGSCKtor_utilsAttributeKey<id> *)key block:(id (^)(void))block __attribute__((swift_name("computeIfAbsent(key:block:)")));
- (BOOL)containsKey:(IPGSCKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("contains(key:)")));
- (id)getKey_:(IPGSCKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("get(key_:)")));
- (id _Nullable)getOrNullKey:(IPGSCKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("getOrNull(key:)")));
- (void)putKey:(IPGSCKtor_utilsAttributeKey<id> *)key value:(id)value __attribute__((swift_name("put(key:value:)")));
- (void)removeKey:(IPGSCKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("remove(key:)")));
- (id)takeKey:(IPGSCKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("take(key:)")));
- (id _Nullable)takeOrNullKey:(IPGSCKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("takeOrNull(key:)")));
@property (readonly) NSArray<IPGSCKtor_utilsAttributeKey<id> *> *allKeys __attribute__((swift_name("allKeys")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_eventsEvents")))
@interface IPGSCKtor_eventsEvents : IPGSCBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)raiseDefinition:(IPGSCKtor_eventsEventDefinition<id> *)definition value:(id _Nullable)value __attribute__((swift_name("raise(definition:value:)")));
- (id<IPGSCKotlinx_coroutines_coreDisposableHandle>)subscribeDefinition:(IPGSCKtor_eventsEventDefinition<id> *)definition handler:(void (^)(id _Nullable))handler __attribute__((swift_name("subscribe(definition:handler:)")));
- (void)unsubscribeDefinition:(IPGSCKtor_eventsEventDefinition<id> *)definition handler:(void (^)(id _Nullable))handler __attribute__((swift_name("unsubscribe(definition:handler:)")));
@end;

__attribute__((swift_name("Ktor_utilsPipeline")))
@interface IPGSCKtor_utilsPipeline<TSubject, TContext> : IPGSCBase
- (instancetype)initWithPhase:(IPGSCKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<IPGSCKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhases:(IPGSCKotlinArray<IPGSCKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer));
- (void)addPhasePhase:(IPGSCKtor_utilsPipelinePhase *)phase __attribute__((swift_name("addPhase(phase:)")));
- (void)afterIntercepted __attribute__((swift_name("afterIntercepted()")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)executeContext:(TContext)context subject:(TSubject)subject completionHandler:(void (^)(TSubject _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("execute(context:subject:completionHandler:)")));
- (void)insertPhaseAfterReference:(IPGSCKtor_utilsPipelinePhase *)reference phase:(IPGSCKtor_utilsPipelinePhase *)phase __attribute__((swift_name("insertPhaseAfter(reference:phase:)")));
- (void)insertPhaseBeforeReference:(IPGSCKtor_utilsPipelinePhase *)reference phase:(IPGSCKtor_utilsPipelinePhase *)phase __attribute__((swift_name("insertPhaseBefore(reference:phase:)")));
- (void)interceptPhase:(IPGSCKtor_utilsPipelinePhase *)phase block:(id<IPGSCKotlinSuspendFunction2>)block __attribute__((swift_name("intercept(phase:block:)")));
- (NSArray<id<IPGSCKotlinSuspendFunction2>> *)interceptorsForPhasePhase:(IPGSCKtor_utilsPipelinePhase *)phase __attribute__((swift_name("interceptorsForPhase(phase:)")));
- (void)mergeFrom:(IPGSCKtor_utilsPipeline<TSubject, TContext> *)from __attribute__((swift_name("merge(from:)")));
- (void)mergePhasesFrom:(IPGSCKtor_utilsPipeline<TSubject, TContext> *)from __attribute__((swift_name("mergePhases(from:)")));
- (void)resetFromFrom:(IPGSCKtor_utilsPipeline<TSubject, TContext> *)from __attribute__((swift_name("resetFrom(from:)")));
@property (readonly) id<IPGSCKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@property (readonly, getter=isEmpty_) BOOL isEmpty __attribute__((swift_name("isEmpty")));
@property (readonly) NSArray<IPGSCKtor_utilsPipelinePhase *> *items __attribute__((swift_name("items")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpReceivePipeline")))
@interface IPGSCKtor_client_coreHttpReceivePipeline : IPGSCKtor_utilsPipeline<IPGSCKtor_client_coreHttpResponse *, IPGSCKotlinUnit *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhase:(IPGSCKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<IPGSCKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhases:(IPGSCKotlinArray<IPGSCKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) IPGSCKtor_client_coreHttpReceivePipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestPipeline")))
@interface IPGSCKtor_client_coreHttpRequestPipeline : IPGSCKtor_utilsPipeline<id, IPGSCKtor_client_coreHttpRequestBuilder *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhase:(IPGSCKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<IPGSCKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhases:(IPGSCKotlinArray<IPGSCKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) IPGSCKtor_client_coreHttpRequestPipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponsePipeline")))
@interface IPGSCKtor_client_coreHttpResponsePipeline : IPGSCKtor_utilsPipeline<IPGSCKtor_client_coreHttpResponseContainer *, IPGSCKtor_client_coreHttpClientCall *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhase:(IPGSCKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<IPGSCKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhases:(IPGSCKotlinArray<IPGSCKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) IPGSCKtor_client_coreHttpResponsePipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpSendPipeline")))
@interface IPGSCKtor_client_coreHttpSendPipeline : IPGSCKtor_utilsPipeline<id, IPGSCKtor_client_coreHttpRequestBuilder *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhase:(IPGSCKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<IPGSCKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhases:(IPGSCKotlinArray<IPGSCKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) IPGSCKtor_client_coreHttpSendPipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end;

__attribute__((swift_name("Kodein_diDIContainer")))
@protocol IPGSCKodein_diDIContainer
@required
- (NSArray<id (^)(id _Nullable)> *)allFactoriesKey:(IPGSCKodein_diDIKey<id, id, id> *)key context:(id)context overrideLevel:(int32_t)overrideLevel __attribute__((swift_name("allFactories(key:context:overrideLevel:)")));
- (NSArray<id (^)(void)> *)allProvidersKey:(IPGSCKodein_diDIKey<id, IPGSCKotlinUnit *, id> *)key context:(id)context overrideLevel:(int32_t)overrideLevel __attribute__((swift_name("allProviders(key:context:overrideLevel:)")));
- (id (^)(id _Nullable))factoryKey:(IPGSCKodein_diDIKey<id, id, id> *)key context:(id)context overrideLevel:(int32_t)overrideLevel __attribute__((swift_name("factory(key:context:overrideLevel:)")));
- (id (^ _Nullable)(id _Nullable))factoryOrNullKey:(IPGSCKodein_diDIKey<id, id, id> *)key context:(id)context overrideLevel:(int32_t)overrideLevel __attribute__((swift_name("factoryOrNull(key:context:overrideLevel:)")));
- (id (^)(void))providerKey:(IPGSCKodein_diDIKey<id, IPGSCKotlinUnit *, id> *)key context:(id)context overrideLevel:(int32_t)overrideLevel __attribute__((swift_name("provider(key:context:overrideLevel:)")));
- (id (^ _Nullable)(void))providerOrNullKey:(IPGSCKodein_diDIKey<id, IPGSCKotlinUnit *, id> *)key context:(id)context overrideLevel:(int32_t)overrideLevel __attribute__((swift_name("providerOrNull(key:context:overrideLevel:)")));
@property (readonly) id<IPGSCKodein_diDITree> tree __attribute__((swift_name("tree")));
@end;

__attribute__((swift_name("Kodein_diDIContext")))
@protocol IPGSCKodein_diDIContext
@required
@property (readonly) IPGSCKodein_typeTypeToken<id> *type __attribute__((swift_name("type")));
@property (readonly) id value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kodein_diDITrigger")))
@interface IPGSCKodein_diDITrigger : IPGSCBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)trigger __attribute__((swift_name("trigger()")));
@property (readonly) NSMutableArray<id<IPGSCKotlinLazy>> *properties __attribute__((swift_name("properties")));
@end;

__attribute__((swift_name("RuntimeQueryListener")))
@protocol IPGSCRuntimeQueryListener
@required
- (void)queryResultsChanged __attribute__((swift_name("queryResultsChanged()")));
@end;

__attribute__((swift_name("KotlinCoroutineContextElement")))
@protocol IPGSCKotlinCoroutineContextElement <IPGSCKotlinCoroutineContext>
@required
@property (readonly) id<IPGSCKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end;

__attribute__((swift_name("KotlinCoroutineContextKey")))
@protocol IPGSCKotlinCoroutineContextKey
@required
@end;

__attribute__((swift_name("KotlinMapEntry")))
@protocol IPGSCKotlinMapEntry
@required
@property (readonly) id _Nullable key __attribute__((swift_name("key")));
@property (readonly) id _Nullable value __attribute__((swift_name("value")));
@end;

__attribute__((swift_name("Kotlinx_serialization_coreSerializersModule")))
@interface IPGSCKotlinx_serialization_coreSerializersModule : IPGSCBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)dumpToCollector:(id<IPGSCKotlinx_serialization_coreSerializersModuleCollector>)collector __attribute__((swift_name("dumpTo(collector:)")));
- (id<IPGSCKotlinx_serialization_coreKSerializer> _Nullable)getContextualKClass:(id<IPGSCKotlinKClass>)kClass typeArgumentsSerializers:(NSArray<id<IPGSCKotlinx_serialization_coreKSerializer>> *)typeArgumentsSerializers __attribute__((swift_name("getContextual(kClass:typeArgumentsSerializers:)")));
- (id<IPGSCKotlinx_serialization_coreSerializationStrategy> _Nullable)getPolymorphicBaseClass:(id<IPGSCKotlinKClass>)baseClass value:(id)value __attribute__((swift_name("getPolymorphic(baseClass:value:)")));
- (id<IPGSCKotlinx_serialization_coreDeserializationStrategy> _Nullable)getPolymorphicBaseClass:(id<IPGSCKotlinKClass>)baseClass serializedClassName:(NSString * _Nullable)serializedClassName __attribute__((swift_name("getPolymorphic(baseClass:serializedClassName:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonJsonConfiguration")))
@interface IPGSCKotlinx_serialization_jsonJsonConfiguration : IPGSCBase
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL allowSpecialFloatingPointValues __attribute__((swift_name("allowSpecialFloatingPointValues")));
@property (readonly) BOOL allowStructuredMapKeys __attribute__((swift_name("allowStructuredMapKeys")));
@property (readonly) NSString *classDiscriminator __attribute__((swift_name("classDiscriminator")));
@property (readonly) BOOL coerceInputValues __attribute__((swift_name("coerceInputValues")));
@property (readonly) BOOL encodeDefaults __attribute__((swift_name("encodeDefaults")));
@property (readonly) BOOL explicitNulls __attribute__((swift_name("explicitNulls")));
@property (readonly) BOOL ignoreUnknownKeys __attribute__((swift_name("ignoreUnknownKeys")));
@property (readonly) BOOL isLenient __attribute__((swift_name("isLenient")));
@property (readonly) BOOL prettyPrint __attribute__((swift_name("prettyPrint")));
@property (readonly) NSString *prettyPrintIndent __attribute__((swift_name("prettyPrintIndent")));
@property (readonly) BOOL useAlternativeNames __attribute__((swift_name("useAlternativeNames")));
@property (readonly) BOOL useArrayPolymorphism __attribute__((swift_name("useArrayPolymorphism")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonJson.Default")))
@interface IPGSCKotlinx_serialization_jsonJsonDefault : IPGSCKotlinx_serialization_jsonJson
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithConfiguration:(IPGSCKotlinx_serialization_jsonJsonConfiguration *)configuration serializersModule:(IPGSCKotlinx_serialization_coreSerializersModule *)serializersModule __attribute__((swift_name("init(configuration:serializersModule:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)default_ __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCKotlinx_serialization_jsonJsonDefault *shared __attribute__((swift_name("shared")));
@end;

__attribute__((swift_name("Kotlinx_serialization_jsonJsonElement")))
@interface IPGSCKotlinx_serialization_jsonJsonElement : IPGSCBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) IPGSCKotlinx_serialization_jsonJsonElementCompanion *companion __attribute__((swift_name("companion")));
@end;

__attribute__((swift_name("Kotlinx_serialization_coreEncoder")))
@protocol IPGSCKotlinx_serialization_coreEncoder
@required
- (id<IPGSCKotlinx_serialization_coreCompositeEncoder>)beginCollectionDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)descriptor collectionSize:(int32_t)collectionSize __attribute__((swift_name("beginCollection(descriptor:collectionSize:)")));
- (id<IPGSCKotlinx_serialization_coreCompositeEncoder>)beginStructureDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (void)encodeBooleanValue:(BOOL)value __attribute__((swift_name("encodeBoolean(value:)")));
- (void)encodeByteValue:(int8_t)value __attribute__((swift_name("encodeByte(value:)")));
- (void)encodeCharValue:(unichar)value __attribute__((swift_name("encodeChar(value:)")));
- (void)encodeDoubleValue:(double)value __attribute__((swift_name("encodeDouble(value:)")));
- (void)encodeEnumEnumDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)enumDescriptor index:(int32_t)index __attribute__((swift_name("encodeEnum(enumDescriptor:index:)")));
- (void)encodeFloatValue:(float)value __attribute__((swift_name("encodeFloat(value:)")));
- (id<IPGSCKotlinx_serialization_coreEncoder>)encodeInlineInlineDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)inlineDescriptor __attribute__((swift_name("encodeInline(inlineDescriptor:)")));
- (void)encodeIntValue:(int32_t)value __attribute__((swift_name("encodeInt(value:)")));
- (void)encodeLongValue:(int64_t)value __attribute__((swift_name("encodeLong(value:)")));
- (void)encodeNotNullMark __attribute__((swift_name("encodeNotNullMark()")));
- (void)encodeNull __attribute__((swift_name("encodeNull()")));
- (void)encodeNullableSerializableValueSerializer:(id<IPGSCKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableValue(serializer:value:)")));
- (void)encodeSerializableValueSerializer:(id<IPGSCKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableValue(serializer:value:)")));
- (void)encodeShortValue:(int16_t)value __attribute__((swift_name("encodeShort(value:)")));
- (void)encodeStringValue:(NSString *)value __attribute__((swift_name("encodeString(value:)")));
@property (readonly) IPGSCKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end;

__attribute__((swift_name("Kotlinx_serialization_coreSerialDescriptor")))
@protocol IPGSCKotlinx_serialization_coreSerialDescriptor
@required
- (NSArray<id<IPGSCKotlinAnnotation>> *)getElementAnnotationsIndex:(int32_t)index __attribute__((swift_name("getElementAnnotations(index:)")));
- (id<IPGSCKotlinx_serialization_coreSerialDescriptor>)getElementDescriptorIndex:(int32_t)index __attribute__((swift_name("getElementDescriptor(index:)")));
- (int32_t)getElementIndexName:(NSString *)name __attribute__((swift_name("getElementIndex(name:)")));
- (NSString *)getElementNameIndex:(int32_t)index __attribute__((swift_name("getElementName(index:)")));
- (BOOL)isElementOptionalIndex:(int32_t)index __attribute__((swift_name("isElementOptional(index:)")));
@property (readonly) NSArray<id<IPGSCKotlinAnnotation>> *annotations __attribute__((swift_name("annotations")));
@property (readonly) int32_t elementsCount __attribute__((swift_name("elementsCount")));
@property (readonly) BOOL isInline __attribute__((swift_name("isInline")));
@property (readonly) BOOL isNullable __attribute__((swift_name("isNullable")));
@property (readonly) IPGSCKotlinx_serialization_coreSerialKind *kind __attribute__((swift_name("kind")));
@property (readonly) NSString *serialName __attribute__((swift_name("serialName")));
@end;

__attribute__((swift_name("Kotlinx_serialization_coreDecoder")))
@protocol IPGSCKotlinx_serialization_coreDecoder
@required
- (id<IPGSCKotlinx_serialization_coreCompositeDecoder>)beginStructureDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (BOOL)decodeBoolean __attribute__((swift_name("decodeBoolean()")));
- (int8_t)decodeByte __attribute__((swift_name("decodeByte()")));
- (unichar)decodeChar __attribute__((swift_name("decodeChar()")));
- (double)decodeDouble __attribute__((swift_name("decodeDouble()")));
- (int32_t)decodeEnumEnumDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)enumDescriptor __attribute__((swift_name("decodeEnum(enumDescriptor:)")));
- (float)decodeFloat __attribute__((swift_name("decodeFloat()")));
- (id<IPGSCKotlinx_serialization_coreDecoder>)decodeInlineInlineDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)inlineDescriptor __attribute__((swift_name("decodeInline(inlineDescriptor:)")));
- (int32_t)decodeInt __attribute__((swift_name("decodeInt()")));
- (int64_t)decodeLong __attribute__((swift_name("decodeLong()")));
- (BOOL)decodeNotNullMark __attribute__((swift_name("decodeNotNullMark()")));
- (IPGSCKotlinNothing * _Nullable)decodeNull __attribute__((swift_name("decodeNull()")));
- (id _Nullable)decodeNullableSerializableValueDeserializer:(id<IPGSCKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeNullableSerializableValue(deserializer:)")));
- (id _Nullable)decodeSerializableValueDeserializer:(id<IPGSCKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeSerializableValue(deserializer:)")));
- (int16_t)decodeShort __attribute__((swift_name("decodeShort()")));
- (NSString *)decodeString __attribute__((swift_name("decodeString()")));
@property (readonly) IPGSCKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end;

__attribute__((swift_name("Kodein_diDIBindBuilder")))
@protocol IPGSCKodein_diDIBindBuilder
@required
@property (readonly) IPGSCKodein_typeTypeToken<id> *contextType __attribute__((swift_name("contextType")));
@property (readonly) BOOL explicitContext __attribute__((swift_name("explicitContext")));
@end;

__attribute__((swift_name("Kodein_diDIBindBuilderWithScope")))
@protocol IPGSCKodein_diDIBindBuilderWithScope <IPGSCKodein_diDIBindBuilder>
@required
@property (readonly) id<IPGSCKodein_diScope> scope __attribute__((swift_name("scope")));
@end;

__attribute__((swift_name("Kodein_diDIBuilder")))
@protocol IPGSCKodein_diDIBuilder <IPGSCKodein_diDIBindBuilder, IPGSCKodein_diDIBindBuilderWithScope>
@required
- (id<IPGSCKodein_diDIBuilderDirectBinder>)BindTag:(id _Nullable)tag overrides:(IPGSCBoolean * _Nullable)overrides __attribute__((swift_name("Bind(tag:overrides:)")));
- (id<IPGSCKodein_diDIBuilderTypeBinder>)BindType:(IPGSCKodein_typeTypeToken<id> *)type tag:(id _Nullable)tag overrides:(IPGSCBoolean * _Nullable)overrides __attribute__((swift_name("Bind(type:tag:overrides:)")));
- (void)RegisterContextTranslatorTranslator:(id<IPGSCKodein_diContextTranslator>)translator __attribute__((swift_name("RegisterContextTranslator(translator:)")));
- (id<IPGSCKodein_diDIBuilderConstantBinder>)constantTag:(id)tag overrides:(IPGSCBoolean * _Nullable)overrides __attribute__((swift_name("constant(tag:overrides:)")));
- (void)importModule:(IPGSCKodein_diDIModule *)module allowOverride:(BOOL)allowOverride __attribute__((swift_name("import(module:allowOverride:)")));
- (void)importAllModules:(IPGSCKotlinArray<IPGSCKodein_diDIModule *> *)modules allowOverride:(BOOL)allowOverride __attribute__((swift_name("importAll(modules:allowOverride:)")));
- (void)importAllModules:(id)modules allowOverride_:(BOOL)allowOverride __attribute__((swift_name("importAll(modules:allowOverride_:)")));
- (void)importOnceModule:(IPGSCKodein_diDIModule *)module allowOverride:(BOOL)allowOverride __attribute__((swift_name("importOnce(module:allowOverride:)")));
- (void)onReadyCb:(void (^)(id<IPGSCKodein_diDirectDI>))cb __attribute__((swift_name("onReady(cb:)")));
@property (readonly) id<IPGSCKodein_diDIContainerBuilder> containerBuilder __attribute__((swift_name("containerBuilder")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinByteArray")))
@interface IPGSCKotlinByteArray : IPGSCBase
+ (instancetype)arrayWithSize:(int32_t)size __attribute__((swift_name("init(size:)")));
+ (instancetype)arrayWithSize:(int32_t)size init:(IPGSCByte *(^)(IPGSCInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (int8_t)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (IPGSCKotlinByteIterator *)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestData")))
@interface IPGSCKtor_client_coreHttpRequestData : IPGSCBase
- (instancetype)initWithUrl:(IPGSCKtor_httpUrl *)url method:(IPGSCKtor_httpHttpMethod *)method headers:(id<IPGSCKtor_httpHeaders>)headers body:(IPGSCKtor_httpOutgoingContent *)body executionContext:(id<IPGSCKotlinx_coroutines_coreJob>)executionContext attributes:(id<IPGSCKtor_utilsAttributes>)attributes __attribute__((swift_name("init(url:method:headers:body:executionContext:attributes:)"))) __attribute__((objc_designated_initializer));
- (id _Nullable)getCapabilityOrNullKey:(id<IPGSCKtor_client_coreHttpClientEngineCapability>)key __attribute__((swift_name("getCapabilityOrNull(key:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<IPGSCKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) IPGSCKtor_httpOutgoingContent *body __attribute__((swift_name("body")));
@property (readonly) id<IPGSCKotlinx_coroutines_coreJob> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) id<IPGSCKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@property (readonly) IPGSCKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) IPGSCKtor_httpUrl *url __attribute__((swift_name("url")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponseData")))
@interface IPGSCKtor_client_coreHttpResponseData : IPGSCBase
- (instancetype)initWithStatusCode:(IPGSCKtor_httpHttpStatusCode *)statusCode requestTime:(IPGSCKtor_utilsGMTDate *)requestTime headers:(id<IPGSCKtor_httpHeaders>)headers version:(IPGSCKtor_httpHttpProtocolVersion *)version body:(id)body callContext:(id<IPGSCKotlinCoroutineContext>)callContext __attribute__((swift_name("init(statusCode:requestTime:headers:version:body:callContext:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id body __attribute__((swift_name("body")));
@property (readonly) id<IPGSCKotlinCoroutineContext> callContext __attribute__((swift_name("callContext")));
@property (readonly) id<IPGSCKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@property (readonly) IPGSCKtor_utilsGMTDate *requestTime __attribute__((swift_name("requestTime")));
@property (readonly) IPGSCKtor_utilsGMTDate *responseTime __attribute__((swift_name("responseTime")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *statusCode __attribute__((swift_name("statusCode")));
@property (readonly) IPGSCKtor_httpHttpProtocolVersion *version __attribute__((swift_name("version")));
@end;

__attribute__((swift_name("KotlinAbstractCoroutineContextElement")))
@interface IPGSCKotlinAbstractCoroutineContextElement : IPGSCBase <IPGSCKotlinCoroutineContextElement>
- (instancetype)initWithKey:(id<IPGSCKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer));
@property (readonly) id<IPGSCKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end;

__attribute__((swift_name("KotlinContinuationInterceptor")))
@protocol IPGSCKotlinContinuationInterceptor <IPGSCKotlinCoroutineContextElement>
@required
- (id<IPGSCKotlinContinuation>)interceptContinuationContinuation:(id<IPGSCKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (void)releaseInterceptedContinuationContinuation:(id<IPGSCKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineDispatcher")))
@interface IPGSCKotlinx_coroutines_coreCoroutineDispatcher : IPGSCKotlinAbstractCoroutineContextElement <IPGSCKotlinContinuationInterceptor>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithKey:(id<IPGSCKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) IPGSCKotlinx_coroutines_coreCoroutineDispatcherKey *companion __attribute__((swift_name("companion")));
- (void)dispatchContext:(id<IPGSCKotlinCoroutineContext>)context block:(id<IPGSCKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatch(context:block:)")));
- (void)dispatchYieldContext:(id<IPGSCKotlinCoroutineContext>)context block:(id<IPGSCKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatchYield(context:block:)")));
- (id<IPGSCKotlinContinuation>)interceptContinuationContinuation:(id<IPGSCKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (BOOL)isDispatchNeededContext:(id<IPGSCKotlinCoroutineContext>)context __attribute__((swift_name("isDispatchNeeded(context:)")));
- (IPGSCKotlinx_coroutines_coreCoroutineDispatcher *)limitedParallelismParallelism:(int32_t)parallelism __attribute__((swift_name("limitedParallelism(parallelism:)")));
- (IPGSCKotlinx_coroutines_coreCoroutineDispatcher *)plusOther:(IPGSCKotlinx_coroutines_coreCoroutineDispatcher *)other __attribute__((swift_name("plus(other:)"))) __attribute__((unavailable("Operator '+' on two CoroutineDispatcher objects is meaningless. CoroutineDispatcher is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The dispatcher to the right of `+` just replaces the dispatcher to the left.")));
- (void)releaseInterceptedContinuationContinuation:(id<IPGSCKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreProxyConfig")))
@interface IPGSCKtor_client_coreProxyConfig : IPGSCBase
- (instancetype)initWithUrl:(IPGSCKtor_httpUrl *)url __attribute__((swift_name("init(url:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) IPGSCKtor_httpUrl *url __attribute__((swift_name("url")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpClientPlugin")))
@protocol IPGSCKtor_client_coreHttpClientPlugin
@required
- (void)installPlugin:(id)plugin scope:(IPGSCKtor_client_coreHttpClient *)scope __attribute__((swift_name("install(plugin:scope:)")));
- (id)prepareBlock:(void (^)(id))block __attribute__((swift_name("prepare(block:)")));
@property (readonly) IPGSCKtor_utilsAttributeKey<id> *key __attribute__((swift_name("key")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsAttributeKey")))
@interface IPGSCKtor_utilsAttributeKey<T> : IPGSCBase
- (instancetype)initWithName:(NSString *)name __attribute__((swift_name("init(name:)"))) __attribute__((objc_designated_initializer));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end;

__attribute__((swift_name("Ktor_eventsEventDefinition")))
@interface IPGSCKtor_eventsEventDefinition<T> : IPGSCBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreDisposableHandle")))
@protocol IPGSCKotlinx_coroutines_coreDisposableHandle
@required
- (void)dispose __attribute__((swift_name("dispose()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsPipelinePhase")))
@interface IPGSCKtor_utilsPipelinePhase : IPGSCBase
- (instancetype)initWithName:(NSString *)name __attribute__((swift_name("init(name:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end;

__attribute__((swift_name("KotlinFunction")))
@protocol IPGSCKotlinFunction
@required
@end;

__attribute__((swift_name("KotlinSuspendFunction2")))
@protocol IPGSCKotlinSuspendFunction2 <IPGSCKotlinFunction>
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeP1:(id _Nullable)p1 p2:(id _Nullable)p2 completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(p1:p2:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpReceivePipeline.Phases")))
@interface IPGSCKtor_client_coreHttpReceivePipelinePhases : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCKtor_client_coreHttpReceivePipelinePhases *shared __attribute__((swift_name("shared")));
@property (readonly) IPGSCKtor_utilsPipelinePhase *After __attribute__((swift_name("After")));
@property (readonly) IPGSCKtor_utilsPipelinePhase *Before __attribute__((swift_name("Before")));
@property (readonly) IPGSCKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@end;

__attribute__((swift_name("Ktor_httpHttpMessage")))
@protocol IPGSCKtor_httpHttpMessage
@required
@property (readonly) id<IPGSCKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpResponse")))
@interface IPGSCKtor_client_coreHttpResponse : IPGSCBase <IPGSCKtor_httpHttpMessage, IPGSCKotlinx_coroutines_coreCoroutineScope>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) IPGSCKtor_client_coreHttpClientCall *call __attribute__((swift_name("call")));
@property (readonly) id<IPGSCKtor_ioByteReadChannel> content __attribute__((swift_name("content")));
@property (readonly) IPGSCKtor_utilsGMTDate *requestTime __attribute__((swift_name("requestTime")));
@property (readonly) IPGSCKtor_utilsGMTDate *responseTime __attribute__((swift_name("responseTime")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *status __attribute__((swift_name("status")));
@property (readonly) IPGSCKtor_httpHttpProtocolVersion *version_ __attribute__((swift_name("version_")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestPipeline.Phases")))
@interface IPGSCKtor_client_coreHttpRequestPipelinePhases : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCKtor_client_coreHttpRequestPipelinePhases *shared __attribute__((swift_name("shared")));
@property (readonly) IPGSCKtor_utilsPipelinePhase *Before __attribute__((swift_name("Before")));
@property (readonly) IPGSCKtor_utilsPipelinePhase *Render __attribute__((swift_name("Render")));
@property (readonly) IPGSCKtor_utilsPipelinePhase *Send __attribute__((swift_name("Send")));
@property (readonly) IPGSCKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@property (readonly) IPGSCKtor_utilsPipelinePhase *Transform __attribute__((swift_name("Transform")));
@end;

__attribute__((swift_name("Ktor_httpHttpMessageBuilder")))
@protocol IPGSCKtor_httpHttpMessageBuilder
@required
@property (readonly) IPGSCKtor_httpHeadersBuilder *headers __attribute__((swift_name("headers")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestBuilder")))
@interface IPGSCKtor_client_coreHttpRequestBuilder : IPGSCBase <IPGSCKtor_httpHttpMessageBuilder>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) IPGSCKtor_client_coreHttpRequestBuilderCompanion *companion __attribute__((swift_name("companion")));
- (IPGSCKtor_client_coreHttpRequestData *)build __attribute__((swift_name("build()")));
- (id _Nullable)getCapabilityOrNullKey:(id<IPGSCKtor_client_coreHttpClientEngineCapability>)key __attribute__((swift_name("getCapabilityOrNull(key:)")));
- (void)setAttributesBlock:(void (^)(id<IPGSCKtor_utilsAttributes>))block __attribute__((swift_name("setAttributes(block:)")));
- (void)setCapabilityKey:(id<IPGSCKtor_client_coreHttpClientEngineCapability>)key capability:(id)capability __attribute__((swift_name("setCapability(key:capability:)")));
- (IPGSCKtor_client_coreHttpRequestBuilder *)takeFromBuilder:(IPGSCKtor_client_coreHttpRequestBuilder *)builder __attribute__((swift_name("takeFrom(builder:)")));
- (IPGSCKtor_client_coreHttpRequestBuilder *)takeFromWithExecutionContextBuilder:(IPGSCKtor_client_coreHttpRequestBuilder *)builder __attribute__((swift_name("takeFromWithExecutionContext(builder:)")));
- (void)urlBlock:(void (^)(IPGSCKtor_httpURLBuilder *, IPGSCKtor_httpURLBuilder *))block __attribute__((swift_name("url(block:)")));
@property (readonly) id<IPGSCKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property id body __attribute__((swift_name("body")));
@property IPGSCKtor_utilsTypeInfo * _Nullable bodyType __attribute__((swift_name("bodyType")));
@property (readonly) id<IPGSCKotlinx_coroutines_coreJob> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) IPGSCKtor_httpHeadersBuilder *headers __attribute__((swift_name("headers")));
@property IPGSCKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) IPGSCKtor_httpURLBuilder *url __attribute__((swift_name("url")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponsePipeline.Phases")))
@interface IPGSCKtor_client_coreHttpResponsePipelinePhases : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCKtor_client_coreHttpResponsePipelinePhases *shared __attribute__((swift_name("shared")));
@property (readonly) IPGSCKtor_utilsPipelinePhase *After __attribute__((swift_name("After")));
@property (readonly) IPGSCKtor_utilsPipelinePhase *Parse __attribute__((swift_name("Parse")));
@property (readonly) IPGSCKtor_utilsPipelinePhase *Receive __attribute__((swift_name("Receive")));
@property (readonly) IPGSCKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@property (readonly) IPGSCKtor_utilsPipelinePhase *Transform __attribute__((swift_name("Transform")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponseContainer")))
@interface IPGSCKtor_client_coreHttpResponseContainer : IPGSCBase
- (instancetype)initWithExpectedType:(IPGSCKtor_utilsTypeInfo *)expectedType response:(id)response __attribute__((swift_name("init(expectedType:response:)"))) __attribute__((objc_designated_initializer));
- (IPGSCKtor_utilsTypeInfo *)component1 __attribute__((swift_name("component1()")));
- (id)component2 __attribute__((swift_name("component2()")));
- (IPGSCKtor_client_coreHttpResponseContainer *)doCopyExpectedType:(IPGSCKtor_utilsTypeInfo *)expectedType response:(id)response __attribute__((swift_name("doCopy(expectedType:response:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) IPGSCKtor_utilsTypeInfo *expectedType __attribute__((swift_name("expectedType")));
@property (readonly) id response __attribute__((swift_name("response")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpClientCall")))
@interface IPGSCKtor_client_coreHttpClientCall : IPGSCBase <IPGSCKotlinx_coroutines_coreCoroutineScope>
- (instancetype)initWithClient:(IPGSCKtor_client_coreHttpClient *)client requestData:(IPGSCKtor_client_coreHttpRequestData *)requestData responseData:(IPGSCKtor_client_coreHttpResponseData *)responseData __attribute__((swift_name("init(client:requestData:responseData:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithClient:(IPGSCKtor_client_coreHttpClient *)client __attribute__((swift_name("init(client:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) IPGSCKtor_client_coreHttpClientCallCompanion *companion __attribute__((swift_name("companion")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)bodyInfo:(IPGSCKtor_utilsTypeInfo *)info completionHandler:(void (^)(id _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("body(info:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getResponseContentWithCompletionHandler:(void (^)(id<IPGSCKtor_ioByteReadChannel> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getResponseContent(completionHandler:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL allowDoubleReceive __attribute__((swift_name("allowDoubleReceive")));
@property (readonly) id<IPGSCKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) IPGSCKtor_client_coreHttpClient *client __attribute__((swift_name("client")));
@property (readonly) id<IPGSCKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property id<IPGSCKtor_client_coreHttpRequest> request __attribute__((swift_name("request")));
@property IPGSCKtor_client_coreHttpResponse *response __attribute__((swift_name("response")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpSendPipeline.Phases")))
@interface IPGSCKtor_client_coreHttpSendPipelinePhases : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCKtor_client_coreHttpSendPipelinePhases *shared __attribute__((swift_name("shared")));
@property (readonly) IPGSCKtor_utilsPipelinePhase *Before __attribute__((swift_name("Before")));
@property (readonly) IPGSCKtor_utilsPipelinePhase *Engine __attribute__((swift_name("Engine")));
@property (readonly) IPGSCKtor_utilsPipelinePhase *Monitoring __attribute__((swift_name("Monitoring")));
@property (readonly) IPGSCKtor_utilsPipelinePhase *Receive __attribute__((swift_name("Receive")));
@property (readonly) IPGSCKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kodein_diDIKey")))
@interface IPGSCKodein_diDIKey<__contravariant C, __contravariant A, __covariant T> : IPGSCBase
- (instancetype)initWithContextType:(IPGSCKodein_typeTypeToken<C> *)contextType argType:(IPGSCKodein_typeTypeToken<A> *)argType type:(IPGSCKodein_typeTypeToken<T> *)type tag:(id _Nullable)tag __attribute__((swift_name("init(contextType:argType:type:tag:)"))) __attribute__((objc_designated_initializer));
- (IPGSCKodein_typeTypeToken<C> *)component1 __attribute__((swift_name("component1()")));
- (IPGSCKodein_typeTypeToken<A> *)component2 __attribute__((swift_name("component2()")));
- (IPGSCKodein_typeTypeToken<T> *)component3 __attribute__((swift_name("component3()")));
- (id _Nullable)component4 __attribute__((swift_name("component4()")));
- (IPGSCKodein_diDIKey<C, A, T> *)doCopyContextType:(IPGSCKodein_typeTypeToken<C> *)contextType argType:(IPGSCKodein_typeTypeToken<A> *)argType type:(IPGSCKodein_typeTypeToken<T> *)type tag:(id _Nullable)tag __attribute__((swift_name("doCopy(contextType:argType:type:tag:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) IPGSCKodein_typeTypeToken<A> *argType __attribute__((swift_name("argType")));
@property (readonly) NSString *bindDescription __attribute__((swift_name("bindDescription")));
@property (readonly) NSString *bindFullDescription __attribute__((swift_name("bindFullDescription")));
@property (readonly) IPGSCKodein_typeTypeToken<C> *contextType __attribute__((swift_name("contextType")));
@property (readonly) NSString *description_ __attribute__((swift_name("description_")));
@property (readonly) NSString *fullDescription __attribute__((swift_name("fullDescription")));
@property (readonly) NSString *internalDescription __attribute__((swift_name("internalDescription")));
@property (readonly) id _Nullable tag __attribute__((swift_name("tag")));
@property (readonly) IPGSCKodein_typeTypeToken<T> *type __attribute__((swift_name("type")));
@end;

__attribute__((swift_name("Kodein_diDITree")))
@protocol IPGSCKodein_diDITree
@required
- (NSArray<IPGSCKotlinTriple<IPGSCKodein_diDIKey<id, id, id> *, IPGSCKodein_diDIDefinition<id, id, id> *, id<IPGSCKodein_diContextTranslator>> *> *)findKey:(IPGSCKodein_diDIKey<id, id, id> *)key overrideLevel:(int32_t)overrideLevel all:(BOOL)all __attribute__((swift_name("find(key:overrideLevel:all:)")));
- (NSArray<IPGSCKotlinTriple<IPGSCKodein_diDIKey<id, id, id> *, NSArray<IPGSCKodein_diDIDefinition<id, id, id> *> *, id<IPGSCKodein_diContextTranslator>> *> *)findSearch:(IPGSCKodein_diSearchSpecs *)search __attribute__((swift_name("find(search:)")));
- (IPGSCKotlinTriple<IPGSCKodein_diDIKey<id, id, id> *, NSArray<IPGSCKodein_diDIDefinition<id, id, id> *> *, id<IPGSCKodein_diContextTranslator>> * _Nullable)getKey__:(IPGSCKodein_diDIKey<id, id, id> *)key __attribute__((swift_name("get(key__:)")));
@property (readonly) NSDictionary<IPGSCKodein_diDIKey<id, id, id> *, NSArray<IPGSCKodein_diDIDefinition<id, id, id> *> *> *bindings __attribute__((swift_name("bindings")));
@property (readonly) NSArray<id<IPGSCKodein_diExternalSource>> *externalSources __attribute__((swift_name("externalSources")));
@property (readonly) NSArray<id<IPGSCKodein_diContextTranslator>> *registeredTranslators __attribute__((swift_name("registeredTranslators")));
@end;

__attribute__((swift_name("Kodein_typeTypeToken")))
@interface IPGSCKodein_typeTypeToken<T> : IPGSCBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) IPGSCKodein_typeTypeTokenCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (IPGSCKotlinArray<IPGSCKodein_typeTypeToken<id> *> *)getGenericParameters __attribute__((swift_name("getGenericParameters()")));
- (IPGSCKodein_typeTypeToken<T> *)getRaw __attribute__((swift_name("getRaw()")));
- (NSArray<IPGSCKodein_typeTypeToken<id> *> *)getSuper __attribute__((swift_name("getSuper()")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)isAssignableFromTypeToken:(IPGSCKodein_typeTypeToken<id> *)typeToken __attribute__((swift_name("isAssignableFrom(typeToken:)")));
- (BOOL)isGeneric __attribute__((swift_name("isGeneric()")));
- (BOOL)isWildcard __attribute__((swift_name("isWildcard()")));
- (NSString *)qualifiedDispString __attribute__((swift_name("qualifiedDispString()")));
- (NSString *)qualifiedErasedDispString __attribute__((swift_name("qualifiedErasedDispString()")));
- (NSString *)simpleDispString __attribute__((swift_name("simpleDispString()")));
- (NSString *)simpleErasedDispString __attribute__((swift_name("simpleErasedDispString()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end;

__attribute__((swift_name("KotlinLazy")))
@protocol IPGSCKotlinLazy
@required
- (BOOL)isInitialized __attribute__((swift_name("isInitialized()")));
@property (readonly) id _Nullable value __attribute__((swift_name("value")));
@end;

__attribute__((swift_name("Kotlinx_serialization_coreSerializersModuleCollector")))
@protocol IPGSCKotlinx_serialization_coreSerializersModuleCollector
@required
- (void)contextualKClass:(id<IPGSCKotlinKClass>)kClass provider:(id<IPGSCKotlinx_serialization_coreKSerializer> (^)(NSArray<id<IPGSCKotlinx_serialization_coreKSerializer>> *))provider __attribute__((swift_name("contextual(kClass:provider:)")));
- (void)contextualKClass:(id<IPGSCKotlinKClass>)kClass serializer:(id<IPGSCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("contextual(kClass:serializer:)")));
- (void)polymorphicBaseClass:(id<IPGSCKotlinKClass>)baseClass actualClass:(id<IPGSCKotlinKClass>)actualClass actualSerializer:(id<IPGSCKotlinx_serialization_coreKSerializer>)actualSerializer __attribute__((swift_name("polymorphic(baseClass:actualClass:actualSerializer:)")));
- (void)polymorphicDefaultBaseClass:(id<IPGSCKotlinKClass>)baseClass defaultDeserializerProvider:(id<IPGSCKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefault(baseClass:defaultDeserializerProvider:)")));
- (void)polymorphicDefaultDeserializerBaseClass:(id<IPGSCKotlinKClass>)baseClass defaultDeserializerProvider:(id<IPGSCKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefaultDeserializer(baseClass:defaultDeserializerProvider:)")));
- (void)polymorphicDefaultSerializerBaseClass:(id<IPGSCKotlinKClass>)baseClass defaultSerializerProvider:(id<IPGSCKotlinx_serialization_coreSerializationStrategy> _Nullable (^)(id))defaultSerializerProvider __attribute__((swift_name("polymorphicDefaultSerializer(baseClass:defaultSerializerProvider:)")));
@end;

__attribute__((swift_name("KotlinKDeclarationContainer")))
@protocol IPGSCKotlinKDeclarationContainer
@required
@end;

__attribute__((swift_name("KotlinKAnnotatedElement")))
@protocol IPGSCKotlinKAnnotatedElement
@required
@end;

__attribute__((swift_name("KotlinKClassifier")))
@protocol IPGSCKotlinKClassifier
@required
@end;

__attribute__((swift_name("KotlinKClass")))
@protocol IPGSCKotlinKClass <IPGSCKotlinKDeclarationContainer, IPGSCKotlinKAnnotatedElement, IPGSCKotlinKClassifier>
@required
- (BOOL)isInstanceValue:(id _Nullable)value __attribute__((swift_name("isInstance(value:)")));
@property (readonly) NSString * _Nullable qualifiedName __attribute__((swift_name("qualifiedName")));
@property (readonly) NSString * _Nullable simpleName __attribute__((swift_name("simpleName")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonJsonElement.Companion")))
@interface IPGSCKotlinx_serialization_jsonJsonElementCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCKotlinx_serialization_jsonJsonElementCompanion *shared __attribute__((swift_name("shared")));
- (id<IPGSCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("Kotlinx_serialization_coreCompositeEncoder")))
@protocol IPGSCKotlinx_serialization_coreCompositeEncoder
@required
- (void)encodeBooleanElementDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(BOOL)value __attribute__((swift_name("encodeBooleanElement(descriptor:index:value:)")));
- (void)encodeByteElementDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int8_t)value __attribute__((swift_name("encodeByteElement(descriptor:index:value:)")));
- (void)encodeCharElementDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(unichar)value __attribute__((swift_name("encodeCharElement(descriptor:index:value:)")));
- (void)encodeDoubleElementDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(double)value __attribute__((swift_name("encodeDoubleElement(descriptor:index:value:)")));
- (void)encodeFloatElementDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(float)value __attribute__((swift_name("encodeFloatElement(descriptor:index:value:)")));
- (id<IPGSCKotlinx_serialization_coreEncoder>)encodeInlineElementDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("encodeInlineElement(descriptor:index:)")));
- (void)encodeIntElementDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int32_t)value __attribute__((swift_name("encodeIntElement(descriptor:index:value:)")));
- (void)encodeLongElementDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int64_t)value __attribute__((swift_name("encodeLongElement(descriptor:index:value:)")));
- (void)encodeNullableSerializableElementDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<IPGSCKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeSerializableElementDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<IPGSCKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeShortElementDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int16_t)value __attribute__((swift_name("encodeShortElement(descriptor:index:value:)")));
- (void)encodeStringElementDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(NSString *)value __attribute__((swift_name("encodeStringElement(descriptor:index:value:)")));
- (void)endStructureDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));
- (BOOL)shouldEncodeElementDefaultDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("shouldEncodeElementDefault(descriptor:index:)")));
@property (readonly) IPGSCKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end;

__attribute__((swift_name("KotlinAnnotation")))
@protocol IPGSCKotlinAnnotation
@required
@end;

__attribute__((swift_name("Kotlinx_serialization_coreSerialKind")))
@interface IPGSCKotlinx_serialization_coreSerialKind : IPGSCBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end;

__attribute__((swift_name("Kotlinx_serialization_coreCompositeDecoder")))
@protocol IPGSCKotlinx_serialization_coreCompositeDecoder
@required
- (BOOL)decodeBooleanElementDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeBooleanElement(descriptor:index:)")));
- (int8_t)decodeByteElementDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeByteElement(descriptor:index:)")));
- (unichar)decodeCharElementDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeCharElement(descriptor:index:)")));
- (int32_t)decodeCollectionSizeDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeCollectionSize(descriptor:)")));
- (double)decodeDoubleElementDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeDoubleElement(descriptor:index:)")));
- (int32_t)decodeElementIndexDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeElementIndex(descriptor:)")));
- (float)decodeFloatElementDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeFloatElement(descriptor:index:)")));
- (id<IPGSCKotlinx_serialization_coreDecoder>)decodeInlineElementDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeInlineElement(descriptor:index:)")));
- (int32_t)decodeIntElementDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeIntElement(descriptor:index:)")));
- (int64_t)decodeLongElementDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeLongElement(descriptor:index:)")));
- (id _Nullable)decodeNullableSerializableElementDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<IPGSCKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeNullableSerializableElement(descriptor:index:deserializer:previousValue:)")));
- (BOOL)decodeSequentially __attribute__((swift_name("decodeSequentially()")));
- (id _Nullable)decodeSerializableElementDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<IPGSCKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeSerializableElement(descriptor:index:deserializer:previousValue:)")));
- (int16_t)decodeShortElementDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeShortElement(descriptor:index:)")));
- (NSString *)decodeStringElementDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeStringElement(descriptor:index:)")));
- (void)endStructureDescriptor:(id<IPGSCKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));
@property (readonly) IPGSCKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end;

__attribute__((swift_name("Kodein_diDIBuilderDirectBinder")))
@protocol IPGSCKodein_diDIBuilderDirectBinder
@required
- (void)fromBinding:(id<IPGSCKodein_diDIBinding>)binding __attribute__((swift_name("from(binding:)")));
@end;

__attribute__((swift_name("Kodein_diDIBuilderTypeBinder")))
@protocol IPGSCKodein_diDIBuilderTypeBinder
@required
- (void)withBinding:(id<IPGSCKodein_diDIBinding>)binding __attribute__((swift_name("with(binding:)")));
@end;

__attribute__((swift_name("Kodein_diContextTranslator")))
@protocol IPGSCKodein_diContextTranslator
@required
- (id _Nullable)translateDi:(id<IPGSCKodein_diDirectDI>)di ctx:(id)ctx __attribute__((swift_name("translate(di:ctx:)")));
@property (readonly) IPGSCKodein_typeTypeToken<id> *contextType __attribute__((swift_name("contextType")));
@property (readonly) IPGSCKodein_typeTypeToken<id> *scopeType __attribute__((swift_name("scopeType")));
@end;

__attribute__((swift_name("Kodein_diDIBuilderConstantBinder")))
@protocol IPGSCKodein_diDIBuilderConstantBinder
@required
- (void)WithValueType:(IPGSCKodein_typeTypeToken<id> *)valueType value:(id)value __attribute__((swift_name("With(valueType:value:)")));
@end;

__attribute__((swift_name("Kodein_diDirectDIAware")))
@protocol IPGSCKodein_diDirectDIAware
@required
@property (readonly) id<IPGSCKodein_diDirectDI> directDI __attribute__((swift_name("directDI")));
@end;

__attribute__((swift_name("Kodein_diDirectDIBase")))
@protocol IPGSCKodein_diDirectDIBase <IPGSCKodein_diDirectDIAware>
@required
- (id (^)(id _Nullable))FactoryArgType:(IPGSCKodein_typeTypeToken<id> *)argType type:(IPGSCKodein_typeTypeToken<id> *)type tag:(id _Nullable)tag __attribute__((swift_name("Factory(argType:type:tag:)")));
- (id (^ _Nullable)(id _Nullable))FactoryOrNullArgType:(IPGSCKodein_typeTypeToken<id> *)argType type:(IPGSCKodein_typeTypeToken<id> *)type tag:(id _Nullable)tag __attribute__((swift_name("FactoryOrNull(argType:type:tag:)")));
- (id)InstanceType:(IPGSCKodein_typeTypeToken<id> *)type tag:(id _Nullable)tag __attribute__((swift_name("Instance(type:tag:)")));
- (id)InstanceArgType:(IPGSCKodein_typeTypeToken<id> *)argType type:(IPGSCKodein_typeTypeToken<id> *)type tag:(id _Nullable)tag arg:(id _Nullable)arg __attribute__((swift_name("Instance(argType:type:tag:arg:)")));
- (id _Nullable)InstanceOrNullType:(IPGSCKodein_typeTypeToken<id> *)type tag:(id _Nullable)tag __attribute__((swift_name("InstanceOrNull(type:tag:)")));
- (id _Nullable)InstanceOrNullArgType:(IPGSCKodein_typeTypeToken<id> *)argType type:(IPGSCKodein_typeTypeToken<id> *)type tag:(id _Nullable)tag arg:(id _Nullable)arg __attribute__((swift_name("InstanceOrNull(argType:type:tag:arg:)")));
- (id<IPGSCKodein_diDirectDI>)OnContext:(id<IPGSCKodein_diDIContext>)context __attribute__((swift_name("On(context:)")));
- (id (^)(void))ProviderType:(IPGSCKodein_typeTypeToken<id> *)type tag:(id _Nullable)tag __attribute__((swift_name("Provider(type:tag:)")));
- (id (^)(void))ProviderArgType:(IPGSCKodein_typeTypeToken<id> *)argType type:(IPGSCKodein_typeTypeToken<id> *)type tag:(id _Nullable)tag arg:(id _Nullable (^)(void))arg __attribute__((swift_name("Provider(argType:type:tag:arg:)")));
- (id (^ _Nullable)(void))ProviderOrNullType:(IPGSCKodein_typeTypeToken<id> *)type tag:(id _Nullable)tag __attribute__((swift_name("ProviderOrNull(type:tag:)")));
- (id (^ _Nullable)(void))ProviderOrNullArgType:(IPGSCKodein_typeTypeToken<id> *)argType type:(IPGSCKodein_typeTypeToken<id> *)type tag:(id _Nullable)tag arg:(id _Nullable (^)(void))arg __attribute__((swift_name("ProviderOrNull(argType:type:tag:arg:)")));
@property (readonly) id<IPGSCKodein_diDIContainer> container __attribute__((swift_name("container")));
@property (readonly) id<IPGSCKodein_diDI> di __attribute__((swift_name("di")));
@property (readonly) id<IPGSCKodein_diDI> lazy __attribute__((swift_name("lazy")));
@end;

__attribute__((swift_name("Kodein_diDirectDI")))
@protocol IPGSCKodein_diDirectDI <IPGSCKodein_diDirectDIBase>
@required
@end;

__attribute__((swift_name("Kodein_diDIContainerBuilder")))
@protocol IPGSCKodein_diDIContainerBuilder
@required
- (void)bindKey:(IPGSCKodein_diDIKey<id, id, id> *)key binding:(id<IPGSCKodein_diDIBinding>)binding fromModule:(NSString * _Nullable)fromModule overrides:(IPGSCBoolean * _Nullable)overrides __attribute__((swift_name("bind(key:binding:fromModule:overrides:)")));
- (void)extendContainer:(id<IPGSCKodein_diDIContainer>)container allowOverride:(BOOL)allowOverride copy:(NSSet<IPGSCKodein_diDIKey<id, id, id> *> *)copy __attribute__((swift_name("extend(container:allowOverride:copy:)")));
- (void)onReadyCb:(void (^)(id<IPGSCKodein_diDirectDI>))cb __attribute__((swift_name("onReady(cb:)")));
- (void)registerContextTranslatorTranslator:(id<IPGSCKodein_diContextTranslator>)translator __attribute__((swift_name("registerContextTranslator(translator:)")));
- (id<IPGSCKodein_diDIContainerBuilder>)subBuilderAllowOverride:(BOOL)allowOverride silentOverride:(BOOL)silentOverride __attribute__((swift_name("subBuilder(allowOverride:silentOverride:)")));
@end;

__attribute__((swift_name("Kodein_diScope")))
@protocol IPGSCKodein_diScope
@required
- (IPGSCKodein_diScopeRegistry *)getRegistryContext:(id _Nullable)context __attribute__((swift_name("getRegistry(context:)")));
@end;

__attribute__((swift_name("KotlinByteIterator")))
@interface IPGSCKotlinByteIterator : IPGSCBase <IPGSCKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (IPGSCByte *)next __attribute__((swift_name("next()")));
- (int8_t)nextByte __attribute__((swift_name("nextByte()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpUrl")))
@interface IPGSCKtor_httpUrl : IPGSCBase
@property (class, readonly, getter=companion) IPGSCKtor_httpUrlCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *encodedFragment __attribute__((swift_name("encodedFragment")));
@property (readonly) NSString * _Nullable encodedPassword __attribute__((swift_name("encodedPassword")));
@property (readonly) NSString *encodedPath __attribute__((swift_name("encodedPath")));
@property (readonly) NSString *encodedPathAndQuery __attribute__((swift_name("encodedPathAndQuery")));
@property (readonly) NSString *encodedQuery __attribute__((swift_name("encodedQuery")));
@property (readonly) NSString * _Nullable encodedUser __attribute__((swift_name("encodedUser")));
@property (readonly) NSString *fragment __attribute__((swift_name("fragment")));
@property (readonly) NSString *host __attribute__((swift_name("host")));
@property (readonly) id<IPGSCKtor_httpParameters> parameters __attribute__((swift_name("parameters")));
@property (readonly) NSString * _Nullable password __attribute__((swift_name("password")));
@property (readonly) NSArray<NSString *> *pathSegments __attribute__((swift_name("pathSegments")));
@property (readonly) int32_t port __attribute__((swift_name("port")));
@property (readonly) IPGSCKtor_httpURLProtocol *protocol __attribute__((swift_name("protocol")));
@property (readonly) int32_t specifiedPort __attribute__((swift_name("specifiedPort")));
@property (readonly) BOOL trailingQuery __attribute__((swift_name("trailingQuery")));
@property (readonly) NSString * _Nullable user __attribute__((swift_name("user")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpMethod")))
@interface IPGSCKtor_httpHttpMethod : IPGSCBase
- (instancetype)initWithValue:(NSString *)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) IPGSCKtor_httpHttpMethodCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (IPGSCKtor_httpHttpMethod *)doCopyValue:(NSString *)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((swift_name("Ktor_httpHeaders")))
@protocol IPGSCKtor_httpHeaders <IPGSCKtor_utilsStringValues>
@required
@end;

__attribute__((swift_name("Ktor_httpOutgoingContent")))
@interface IPGSCKtor_httpOutgoingContent : IPGSCBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (id _Nullable)getPropertyKey:(IPGSCKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("getProperty(key:)")));
- (void)setPropertyKey:(IPGSCKtor_utilsAttributeKey<id> *)key value:(id _Nullable)value __attribute__((swift_name("setProperty(key:value:)")));
- (id<IPGSCKtor_httpHeaders> _Nullable)trailers __attribute__((swift_name("trailers()")));
@property (readonly) IPGSCLong * _Nullable contentLength __attribute__((swift_name("contentLength")));
@property (readonly) IPGSCKtor_httpContentType * _Nullable contentType __attribute__((swift_name("contentType")));
@property (readonly) id<IPGSCKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@property (readonly) IPGSCKtor_httpHttpStatusCode * _Nullable status __attribute__((swift_name("status")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreJob")))
@protocol IPGSCKotlinx_coroutines_coreJob <IPGSCKotlinCoroutineContextElement>
@required
- (id<IPGSCKotlinx_coroutines_coreChildHandle>)attachChildChild:(id<IPGSCKotlinx_coroutines_coreChildJob>)child __attribute__((swift_name("attachChild(child:)")));
- (void)cancelCause:(IPGSCKotlinCancellationException * _Nullable)cause __attribute__((swift_name("cancel(cause:)")));
- (IPGSCKotlinCancellationException *)getCancellationException __attribute__((swift_name("getCancellationException()")));
- (id<IPGSCKotlinx_coroutines_coreDisposableHandle>)invokeOnCompletionOnCancelling:(BOOL)onCancelling invokeImmediately:(BOOL)invokeImmediately handler:(void (^)(IPGSCKotlinThrowable * _Nullable))handler __attribute__((swift_name("invokeOnCompletion(onCancelling:invokeImmediately:handler:)")));
- (id<IPGSCKotlinx_coroutines_coreDisposableHandle>)invokeOnCompletionHandler:(void (^)(IPGSCKotlinThrowable * _Nullable))handler __attribute__((swift_name("invokeOnCompletion(handler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)joinWithCompletionHandler:(void (^)(IPGSCKotlinUnit * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("join(completionHandler:)")));
- (id<IPGSCKotlinx_coroutines_coreJob>)plusOther_:(id<IPGSCKotlinx_coroutines_coreJob>)other __attribute__((swift_name("plus(other_:)"))) __attribute__((unavailable("Operator '+' on two Job objects is meaningless. Job is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The job to the right of `+` just replaces the job the left of `+`.")));
- (BOOL)start __attribute__((swift_name("start()")));
@property (readonly) id<IPGSCKotlinSequence> children __attribute__((swift_name("children")));
@property (readonly) BOOL isActive __attribute__((swift_name("isActive")));
@property (readonly) BOOL isCancelled __attribute__((swift_name("isCancelled")));
@property (readonly) BOOL isCompleted __attribute__((swift_name("isCompleted")));
@property (readonly) id<IPGSCKotlinx_coroutines_coreSelectClause0> onJoin __attribute__((swift_name("onJoin")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpStatusCode")))
@interface IPGSCKtor_httpHttpStatusCode : IPGSCBase
- (instancetype)initWithValue:(int32_t)value description:(NSString *)description __attribute__((swift_name("init(value:description:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) IPGSCKtor_httpHttpStatusCodeCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)component1 __attribute__((swift_name("component1()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (IPGSCKtor_httpHttpStatusCode *)doCopyValue:(int32_t)value description:(NSString *)description __attribute__((swift_name("doCopy(value:description:)")));
- (IPGSCKtor_httpHttpStatusCode *)descriptionValue:(NSString *)value __attribute__((swift_name("description(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *description_ __attribute__((swift_name("description_")));
@property (readonly) int32_t value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsGMTDate")))
@interface IPGSCKtor_utilsGMTDate : IPGSCBase <IPGSCKotlinComparable>
@property (class, readonly, getter=companion) IPGSCKtor_utilsGMTDateCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(IPGSCKtor_utilsGMTDate *)other __attribute__((swift_name("compareTo(other:)")));
- (int32_t)component1 __attribute__((swift_name("component1()")));
- (int32_t)component2 __attribute__((swift_name("component2()")));
- (int32_t)component3 __attribute__((swift_name("component3()")));
- (IPGSCKtor_utilsWeekDay *)component4 __attribute__((swift_name("component4()")));
- (int32_t)component5 __attribute__((swift_name("component5()")));
- (int32_t)component6 __attribute__((swift_name("component6()")));
- (IPGSCKtor_utilsMonth *)component7 __attribute__((swift_name("component7()")));
- (int32_t)component8 __attribute__((swift_name("component8()")));
- (int64_t)component9 __attribute__((swift_name("component9()")));
- (IPGSCKtor_utilsGMTDate *)doCopySeconds:(int32_t)seconds minutes:(int32_t)minutes hours:(int32_t)hours dayOfWeek:(IPGSCKtor_utilsWeekDay *)dayOfWeek dayOfMonth:(int32_t)dayOfMonth dayOfYear:(int32_t)dayOfYear month:(IPGSCKtor_utilsMonth *)month year:(int32_t)year timestamp:(int64_t)timestamp __attribute__((swift_name("doCopy(seconds:minutes:hours:dayOfWeek:dayOfMonth:dayOfYear:month:year:timestamp:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t dayOfMonth __attribute__((swift_name("dayOfMonth")));
@property (readonly) IPGSCKtor_utilsWeekDay *dayOfWeek __attribute__((swift_name("dayOfWeek")));
@property (readonly) int32_t dayOfYear __attribute__((swift_name("dayOfYear")));
@property (readonly) int32_t hours __attribute__((swift_name("hours")));
@property (readonly) int32_t minutes __attribute__((swift_name("minutes")));
@property (readonly) IPGSCKtor_utilsMonth *month __attribute__((swift_name("month")));
@property (readonly) int32_t seconds __attribute__((swift_name("seconds")));
@property (readonly) int64_t timestamp __attribute__((swift_name("timestamp")));
@property (readonly) int32_t year __attribute__((swift_name("year")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpProtocolVersion")))
@interface IPGSCKtor_httpHttpProtocolVersion : IPGSCBase
- (instancetype)initWithName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("init(name:major:minor:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) IPGSCKtor_httpHttpProtocolVersionCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (int32_t)component2 __attribute__((swift_name("component2()")));
- (int32_t)component3 __attribute__((swift_name("component3()")));
- (IPGSCKtor_httpHttpProtocolVersion *)doCopyName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("doCopy(name:major:minor:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t major __attribute__((swift_name("major")));
@property (readonly) int32_t minor __attribute__((swift_name("minor")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end;

__attribute__((swift_name("KotlinContinuation")))
@protocol IPGSCKotlinContinuation
@required
- (void)resumeWithResult:(id _Nullable)result __attribute__((swift_name("resumeWith(result:)")));
@property (readonly) id<IPGSCKotlinCoroutineContext> context __attribute__((swift_name("context")));
@end;

__attribute__((swift_name("KotlinAbstractCoroutineContextKey")))
@interface IPGSCKotlinAbstractCoroutineContextKey<B, E> : IPGSCBase <IPGSCKotlinCoroutineContextKey>
- (instancetype)initWithBaseKey:(id<IPGSCKotlinCoroutineContextKey>)baseKey safeCast:(E _Nullable (^)(id<IPGSCKotlinCoroutineContextElement>))safeCast __attribute__((swift_name("init(baseKey:safeCast:)"))) __attribute__((objc_designated_initializer));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineDispatcher.Key")))
@interface IPGSCKotlinx_coroutines_coreCoroutineDispatcherKey : IPGSCKotlinAbstractCoroutineContextKey<id<IPGSCKotlinContinuationInterceptor>, IPGSCKotlinx_coroutines_coreCoroutineDispatcher *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithBaseKey:(id<IPGSCKotlinCoroutineContextKey>)baseKey safeCast:(id<IPGSCKotlinCoroutineContextElement> _Nullable (^)(id<IPGSCKotlinCoroutineContextElement>))safeCast __attribute__((swift_name("init(baseKey:safeCast:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)key __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCKotlinx_coroutines_coreCoroutineDispatcherKey *shared __attribute__((swift_name("shared")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreRunnable")))
@protocol IPGSCKotlinx_coroutines_coreRunnable
@required
- (void)run __attribute__((swift_name("run()")));
@end;

__attribute__((swift_name("Ktor_ioByteReadChannel")))
@protocol IPGSCKtor_ioByteReadChannel
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)awaitContentWithCompletionHandler:(void (^)(IPGSCKotlinUnit * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("awaitContent(completionHandler:)")));
- (BOOL)cancelCause_:(IPGSCKotlinThrowable * _Nullable)cause __attribute__((swift_name("cancel(cause_:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)discardMax:(int64_t)max completionHandler:(void (^)(IPGSCLong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("discard(max:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)peekToDestination:(IPGSCKtor_ioMemory *)destination destinationOffset:(int64_t)destinationOffset offset:(int64_t)offset min:(int64_t)min max:(int64_t)max completionHandler:(void (^)(IPGSCLong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("peekTo(destination:destinationOffset:offset:min:max:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readAvailableDst:(IPGSCKtor_ioChunkBuffer *)dst completionHandler:(void (^)(IPGSCInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readAvailable(dst:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readAvailableDst:(IPGSCKotlinByteArray *)dst offset:(int32_t)offset length:(int32_t)length completionHandler:(void (^)(IPGSCInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readAvailable(dst:offset:length:completionHandler:)")));
- (int32_t)readAvailableMin:(int32_t)min block:(void (^)(IPGSCKtor_ioBuffer *))block __attribute__((swift_name("readAvailable(min:block:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readAvailableDst:(void *)dst offset:(int32_t)offset length:(int32_t)length completionHandler_:(void (^)(IPGSCInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readAvailable(dst:offset:length:completionHandler_:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readAvailableDst:(void *)dst offset:(int64_t)offset length:(int64_t)length completionHandler__:(void (^)(IPGSCInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readAvailable(dst:offset:length:completionHandler__:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readBooleanWithCompletionHandler:(void (^)(IPGSCBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readBoolean(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readByteWithCompletionHandler:(void (^)(IPGSCByte * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readByte(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readDoubleWithCompletionHandler:(void (^)(IPGSCDouble * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readDouble(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readFloatWithCompletionHandler:(void (^)(IPGSCFloat * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readFloat(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readFullyDst:(IPGSCKtor_ioChunkBuffer *)dst n:(int32_t)n completionHandler:(void (^)(IPGSCKotlinUnit * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readFully(dst:n:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readFullyDst:(IPGSCKotlinByteArray *)dst offset:(int32_t)offset length:(int32_t)length completionHandler:(void (^)(IPGSCKotlinUnit * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readFully(dst:offset:length:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readFullyDst:(void *)dst offset:(int32_t)offset length:(int32_t)length completionHandler_:(void (^)(IPGSCKotlinUnit * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readFully(dst:offset:length:completionHandler_:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readFullyDst:(void *)dst offset:(int64_t)offset length:(int64_t)length completionHandler__:(void (^)(IPGSCKotlinUnit * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readFully(dst:offset:length:completionHandler__:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readIntWithCompletionHandler:(void (^)(IPGSCInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readInt(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readLongWithCompletionHandler:(void (^)(IPGSCLong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readLong(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readPacketSize:(int32_t)size completionHandler:(void (^)(IPGSCKtor_ioByteReadPacket * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readPacket(size:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readRemainingLimit:(int64_t)limit completionHandler:(void (^)(IPGSCKtor_ioByteReadPacket * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readRemaining(limit:completionHandler:)")));
- (void)readSessionConsumer:(void (^)(id<IPGSCKtor_ioReadSession>))consumer __attribute__((swift_name("readSession(consumer:)"))) __attribute__((deprecated("Use read { } instead.")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readShortWithCompletionHandler:(void (^)(IPGSCShort * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readShort(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readSuspendableSessionConsumer:(id<IPGSCKotlinSuspendFunction1>)consumer completionHandler:(void (^)(IPGSCKotlinUnit * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readSuspendableSession(consumer:completionHandler:)"))) __attribute__((deprecated("Use read { } instead.")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readUTF8LineLimit:(int32_t)limit completionHandler:(void (^)(NSString * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("readUTF8Line(limit:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readUTF8LineToOut:(id<IPGSCKotlinAppendable>)out limit:(int32_t)limit completionHandler:(void (^)(IPGSCBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readUTF8LineTo(out:limit:completionHandler:)")));
@property (readonly) int32_t availableForRead __attribute__((swift_name("availableForRead")));
@property (readonly) IPGSCKotlinThrowable * _Nullable closedCause __attribute__((swift_name("closedCause")));
@property (readonly) BOOL isClosedForRead __attribute__((swift_name("isClosedForRead")));
@property (readonly) BOOL isClosedForWrite __attribute__((swift_name("isClosedForWrite")));
@property (readonly) int64_t totalBytesRead __attribute__((swift_name("totalBytesRead")));
@end;

__attribute__((swift_name("Ktor_utilsStringValuesBuilder")))
@protocol IPGSCKtor_utilsStringValuesBuilder
@required
- (void)appendName:(NSString *)name value:(NSString *)value __attribute__((swift_name("append(name:value:)")));
- (void)appendAllStringValues:(id<IPGSCKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendAll(stringValues:)")));
- (void)appendAllName:(NSString *)name values:(id)values __attribute__((swift_name("appendAll(name:values:)")));
- (void)appendMissingStringValues:(id<IPGSCKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendMissing(stringValues:)")));
- (void)appendMissingName:(NSString *)name values:(id)values __attribute__((swift_name("appendMissing(name:values:)")));
- (id<IPGSCKtor_utilsStringValues>)build __attribute__((swift_name("build()")));
- (void)clear __attribute__((swift_name("clear()")));
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));
- (NSSet<id<IPGSCKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));
- (void)removeName:(NSString *)name __attribute__((swift_name("remove(name:)")));
- (BOOL)removeName:(NSString *)name value:(NSString *)value __attribute__((swift_name("remove(name:value:)")));
- (void)removeKeysWithNoEntries __attribute__((swift_name("removeKeysWithNoEntries()")));
- (void)setName:(NSString *)name value:(NSString *)value __attribute__((swift_name("set(name:value:)")));
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));
@end;

__attribute__((swift_name("Ktor_utilsStringValuesBuilderImpl")))
@interface IPGSCKtor_utilsStringValuesBuilderImpl : IPGSCBase <IPGSCKtor_utilsStringValuesBuilder>
- (instancetype)initWithCaseInsensitiveName:(BOOL)caseInsensitiveName size:(int32_t)size __attribute__((swift_name("init(caseInsensitiveName:size:)"))) __attribute__((objc_designated_initializer));
- (void)appendName:(NSString *)name value:(NSString *)value __attribute__((swift_name("append(name:value:)")));
- (void)appendAllStringValues:(id<IPGSCKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendAll(stringValues:)")));
- (void)appendAllName:(NSString *)name values:(id)values __attribute__((swift_name("appendAll(name:values:)")));
- (void)appendMissingStringValues:(id<IPGSCKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendMissing(stringValues:)")));
- (void)appendMissingName:(NSString *)name values:(id)values __attribute__((swift_name("appendMissing(name:values:)")));
- (id<IPGSCKtor_utilsStringValues>)build __attribute__((swift_name("build()")));
- (void)clear __attribute__((swift_name("clear()")));
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));
- (NSSet<id<IPGSCKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));
- (void)removeName:(NSString *)name __attribute__((swift_name("remove(name:)")));
- (BOOL)removeName:(NSString *)name value:(NSString *)value __attribute__((swift_name("remove(name:value:)")));
- (void)removeKeysWithNoEntries __attribute__((swift_name("removeKeysWithNoEntries()")));
- (void)setName:(NSString *)name value:(NSString *)value __attribute__((swift_name("set(name:value:)")));
- (void)validateNameName:(NSString *)name __attribute__((swift_name("validateName(name:)")));
- (void)validateValueValue:(NSString *)value __attribute__((swift_name("validateValue(value:)")));
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));
@property (readonly) IPGSCMutableDictionary<NSString *, NSMutableArray<NSString *> *> *values __attribute__((swift_name("values")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeadersBuilder")))
@interface IPGSCKtor_httpHeadersBuilder : IPGSCKtor_utilsStringValuesBuilderImpl
- (instancetype)initWithSize:(int32_t)size __attribute__((swift_name("init(size:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCaseInsensitiveName:(BOOL)caseInsensitiveName size:(int32_t)size __attribute__((swift_name("init(caseInsensitiveName:size:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (id<IPGSCKtor_httpHeaders>)build __attribute__((swift_name("build()")));
- (void)validateNameName:(NSString *)name __attribute__((swift_name("validateName(name:)")));
- (void)validateValueValue:(NSString *)value __attribute__((swift_name("validateValue(value:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestBuilder.Companion")))
@interface IPGSCKtor_client_coreHttpRequestBuilderCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCKtor_client_coreHttpRequestBuilderCompanion *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLBuilder")))
@interface IPGSCKtor_httpURLBuilder : IPGSCBase
- (instancetype)initWithProtocol:(IPGSCKtor_httpURLProtocol *)protocol host:(NSString *)host port:(int32_t)port user:(NSString * _Nullable)user password:(NSString * _Nullable)password pathSegments:(NSArray<NSString *> *)pathSegments parameters:(id<IPGSCKtor_httpParameters>)parameters fragment:(NSString *)fragment trailingQuery:(BOOL)trailingQuery __attribute__((swift_name("init(protocol:host:port:user:password:pathSegments:parameters:fragment:trailingQuery:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) IPGSCKtor_httpURLBuilderCompanion *companion __attribute__((swift_name("companion")));
- (IPGSCKtor_httpUrl *)build __attribute__((swift_name("build()")));
- (NSString *)buildString __attribute__((swift_name("buildString()")));
@property NSString *encodedFragment __attribute__((swift_name("encodedFragment")));
@property id<IPGSCKtor_httpParametersBuilder> encodedParameters __attribute__((swift_name("encodedParameters")));
@property NSString * _Nullable encodedPassword __attribute__((swift_name("encodedPassword")));
@property NSArray<NSString *> *encodedPathSegments __attribute__((swift_name("encodedPathSegments")));
@property NSString * _Nullable encodedUser __attribute__((swift_name("encodedUser")));
@property NSString *fragment __attribute__((swift_name("fragment")));
@property NSString *host __attribute__((swift_name("host")));
@property (readonly) id<IPGSCKtor_httpParametersBuilder> parameters __attribute__((swift_name("parameters")));
@property NSString * _Nullable password __attribute__((swift_name("password")));
@property NSArray<NSString *> *pathSegments __attribute__((swift_name("pathSegments")));
@property int32_t port __attribute__((swift_name("port")));
@property IPGSCKtor_httpURLProtocol *protocol __attribute__((swift_name("protocol")));
@property BOOL trailingQuery __attribute__((swift_name("trailingQuery")));
@property NSString * _Nullable user __attribute__((swift_name("user")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsTypeInfo")))
@interface IPGSCKtor_utilsTypeInfo : IPGSCBase
- (instancetype)initWithType:(id<IPGSCKotlinKClass>)type reifiedType:(id<IPGSCKotlinKType>)reifiedType kotlinType:(id<IPGSCKotlinKType> _Nullable)kotlinType __attribute__((swift_name("init(type:reifiedType:kotlinType:)"))) __attribute__((objc_designated_initializer));
- (id<IPGSCKotlinKClass>)component1 __attribute__((swift_name("component1()")));
- (id<IPGSCKotlinKType>)component2 __attribute__((swift_name("component2()")));
- (id<IPGSCKotlinKType> _Nullable)component3 __attribute__((swift_name("component3()")));
- (IPGSCKtor_utilsTypeInfo *)doCopyType:(id<IPGSCKotlinKClass>)type reifiedType:(id<IPGSCKotlinKType>)reifiedType kotlinType:(id<IPGSCKotlinKType> _Nullable)kotlinType __attribute__((swift_name("doCopy(type:reifiedType:kotlinType:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<IPGSCKotlinKType> _Nullable kotlinType __attribute__((swift_name("kotlinType")));
@property (readonly) id<IPGSCKotlinKType> reifiedType __attribute__((swift_name("reifiedType")));
@property (readonly) id<IPGSCKotlinKClass> type __attribute__((swift_name("type")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClientCall.Companion")))
@interface IPGSCKtor_client_coreHttpClientCallCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCKtor_client_coreHttpClientCallCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) IPGSCKtor_utilsAttributeKey<id> *CustomResponse __attribute__((swift_name("CustomResponse"))) __attribute__((unavailable("This is going to be removed. Please file a ticket with clarification why and what for do you need it.")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpRequest")))
@protocol IPGSCKtor_client_coreHttpRequest <IPGSCKtor_httpHttpMessage, IPGSCKotlinx_coroutines_coreCoroutineScope>
@required
@property (readonly) id<IPGSCKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) IPGSCKtor_client_coreHttpClientCall *call __attribute__((swift_name("call")));
@property (readonly) IPGSCKtor_httpOutgoingContent *content __attribute__((swift_name("content")));
@property (readonly) IPGSCKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) IPGSCKtor_httpUrl *url __attribute__((swift_name("url")));
@end;

__attribute__((swift_name("Kodein_diDIDefining")))
@interface IPGSCKodein_diDIDefining<C, A, T> : IPGSCBase
- (instancetype)initWithBinding:(id<IPGSCKodein_diDIBinding>)binding fromModule:(NSString * _Nullable)fromModule __attribute__((swift_name("init(binding:fromModule:)"))) __attribute__((objc_designated_initializer));
@property (readonly) id<IPGSCKodein_diDIBinding> binding __attribute__((swift_name("binding")));
@property (readonly) NSString * _Nullable fromModule __attribute__((swift_name("fromModule")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kodein_diDIDefinition")))
@interface IPGSCKodein_diDIDefinition<C, A, T> : IPGSCKodein_diDIDefining<C, A, T>
- (instancetype)initWithBinding:(id<IPGSCKodein_diDIBinding>)binding fromModule:(NSString * _Nullable)fromModule tree:(id<IPGSCKodein_diDITree>)tree __attribute__((swift_name("init(binding:fromModule:tree:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithBinding:(id<IPGSCKodein_diDIBinding>)binding fromModule:(NSString * _Nullable)fromModule __attribute__((swift_name("init(binding:fromModule:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (readonly) id<IPGSCKodein_diDITree> tree __attribute__((swift_name("tree")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinTriple")))
@interface IPGSCKotlinTriple<__covariant A, __covariant B, __covariant C> : IPGSCBase
- (instancetype)initWithFirst:(A _Nullable)first second:(B _Nullable)second third:(C _Nullable)third __attribute__((swift_name("init(first:second:third:)"))) __attribute__((objc_designated_initializer));
- (A _Nullable)component1 __attribute__((swift_name("component1()")));
- (B _Nullable)component2 __attribute__((swift_name("component2()")));
- (C _Nullable)component3 __attribute__((swift_name("component3()")));
- (IPGSCKotlinTriple<A, B, C> *)doCopyFirst:(A _Nullable)first second:(B _Nullable)second third:(C _Nullable)third __attribute__((swift_name("doCopy(first:second:third:)")));
- (BOOL)equalsOther:(id _Nullable)other __attribute__((swift_name("equals(other:)")));
- (int32_t)hashCode __attribute__((swift_name("hashCode()")));
- (NSString *)toString __attribute__((swift_name("toString()")));
@property (readonly) A _Nullable first __attribute__((swift_name("first")));
@property (readonly) B _Nullable second __attribute__((swift_name("second")));
@property (readonly) C _Nullable third __attribute__((swift_name("third")));
@end;

__attribute__((swift_name("Kodein_diSearchSpecs")))
@interface IPGSCKodein_diSearchSpecs : IPGSCBase
- (instancetype)initWithContextType:(IPGSCKodein_typeTypeToken<id> * _Nullable)contextType argType:(IPGSCKodein_typeTypeToken<id> * _Nullable)argType type:(IPGSCKodein_typeTypeToken<id> * _Nullable)type tag:(id _Nullable)tag __attribute__((swift_name("init(contextType:argType:type:tag:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property IPGSCKodein_typeTypeToken<id> * _Nullable argType __attribute__((swift_name("argType")));
@property IPGSCKodein_typeTypeToken<id> * _Nullable contextType __attribute__((swift_name("contextType")));
@property id _Nullable tag __attribute__((swift_name("tag")));
@property IPGSCKodein_typeTypeToken<id> * _Nullable type __attribute__((swift_name("type")));
@end;

__attribute__((swift_name("Kodein_diExternalSource")))
@protocol IPGSCKodein_diExternalSource
@required
- (id (^ _Nullable)(id _Nullable))getFactoryDi:(id<IPGSCKodein_diBindingDI>)di key:(IPGSCKodein_diDIKey<id, id, id> *)key __attribute__((swift_name("getFactory(di:key:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kodein_typeTypeTokenCompanion")))
@interface IPGSCKodein_typeTypeTokenCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCKodein_typeTypeTokenCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) IPGSCKodein_typeTypeToken<id> *Any __attribute__((swift_name("Any")));
@property (readonly) IPGSCKodein_typeTypeToken<IPGSCKotlinUnit *> *Unit __attribute__((swift_name("Unit")));
@end;

__attribute__((swift_name("Kodein_diBinding")))
@protocol IPGSCKodein_diBinding
@required
- (id (^)(id _Nullable))getFactoryKey:(IPGSCKodein_diDIKey<id, id, id> *)key di:(id<IPGSCKodein_diBindingDI>)di __attribute__((swift_name("getFactory(key:di:)")));
@end;

__attribute__((swift_name("Kodein_diDIBinding")))
@protocol IPGSCKodein_diDIBinding <IPGSCKodein_diBinding>
@required
- (NSString *)factoryFullName __attribute__((swift_name("factoryFullName()")));
- (NSString *)factoryName __attribute__((swift_name("factoryName()")));
@property (readonly) IPGSCKodein_typeTypeToken<id> *argType __attribute__((swift_name("argType")));
@property (readonly) IPGSCKodein_typeTypeToken<id> *contextType __attribute__((swift_name("contextType")));
@property (readonly) id<IPGSCKodein_diDIBindingCopier> _Nullable copier __attribute__((swift_name("copier")));
@property (readonly) IPGSCKodein_typeTypeToken<id> *createdType __attribute__((swift_name("createdType")));
@property (readonly) NSString *description_ __attribute__((swift_name("description_")));
@property (readonly) NSString *fullDescription __attribute__((swift_name("fullDescription")));
@property (readonly) id<IPGSCKodein_diScope> _Nullable scope __attribute__((swift_name("scope")));
@property (readonly) BOOL supportSubTypes __attribute__((swift_name("supportSubTypes")));
@end;

__attribute__((swift_name("Kodein_diScopeCloseable")))
@protocol IPGSCKodein_diScopeCloseable
@required
- (void)close __attribute__((swift_name("close()")));
@end;

__attribute__((swift_name("Kodein_diScopeRegistry")))
@interface IPGSCKodein_diScopeRegistry : IPGSCBase <IPGSCKodein_diScopeCloseable>
- (void)clear __attribute__((swift_name("clear()")));
- (void)close __attribute__((swift_name("close()")));
- (id)getOrCreateKey:(id)key sync:(BOOL)sync creator:(IPGSCKodein_diReference<id> *(^)(void))creator __attribute__((swift_name("getOrCreate(key:sync:creator:)")));
- (id _Nullable (^ _Nullable)(void))getOrNullKey_:(id)key __attribute__((swift_name("getOrNull(key_:)")));
- (void)removeKey_:(id)key __attribute__((swift_name("remove(key_:)")));
- (id)values __attribute__((swift_name("values()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpUrl.Companion")))
@interface IPGSCKtor_httpUrlCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCKtor_httpUrlCompanion *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLProtocol")))
@interface IPGSCKtor_httpURLProtocol : IPGSCBase
- (instancetype)initWithName:(NSString *)name defaultPort:(int32_t)defaultPort __attribute__((swift_name("init(name:defaultPort:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) IPGSCKtor_httpURLProtocolCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (int32_t)component2 __attribute__((swift_name("component2()")));
- (IPGSCKtor_httpURLProtocol *)doCopyName:(NSString *)name defaultPort:(int32_t)defaultPort __attribute__((swift_name("doCopy(name:defaultPort:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t defaultPort __attribute__((swift_name("defaultPort")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpMethod.Companion")))
@interface IPGSCKtor_httpHttpMethodCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCKtor_httpHttpMethodCompanion *shared __attribute__((swift_name("shared")));
- (IPGSCKtor_httpHttpMethod *)parseMethod:(NSString *)method __attribute__((swift_name("parse(method:)")));
@property (readonly) NSArray<IPGSCKtor_httpHttpMethod *> *DefaultMethods __attribute__((swift_name("DefaultMethods")));
@property (readonly) IPGSCKtor_httpHttpMethod *Delete __attribute__((swift_name("Delete")));
@property (readonly) IPGSCKtor_httpHttpMethod *Get __attribute__((swift_name("Get")));
@property (readonly) IPGSCKtor_httpHttpMethod *Head __attribute__((swift_name("Head")));
@property (readonly) IPGSCKtor_httpHttpMethod *Options __attribute__((swift_name("Options")));
@property (readonly) IPGSCKtor_httpHttpMethod *Patch __attribute__((swift_name("Patch")));
@property (readonly) IPGSCKtor_httpHttpMethod *Post __attribute__((swift_name("Post")));
@property (readonly) IPGSCKtor_httpHttpMethod *Put __attribute__((swift_name("Put")));
@end;

__attribute__((swift_name("Ktor_httpHeaderValueWithParameters")))
@interface IPGSCKtor_httpHeaderValueWithParameters : IPGSCBase
- (instancetype)initWithContent:(NSString *)content parameters:(NSArray<IPGSCKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(content:parameters:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) IPGSCKtor_httpHeaderValueWithParametersCompanion *companion __attribute__((swift_name("companion")));
- (NSString * _Nullable)parameterName:(NSString *)name __attribute__((swift_name("parameter(name:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *content __attribute__((swift_name("content")));
@property (readonly) NSArray<IPGSCKtor_httpHeaderValueParam *> *parameters __attribute__((swift_name("parameters")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpContentType")))
@interface IPGSCKtor_httpContentType : IPGSCKtor_httpHeaderValueWithParameters
- (instancetype)initWithContentType:(NSString *)contentType contentSubtype:(NSString *)contentSubtype parameters:(NSArray<IPGSCKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(contentType:contentSubtype:parameters:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithContent:(NSString *)content parameters:(NSArray<IPGSCKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(content:parameters:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) IPGSCKtor_httpContentTypeCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)matchPattern:(IPGSCKtor_httpContentType *)pattern __attribute__((swift_name("match(pattern:)")));
- (BOOL)matchPattern_:(NSString *)pattern __attribute__((swift_name("match(pattern_:)")));
- (IPGSCKtor_httpContentType *)withParameterName:(NSString *)name value:(NSString *)value __attribute__((swift_name("withParameter(name:value:)")));
- (IPGSCKtor_httpContentType *)withoutParameters __attribute__((swift_name("withoutParameters()")));
@property (readonly) NSString *contentSubtype __attribute__((swift_name("contentSubtype")));
@property (readonly) NSString *contentType __attribute__((swift_name("contentType")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreChildHandle")))
@protocol IPGSCKotlinx_coroutines_coreChildHandle <IPGSCKotlinx_coroutines_coreDisposableHandle>
@required
- (BOOL)childCancelledCause:(IPGSCKotlinThrowable *)cause __attribute__((swift_name("childCancelled(cause:)")));
@property (readonly) id<IPGSCKotlinx_coroutines_coreJob> _Nullable parent __attribute__((swift_name("parent")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreChildJob")))
@protocol IPGSCKotlinx_coroutines_coreChildJob <IPGSCKotlinx_coroutines_coreJob>
@required
- (void)parentCancelledParentJob:(id<IPGSCKotlinx_coroutines_coreParentJob>)parentJob __attribute__((swift_name("parentCancelled(parentJob:)")));
@end;

__attribute__((swift_name("KotlinSequence")))
@protocol IPGSCKotlinSequence
@required
- (id<IPGSCKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreSelectClause0")))
@protocol IPGSCKotlinx_coroutines_coreSelectClause0
@required
- (void)registerSelectClause0Select:(id<IPGSCKotlinx_coroutines_coreSelectInstance>)select block:(id<IPGSCKotlinSuspendFunction0>)block __attribute__((swift_name("registerSelectClause0(select:block:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpStatusCode.Companion")))
@interface IPGSCKtor_httpHttpStatusCodeCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCKtor_httpHttpStatusCodeCompanion *shared __attribute__((swift_name("shared")));
- (IPGSCKtor_httpHttpStatusCode *)fromValueValue:(int32_t)value __attribute__((swift_name("fromValue(value:)")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *Accepted __attribute__((swift_name("Accepted")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *BadGateway __attribute__((swift_name("BadGateway")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *BadRequest __attribute__((swift_name("BadRequest")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *Conflict __attribute__((swift_name("Conflict")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *Continue __attribute__((swift_name("Continue")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *Created __attribute__((swift_name("Created")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *ExpectationFailed __attribute__((swift_name("ExpectationFailed")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *FailedDependency __attribute__((swift_name("FailedDependency")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *Forbidden __attribute__((swift_name("Forbidden")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *Found __attribute__((swift_name("Found")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *GatewayTimeout __attribute__((swift_name("GatewayTimeout")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *Gone __attribute__((swift_name("Gone")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *InsufficientStorage __attribute__((swift_name("InsufficientStorage")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *InternalServerError __attribute__((swift_name("InternalServerError")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *LengthRequired __attribute__((swift_name("LengthRequired")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *Locked __attribute__((swift_name("Locked")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *MethodNotAllowed __attribute__((swift_name("MethodNotAllowed")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *MovedPermanently __attribute__((swift_name("MovedPermanently")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *MultiStatus __attribute__((swift_name("MultiStatus")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *MultipleChoices __attribute__((swift_name("MultipleChoices")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *NoContent __attribute__((swift_name("NoContent")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *NonAuthoritativeInformation __attribute__((swift_name("NonAuthoritativeInformation")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *NotAcceptable __attribute__((swift_name("NotAcceptable")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *NotFound __attribute__((swift_name("NotFound")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *NotImplemented __attribute__((swift_name("NotImplemented")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *NotModified __attribute__((swift_name("NotModified")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *OK __attribute__((swift_name("OK")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *PartialContent __attribute__((swift_name("PartialContent")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *PayloadTooLarge __attribute__((swift_name("PayloadTooLarge")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *PaymentRequired __attribute__((swift_name("PaymentRequired")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *PermanentRedirect __attribute__((swift_name("PermanentRedirect")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *PreconditionFailed __attribute__((swift_name("PreconditionFailed")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *Processing __attribute__((swift_name("Processing")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *ProxyAuthenticationRequired __attribute__((swift_name("ProxyAuthenticationRequired")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *RequestHeaderFieldTooLarge __attribute__((swift_name("RequestHeaderFieldTooLarge")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *RequestTimeout __attribute__((swift_name("RequestTimeout")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *RequestURITooLong __attribute__((swift_name("RequestURITooLong")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *RequestedRangeNotSatisfiable __attribute__((swift_name("RequestedRangeNotSatisfiable")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *ResetContent __attribute__((swift_name("ResetContent")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *SeeOther __attribute__((swift_name("SeeOther")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *ServiceUnavailable __attribute__((swift_name("ServiceUnavailable")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *SwitchProxy __attribute__((swift_name("SwitchProxy")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *SwitchingProtocols __attribute__((swift_name("SwitchingProtocols")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *TemporaryRedirect __attribute__((swift_name("TemporaryRedirect")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *TooManyRequests __attribute__((swift_name("TooManyRequests")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *Unauthorized __attribute__((swift_name("Unauthorized")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *UnprocessableEntity __attribute__((swift_name("UnprocessableEntity")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *UnsupportedMediaType __attribute__((swift_name("UnsupportedMediaType")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *UpgradeRequired __attribute__((swift_name("UpgradeRequired")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *UseProxy __attribute__((swift_name("UseProxy")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *VariantAlsoNegotiates __attribute__((swift_name("VariantAlsoNegotiates")));
@property (readonly) IPGSCKtor_httpHttpStatusCode *VersionNotSupported __attribute__((swift_name("VersionNotSupported")));
@property (readonly) NSArray<IPGSCKtor_httpHttpStatusCode *> *allStatusCodes __attribute__((swift_name("allStatusCodes")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsGMTDate.Companion")))
@interface IPGSCKtor_utilsGMTDateCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCKtor_utilsGMTDateCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) IPGSCKtor_utilsGMTDate *START __attribute__((swift_name("START")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsWeekDay")))
@interface IPGSCKtor_utilsWeekDay : IPGSCKotlinEnum<IPGSCKtor_utilsWeekDay *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) IPGSCKtor_utilsWeekDayCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) IPGSCKtor_utilsWeekDay *monday __attribute__((swift_name("monday")));
@property (class, readonly) IPGSCKtor_utilsWeekDay *tuesday __attribute__((swift_name("tuesday")));
@property (class, readonly) IPGSCKtor_utilsWeekDay *wednesday __attribute__((swift_name("wednesday")));
@property (class, readonly) IPGSCKtor_utilsWeekDay *thursday __attribute__((swift_name("thursday")));
@property (class, readonly) IPGSCKtor_utilsWeekDay *friday __attribute__((swift_name("friday")));
@property (class, readonly) IPGSCKtor_utilsWeekDay *saturday __attribute__((swift_name("saturday")));
@property (class, readonly) IPGSCKtor_utilsWeekDay *sunday __attribute__((swift_name("sunday")));
+ (IPGSCKotlinArray<IPGSCKtor_utilsWeekDay *> *)values __attribute__((swift_name("values()")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsMonth")))
@interface IPGSCKtor_utilsMonth : IPGSCKotlinEnum<IPGSCKtor_utilsMonth *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) IPGSCKtor_utilsMonthCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) IPGSCKtor_utilsMonth *january __attribute__((swift_name("january")));
@property (class, readonly) IPGSCKtor_utilsMonth *february __attribute__((swift_name("february")));
@property (class, readonly) IPGSCKtor_utilsMonth *march __attribute__((swift_name("march")));
@property (class, readonly) IPGSCKtor_utilsMonth *april __attribute__((swift_name("april")));
@property (class, readonly) IPGSCKtor_utilsMonth *may __attribute__((swift_name("may")));
@property (class, readonly) IPGSCKtor_utilsMonth *june __attribute__((swift_name("june")));
@property (class, readonly) IPGSCKtor_utilsMonth *july __attribute__((swift_name("july")));
@property (class, readonly) IPGSCKtor_utilsMonth *august __attribute__((swift_name("august")));
@property (class, readonly) IPGSCKtor_utilsMonth *september __attribute__((swift_name("september")));
@property (class, readonly) IPGSCKtor_utilsMonth *october __attribute__((swift_name("october")));
@property (class, readonly) IPGSCKtor_utilsMonth *november __attribute__((swift_name("november")));
@property (class, readonly) IPGSCKtor_utilsMonth *december __attribute__((swift_name("december")));
+ (IPGSCKotlinArray<IPGSCKtor_utilsMonth *> *)values __attribute__((swift_name("values()")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpProtocolVersion.Companion")))
@interface IPGSCKtor_httpHttpProtocolVersionCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCKtor_httpHttpProtocolVersionCompanion *shared __attribute__((swift_name("shared")));
- (IPGSCKtor_httpHttpProtocolVersion *)fromValueName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("fromValue(name:major:minor:)")));
- (IPGSCKtor_httpHttpProtocolVersion *)parseValue:(id)value __attribute__((swift_name("parse(value:)")));
@property (readonly) IPGSCKtor_httpHttpProtocolVersion *HTTP_1_0 __attribute__((swift_name("HTTP_1_0")));
@property (readonly) IPGSCKtor_httpHttpProtocolVersion *HTTP_1_1 __attribute__((swift_name("HTTP_1_1")));
@property (readonly) IPGSCKtor_httpHttpProtocolVersion *HTTP_2_0 __attribute__((swift_name("HTTP_2_0")));
@property (readonly) IPGSCKtor_httpHttpProtocolVersion *QUIC __attribute__((swift_name("QUIC")));
@property (readonly) IPGSCKtor_httpHttpProtocolVersion *SPDY_3 __attribute__((swift_name("SPDY_3")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioMemory")))
@interface IPGSCKtor_ioMemory : IPGSCBase
- (instancetype)initWithPointer:(void *)pointer size:(int64_t)size __attribute__((swift_name("init(pointer:size:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) IPGSCKtor_ioMemoryCompanion *companion __attribute__((swift_name("companion")));
- (void)doCopyToDestination:(IPGSCKtor_ioMemory *)destination offset:(int32_t)offset length:(int32_t)length destinationOffset:(int32_t)destinationOffset __attribute__((swift_name("doCopyTo(destination:offset:length:destinationOffset:)")));
- (void)doCopyToDestination:(IPGSCKtor_ioMemory *)destination offset:(int64_t)offset length:(int64_t)length destinationOffset_:(int64_t)destinationOffset __attribute__((swift_name("doCopyTo(destination:offset:length:destinationOffset_:)")));
- (int8_t)loadAtIndex:(int32_t)index __attribute__((swift_name("loadAt(index:)")));
- (int8_t)loadAtIndex_:(int64_t)index __attribute__((swift_name("loadAt(index_:)")));
- (IPGSCKtor_ioMemory *)sliceOffset:(int32_t)offset length:(int32_t)length __attribute__((swift_name("slice(offset:length:)")));
- (IPGSCKtor_ioMemory *)sliceOffset:(int64_t)offset length_:(int64_t)length __attribute__((swift_name("slice(offset:length_:)")));
- (void)storeAtIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("storeAt(index:value:)")));
- (void)storeAtIndex:(int64_t)index value_:(int8_t)value __attribute__((swift_name("storeAt(index:value_:)")));
@property (readonly) void *pointer __attribute__((swift_name("pointer")));
@property (readonly) int64_t size __attribute__((swift_name("size")));
@property (readonly) int32_t size32 __attribute__((swift_name("size32")));
@end;

__attribute__((swift_name("Ktor_ioBuffer")))
@interface IPGSCKtor_ioBuffer : IPGSCBase
- (instancetype)initWithMemory:(IPGSCKtor_ioMemory *)memory __attribute__((swift_name("init(memory:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) IPGSCKtor_ioBufferCompanion *companion __attribute__((swift_name("companion")));
- (void)commitWrittenCount:(int32_t)count __attribute__((swift_name("commitWritten(count:)")));
- (void)discardExactCount:(int32_t)count __attribute__((swift_name("discardExact(count:)")));
- (IPGSCKtor_ioBuffer *)duplicate __attribute__((swift_name("duplicate()")));
- (void)duplicateToCopy:(IPGSCKtor_ioBuffer *)copy __attribute__((swift_name("duplicateTo(copy:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (void)reserveEndGapEndGap:(int32_t)endGap __attribute__((swift_name("reserveEndGap(endGap:)")));
- (void)reserveStartGapStartGap:(int32_t)startGap __attribute__((swift_name("reserveStartGap(startGap:)")));
- (void)reset __attribute__((swift_name("reset()")));
- (void)resetForRead __attribute__((swift_name("resetForRead()")));
- (void)resetForWrite __attribute__((swift_name("resetForWrite()")));
- (void)resetForWriteLimit:(int32_t)limit __attribute__((swift_name("resetForWrite(limit:)")));
- (void)rewindCount:(int32_t)count __attribute__((swift_name("rewind(count:)")));
- (NSString *)description __attribute__((swift_name("description()")));
- (int32_t)tryPeekByte __attribute__((swift_name("tryPeekByte()")));
- (int32_t)tryReadByte __attribute__((swift_name("tryReadByte()")));
- (void)writeByteValue:(int8_t)value __attribute__((swift_name("writeByte(value:)")));
@property (readonly) int32_t capacity __attribute__((swift_name("capacity")));
@property (readonly) int32_t endGap __attribute__((swift_name("endGap")));
@property (readonly) int32_t limit __attribute__((swift_name("limit")));
@property (readonly) IPGSCKtor_ioMemory *memory __attribute__((swift_name("memory")));
@property (readonly) int32_t readPosition __attribute__((swift_name("readPosition")));
@property (readonly) int32_t readRemaining __attribute__((swift_name("readRemaining")));
@property (readonly) int32_t startGap __attribute__((swift_name("startGap")));
@property (readonly) int32_t writePosition __attribute__((swift_name("writePosition")));
@property (readonly) int32_t writeRemaining __attribute__((swift_name("writeRemaining")));
@end;

__attribute__((swift_name("Ktor_ioChunkBuffer")))
@interface IPGSCKtor_ioChunkBuffer : IPGSCKtor_ioBuffer
- (instancetype)initWithMemory:(IPGSCKtor_ioMemory *)memory origin:(IPGSCKtor_ioChunkBuffer * _Nullable)origin parentPool:(id<IPGSCKtor_ioObjectPool> _Nullable)parentPool __attribute__((swift_name("init(memory:origin:parentPool:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMemory:(IPGSCKtor_ioMemory *)memory __attribute__((swift_name("init(memory:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) IPGSCKtor_ioChunkBufferCompanion *companion __attribute__((swift_name("companion")));
- (IPGSCKtor_ioChunkBuffer * _Nullable)cleanNext __attribute__((swift_name("cleanNext()")));
- (IPGSCKtor_ioChunkBuffer *)duplicate __attribute__((swift_name("duplicate()")));
- (void)releasePool:(id<IPGSCKtor_ioObjectPool>)pool __attribute__((swift_name("release(pool:)")));
- (void)reset __attribute__((swift_name("reset()")));
@property (getter=next__) IPGSCKtor_ioChunkBuffer * _Nullable next __attribute__((swift_name("next")));
@property (readonly) IPGSCKtor_ioChunkBuffer * _Nullable origin __attribute__((swift_name("origin")));
@property (readonly) int32_t referenceCount __attribute__((swift_name("referenceCount")));
@end;

__attribute__((swift_name("Ktor_ioInput")))
@interface IPGSCKtor_ioInput : IPGSCBase <IPGSCKtor_ioCloseable>
- (instancetype)initWithHead:(IPGSCKtor_ioChunkBuffer *)head remaining:(int64_t)remaining pool:(id<IPGSCKtor_ioObjectPool>)pool __attribute__((swift_name("init(head:remaining:pool:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) IPGSCKtor_ioInputCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)canRead __attribute__((swift_name("canRead()")));
- (void)close __attribute__((swift_name("close()")));
- (void)closeSource __attribute__((swift_name("closeSource()")));
- (int32_t)discardN:(int32_t)n __attribute__((swift_name("discard(n:)")));
- (int64_t)discardN_:(int64_t)n __attribute__((swift_name("discard(n_:)")));
- (void)discardExactN:(int32_t)n __attribute__((swift_name("discardExact(n:)")));
- (IPGSCKtor_ioChunkBuffer * _Nullable)fill __attribute__((swift_name("fill()")));
- (int32_t)fillDestination:(IPGSCKtor_ioMemory *)destination offset:(int32_t)offset length:(int32_t)length __attribute__((swift_name("fill(destination:offset:length:)")));
- (BOOL)hasBytesN:(int32_t)n __attribute__((swift_name("hasBytes(n:)")));
- (void)markNoMoreChunksAvailable __attribute__((swift_name("markNoMoreChunksAvailable()")));
- (int64_t)peekToDestination:(IPGSCKtor_ioMemory *)destination destinationOffset:(int64_t)destinationOffset offset:(int64_t)offset min:(int64_t)min max:(int64_t)max __attribute__((swift_name("peekTo(destination:destinationOffset:offset:min:max:)")));
- (int32_t)peekToBuffer:(IPGSCKtor_ioChunkBuffer *)buffer __attribute__((swift_name("peekTo(buffer:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (NSString *)readTextMin:(int32_t)min max:(int32_t)max __attribute__((swift_name("readText(min:max:)")));
- (int32_t)readTextOut:(id<IPGSCKotlinAppendable>)out min:(int32_t)min max:(int32_t)max __attribute__((swift_name("readText(out:min:max:)")));
- (NSString *)readTextExactExactCharacters:(int32_t)exactCharacters __attribute__((swift_name("readTextExact(exactCharacters:)")));
- (void)readTextExactOut:(id<IPGSCKotlinAppendable>)out exactCharacters:(int32_t)exactCharacters __attribute__((swift_name("readTextExact(out:exactCharacters:)")));
- (void)release_ __attribute__((swift_name("release()")));
- (int32_t)tryPeek __attribute__((swift_name("tryPeek()")));
@property (readonly) BOOL endOfInput __attribute__((swift_name("endOfInput")));
@property (readonly) id<IPGSCKtor_ioObjectPool> pool __attribute__((swift_name("pool")));
@property (readonly) int64_t remaining __attribute__((swift_name("remaining")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioByteReadPacket")))
@interface IPGSCKtor_ioByteReadPacket : IPGSCKtor_ioInput
- (instancetype)initWithHead:(IPGSCKtor_ioChunkBuffer *)head pool:(id<IPGSCKtor_ioObjectPool>)pool __attribute__((swift_name("init(head:pool:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithHead:(IPGSCKtor_ioChunkBuffer *)head remaining:(int64_t)remaining pool:(id<IPGSCKtor_ioObjectPool>)pool __attribute__((swift_name("init(head:remaining:pool:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) IPGSCKtor_ioByteReadPacketCompanion *companion __attribute__((swift_name("companion")));
- (void)closeSource __attribute__((swift_name("closeSource()")));
- (IPGSCKtor_ioByteReadPacket *)doCopy __attribute__((swift_name("doCopy()")));
- (IPGSCKtor_ioChunkBuffer * _Nullable)fill __attribute__((swift_name("fill()")));
- (int32_t)fillDestination:(IPGSCKtor_ioMemory *)destination offset:(int32_t)offset length:(int32_t)length __attribute__((swift_name("fill(destination:offset:length:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@end;

__attribute__((swift_name("Ktor_ioReadSession")))
@protocol IPGSCKtor_ioReadSession
@required
- (int32_t)discardN:(int32_t)n __attribute__((swift_name("discard(n:)")));
- (IPGSCKtor_ioChunkBuffer * _Nullable)requestAtLeast:(int32_t)atLeast __attribute__((swift_name("request(atLeast:)")));
@property (readonly) int32_t availableForRead __attribute__((swift_name("availableForRead")));
@end;

__attribute__((swift_name("KotlinSuspendFunction1")))
@protocol IPGSCKotlinSuspendFunction1 <IPGSCKotlinFunction>
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeP1:(id _Nullable)p1 completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(p1:completionHandler:)")));
@end;

__attribute__((swift_name("KotlinAppendable")))
@protocol IPGSCKotlinAppendable
@required
- (id<IPGSCKotlinAppendable>)appendValue:(unichar)value __attribute__((swift_name("append(value:)")));
- (id<IPGSCKotlinAppendable>)appendValue_:(id _Nullable)value __attribute__((swift_name("append(value_:)")));
- (id<IPGSCKotlinAppendable>)appendValue:(id _Nullable)value startIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("append(value:startIndex:endIndex:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLBuilder.Companion")))
@interface IPGSCKtor_httpURLBuilderCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCKtor_httpURLBuilderCompanion *shared __attribute__((swift_name("shared")));
@end;

__attribute__((swift_name("Ktor_httpParametersBuilder")))
@protocol IPGSCKtor_httpParametersBuilder <IPGSCKtor_utilsStringValuesBuilder>
@required
@end;

__attribute__((swift_name("KotlinKType")))
@protocol IPGSCKotlinKType
@required
@property (readonly) NSArray<IPGSCKotlinKTypeProjection *> *arguments __attribute__((swift_name("arguments")));
@property (readonly) id<IPGSCKotlinKClassifier> _Nullable classifier __attribute__((swift_name("classifier")));
@property (readonly) BOOL isMarkedNullable __attribute__((swift_name("isMarkedNullable")));
@end;

__attribute__((swift_name("Kodein_diWithContext")))
@protocol IPGSCKodein_diWithContext
@required
@property (readonly) id context __attribute__((swift_name("context")));
@end;

__attribute__((swift_name("Kodein_diBindingDI")))
@protocol IPGSCKodein_diBindingDI <IPGSCKodein_diDirectDI, IPGSCKodein_diWithContext>
@required
- (id<IPGSCKodein_diBindingDI>)onErasedContext __attribute__((swift_name("onErasedContext()")));
- (id (^)(id _Nullable))overriddenFactory __attribute__((swift_name("overriddenFactory()")));
- (id (^ _Nullable)(id _Nullable))overriddenFactoryOrNull __attribute__((swift_name("overriddenFactoryOrNull()")));
@end;

__attribute__((swift_name("Kodein_diDIBindingCopier")))
@protocol IPGSCKodein_diDIBindingCopier
@required
- (id<IPGSCKodein_diDIBinding>)doCopyBuilder:(id<IPGSCKodein_diDIContainerBuilder>)builder __attribute__((swift_name("doCopy(builder:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kodein_diReference")))
@interface IPGSCKodein_diReference<__covariant T> : IPGSCBase
- (instancetype)initWithCurrent:(T)current next:(T _Nullable (^)(void))next __attribute__((swift_name("init(current:next:)"))) __attribute__((objc_designated_initializer));
- (T)component1 __attribute__((swift_name("component1()")));
- (T _Nullable (^)(void))component2 __attribute__((swift_name("component2()")));
- (IPGSCKodein_diReference<T> *)doCopyCurrent:(T)current next:(T _Nullable (^)(void))next __attribute__((swift_name("doCopy(current:next:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) T current __attribute__((swift_name("current")));
@property (readonly) T _Nullable (^next)(void) __attribute__((swift_name("next")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLProtocol.Companion")))
@interface IPGSCKtor_httpURLProtocolCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCKtor_httpURLProtocolCompanion *shared __attribute__((swift_name("shared")));
- (IPGSCKtor_httpURLProtocol *)createOrDefaultName:(NSString *)name __attribute__((swift_name("createOrDefault(name:)")));
@property (readonly) IPGSCKtor_httpURLProtocol *HTTP __attribute__((swift_name("HTTP")));
@property (readonly) IPGSCKtor_httpURLProtocol *HTTPS __attribute__((swift_name("HTTPS")));
@property (readonly) IPGSCKtor_httpURLProtocol *SOCKS __attribute__((swift_name("SOCKS")));
@property (readonly) IPGSCKtor_httpURLProtocol *WS __attribute__((swift_name("WS")));
@property (readonly) IPGSCKtor_httpURLProtocol *WSS __attribute__((swift_name("WSS")));
@property (readonly) NSDictionary<NSString *, IPGSCKtor_httpURLProtocol *> *byName __attribute__((swift_name("byName")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeaderValueParam")))
@interface IPGSCKtor_httpHeaderValueParam : IPGSCBase
- (instancetype)initWithName:(NSString *)name value:(NSString *)value __attribute__((swift_name("init(name:value:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (IPGSCKtor_httpHeaderValueParam *)doCopyName:(NSString *)name value:(NSString *)value __attribute__((swift_name("doCopy(name:value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeaderValueWithParameters.Companion")))
@interface IPGSCKtor_httpHeaderValueWithParametersCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCKtor_httpHeaderValueWithParametersCompanion *shared __attribute__((swift_name("shared")));
- (id _Nullable)parseValue:(NSString *)value init:(id _Nullable (^)(NSString *, NSArray<IPGSCKtor_httpHeaderValueParam *> *))init __attribute__((swift_name("parse(value:init:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpContentType.Companion")))
@interface IPGSCKtor_httpContentTypeCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCKtor_httpContentTypeCompanion *shared __attribute__((swift_name("shared")));
- (IPGSCKtor_httpContentType *)parseValue:(NSString *)value __attribute__((swift_name("parse(value:)")));
@property (readonly) IPGSCKtor_httpContentType *Any __attribute__((swift_name("Any")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreParentJob")))
@protocol IPGSCKotlinx_coroutines_coreParentJob <IPGSCKotlinx_coroutines_coreJob>
@required
- (IPGSCKotlinCancellationException *)getChildJobCancellationCause __attribute__((swift_name("getChildJobCancellationCause()")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreSelectInstance")))
@protocol IPGSCKotlinx_coroutines_coreSelectInstance
@required
- (void)disposeOnSelectHandle:(id<IPGSCKotlinx_coroutines_coreDisposableHandle>)handle __attribute__((swift_name("disposeOnSelect(handle:)")));
- (id _Nullable)performAtomicTrySelectDesc:(IPGSCKotlinx_coroutines_coreAtomicDesc *)desc __attribute__((swift_name("performAtomicTrySelect(desc:)")));
- (void)resumeSelectWithExceptionException:(IPGSCKotlinThrowable *)exception __attribute__((swift_name("resumeSelectWithException(exception:)")));
- (BOOL)trySelect __attribute__((swift_name("trySelect()")));
- (id _Nullable)trySelectOtherOtherOp:(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNodePrepareOp * _Nullable)otherOp __attribute__((swift_name("trySelectOther(otherOp:)")));
@property (readonly) id<IPGSCKotlinContinuation> completion __attribute__((swift_name("completion")));
@property (readonly) BOOL isSelected __attribute__((swift_name("isSelected")));
@end;

__attribute__((swift_name("KotlinSuspendFunction0")))
@protocol IPGSCKotlinSuspendFunction0 <IPGSCKotlinFunction>
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsWeekDay.Companion")))
@interface IPGSCKtor_utilsWeekDayCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCKtor_utilsWeekDayCompanion *shared __attribute__((swift_name("shared")));
- (IPGSCKtor_utilsWeekDay *)fromOrdinal:(int32_t)ordinal __attribute__((swift_name("from(ordinal:)")));
- (IPGSCKtor_utilsWeekDay *)fromValue:(NSString *)value __attribute__((swift_name("from(value:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsMonth.Companion")))
@interface IPGSCKtor_utilsMonthCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCKtor_utilsMonthCompanion *shared __attribute__((swift_name("shared")));
- (IPGSCKtor_utilsMonth *)fromOrdinal:(int32_t)ordinal __attribute__((swift_name("from(ordinal:)")));
- (IPGSCKtor_utilsMonth *)fromValue:(NSString *)value __attribute__((swift_name("from(value:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioMemory.Companion")))
@interface IPGSCKtor_ioMemoryCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCKtor_ioMemoryCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) IPGSCKtor_ioMemory *Empty __attribute__((swift_name("Empty")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioBuffer.Companion")))
@interface IPGSCKtor_ioBufferCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCKtor_ioBufferCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) IPGSCKtor_ioBuffer *Empty __attribute__((swift_name("Empty")));
@property (readonly) int32_t ReservedSize __attribute__((swift_name("ReservedSize")));
@end;

__attribute__((swift_name("Ktor_ioObjectPool")))
@protocol IPGSCKtor_ioObjectPool <IPGSCKtor_ioCloseable>
@required
- (id)borrow __attribute__((swift_name("borrow()")));
- (void)dispose __attribute__((swift_name("dispose()")));
- (void)recycleInstance:(id)instance __attribute__((swift_name("recycle(instance:)")));
@property (readonly) int32_t capacity __attribute__((swift_name("capacity")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioChunkBuffer.Companion")))
@interface IPGSCKtor_ioChunkBufferCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCKtor_ioChunkBufferCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) IPGSCKtor_ioChunkBuffer *Empty __attribute__((swift_name("Empty")));
@property (readonly) id<IPGSCKtor_ioObjectPool> EmptyPool __attribute__((swift_name("EmptyPool")));
@property (readonly) id<IPGSCKtor_ioObjectPool> Pool __attribute__((swift_name("Pool")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioInput.Companion")))
@interface IPGSCKtor_ioInputCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCKtor_ioInputCompanion *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioByteReadPacket.Companion")))
@interface IPGSCKtor_ioByteReadPacketCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCKtor_ioByteReadPacketCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) IPGSCKtor_ioByteReadPacket *Empty __attribute__((swift_name("Empty")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKTypeProjection")))
@interface IPGSCKotlinKTypeProjection : IPGSCBase
- (instancetype)initWithVariance:(IPGSCKotlinKVariance * _Nullable)variance type:(id<IPGSCKotlinKType> _Nullable)type __attribute__((swift_name("init(variance:type:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) IPGSCKotlinKTypeProjectionCompanion *companion __attribute__((swift_name("companion")));
- (IPGSCKotlinKVariance * _Nullable)component1 __attribute__((swift_name("component1()")));
- (id<IPGSCKotlinKType> _Nullable)component2 __attribute__((swift_name("component2()")));
- (IPGSCKotlinKTypeProjection *)doCopyVariance:(IPGSCKotlinKVariance * _Nullable)variance type:(id<IPGSCKotlinKType> _Nullable)type __attribute__((swift_name("doCopy(variance:type:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<IPGSCKotlinKType> _Nullable type __attribute__((swift_name("type")));
@property (readonly) IPGSCKotlinKVariance * _Nullable variance __attribute__((swift_name("variance")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreAtomicDesc")))
@interface IPGSCKotlinx_coroutines_coreAtomicDesc : IPGSCBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)completeOp:(IPGSCKotlinx_coroutines_coreAtomicOp<id> *)op failure:(id _Nullable)failure __attribute__((swift_name("complete(op:failure:)")));
- (id _Nullable)prepareOp:(IPGSCKotlinx_coroutines_coreAtomicOp<id> *)op __attribute__((swift_name("prepare(op:)")));
@property IPGSCKotlinx_coroutines_coreAtomicOp<id> *atomicOp __attribute__((swift_name("atomicOp")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreOpDescriptor")))
@interface IPGSCKotlinx_coroutines_coreOpDescriptor : IPGSCBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (BOOL)isEarlierThanThat:(IPGSCKotlinx_coroutines_coreOpDescriptor *)that __attribute__((swift_name("isEarlierThan(that:)")));
- (id _Nullable)performAffected:(id _Nullable)affected __attribute__((swift_name("perform(affected:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) IPGSCKotlinx_coroutines_coreAtomicOp<id> * _Nullable atomicOp __attribute__((swift_name("atomicOp")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_coroutines_coreLockFreeLinkedListNode.PrepareOp")))
@interface IPGSCKotlinx_coroutines_coreLockFreeLinkedListNodePrepareOp : IPGSCKotlinx_coroutines_coreOpDescriptor
- (instancetype)initWithAffected:(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *)next desc:(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNodeAbstractAtomicDesc *)desc __attribute__((swift_name("init(affected:next:desc:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (void)finishPrepare __attribute__((swift_name("finishPrepare()")));
- (id _Nullable)performAffected:(id _Nullable)affected __attribute__((swift_name("perform(affected:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *affected __attribute__((swift_name("affected")));
@property (readonly) IPGSCKotlinx_coroutines_coreAtomicOp<id> *atomicOp __attribute__((swift_name("atomicOp")));
@property (readonly) IPGSCKotlinx_coroutines_coreLockFreeLinkedListNodeAbstractAtomicDesc *desc __attribute__((swift_name("desc")));
@property (readonly) IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *next __attribute__((swift_name("next")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKVariance")))
@interface IPGSCKotlinKVariance : IPGSCKotlinEnum<IPGSCKotlinKVariance *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) IPGSCKotlinKVariance *invariant __attribute__((swift_name("invariant")));
@property (class, readonly) IPGSCKotlinKVariance *in __attribute__((swift_name("in")));
@property (class, readonly) IPGSCKotlinKVariance *out __attribute__((swift_name("out")));
+ (IPGSCKotlinArray<IPGSCKotlinKVariance *> *)values __attribute__((swift_name("values()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKTypeProjection.Companion")))
@interface IPGSCKotlinKTypeProjectionCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) IPGSCKotlinKTypeProjectionCompanion *shared __attribute__((swift_name("shared")));
- (IPGSCKotlinKTypeProjection *)contravariantType:(id<IPGSCKotlinKType>)type __attribute__((swift_name("contravariant(type:)")));
- (IPGSCKotlinKTypeProjection *)covariantType:(id<IPGSCKotlinKType>)type __attribute__((swift_name("covariant(type:)")));
- (IPGSCKotlinKTypeProjection *)invariantType:(id<IPGSCKotlinKType>)type __attribute__((swift_name("invariant(type:)")));
@property (readonly) IPGSCKotlinKTypeProjection *STAR __attribute__((swift_name("STAR")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreAtomicOp")))
@interface IPGSCKotlinx_coroutines_coreAtomicOp<__contravariant T> : IPGSCKotlinx_coroutines_coreOpDescriptor
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)completeAffected:(T _Nullable)affected failure:(id _Nullable)failure __attribute__((swift_name("complete(affected:failure:)")));
- (id _Nullable)decideDecision:(id _Nullable)decision __attribute__((swift_name("decide(decision:)")));
- (id _Nullable)performAffected:(id _Nullable)affected __attribute__((swift_name("perform(affected:)")));
- (id _Nullable)prepareAffected:(T _Nullable)affected __attribute__((swift_name("prepare(affected:)")));
@property (readonly) IPGSCKotlinx_coroutines_coreAtomicOp<id> *atomicOp __attribute__((swift_name("atomicOp")));
@property (readonly) id _Nullable consensus __attribute__((swift_name("consensus")));
@property (readonly) BOOL isDecided __attribute__((swift_name("isDecided")));
@property (readonly) int64_t opSequence __attribute__((swift_name("opSequence")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreLockFreeLinkedListNode")))
@interface IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode : IPGSCBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)addLastNode:(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *)node __attribute__((swift_name("addLast(node:)")));
- (BOOL)addLastIfNode:(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *)node condition:(IPGSCBoolean *(^)(void))condition __attribute__((swift_name("addLastIf(node:condition:)")));
- (BOOL)addLastIfPrevNode:(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *)node predicate:(IPGSCBoolean *(^)(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *))predicate __attribute__((swift_name("addLastIfPrev(node:predicate:)")));
- (BOOL)addLastIfPrevAndIfNode:(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *)node predicate:(IPGSCBoolean *(^)(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *))predicate condition:(IPGSCBoolean *(^)(void))condition __attribute__((swift_name("addLastIfPrevAndIf(node:predicate:condition:)")));
- (BOOL)addOneIfEmptyNode:(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *)node __attribute__((swift_name("addOneIfEmpty(node:)")));
- (IPGSCKotlinx_coroutines_coreLockFreeLinkedListNodeAddLastDesc<IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *> *)describeAddLastNode:(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *)node __attribute__((swift_name("describeAddLast(node:)")));
- (IPGSCKotlinx_coroutines_coreLockFreeLinkedListNodeRemoveFirstDesc<IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *> *)describeRemoveFirst __attribute__((swift_name("describeRemoveFirst()")));
- (void)helpRemove __attribute__((swift_name("helpRemove()")));
- (IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable)nextIfRemoved __attribute__((swift_name("nextIfRemoved()")));
- (BOOL)remove __attribute__((swift_name("remove()")));
- (id _Nullable)removeFirstIfIsInstanceOfOrPeekIfPredicate:(IPGSCBoolean *(^)(id _Nullable))predicate __attribute__((swift_name("removeFirstIfIsInstanceOfOrPeekIf(predicate:)")));
- (IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable)removeFirstOrNull __attribute__((swift_name("removeFirstOrNull()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL isRemoved __attribute__((swift_name("isRemoved")));
@property (readonly, getter=next__) id next __attribute__((swift_name("next")));
@property (readonly) IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *nextNode __attribute__((swift_name("nextNode")));
@property (readonly) IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *prevNode __attribute__((swift_name("prevNode")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreLockFreeLinkedListNode.AbstractAtomicDesc")))
@interface IPGSCKotlinx_coroutines_coreLockFreeLinkedListNodeAbstractAtomicDesc : IPGSCKotlinx_coroutines_coreAtomicDesc
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)completeOp:(IPGSCKotlinx_coroutines_coreAtomicOp<id> *)op failure:(id _Nullable)failure __attribute__((swift_name("complete(op:failure:)")));
- (id _Nullable)failureAffected:(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *)affected __attribute__((swift_name("failure(affected:)")));
- (void)finishOnSuccessAffected:(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *)next __attribute__((swift_name("finishOnSuccess(affected:next:)")));
- (void)finishPreparePrepareOp:(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNodePrepareOp *)prepareOp __attribute__((swift_name("finishPrepare(prepareOp:)")));
- (id _Nullable)onPreparePrepareOp:(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNodePrepareOp *)prepareOp __attribute__((swift_name("onPrepare(prepareOp:)")));
- (void)onRemovedAffected:(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *)affected __attribute__((swift_name("onRemoved(affected:)")));
- (id _Nullable)prepareOp:(IPGSCKotlinx_coroutines_coreAtomicOp<id> *)op __attribute__((swift_name("prepare(op:)")));
- (BOOL)retryAffected:(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(id)next __attribute__((swift_name("retry(affected:next:)")));
- (IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable)takeAffectedNodeOp:(IPGSCKotlinx_coroutines_coreOpDescriptor *)op __attribute__((swift_name("takeAffectedNode(op:)")));
- (id)updatedNextAffected:(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *)next __attribute__((swift_name("updatedNext(affected:next:)")));
@property (readonly) IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable affectedNode __attribute__((swift_name("affectedNode")));
@property (readonly) IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable originalNext __attribute__((swift_name("originalNext")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreLockFreeLinkedListNodeAddLastDesc")))
@interface IPGSCKotlinx_coroutines_coreLockFreeLinkedListNodeAddLastDesc<T> : IPGSCKotlinx_coroutines_coreLockFreeLinkedListNodeAbstractAtomicDesc
- (instancetype)initWithQueue:(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *)queue node:(T)node __attribute__((swift_name("init(queue:node:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (void)finishOnSuccessAffected:(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *)next __attribute__((swift_name("finishOnSuccess(affected:next:)")));
- (void)finishPreparePrepareOp:(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNodePrepareOp *)prepareOp __attribute__((swift_name("finishPrepare(prepareOp:)")));
- (BOOL)retryAffected:(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(id)next __attribute__((swift_name("retry(affected:next:)")));
- (IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable)takeAffectedNodeOp:(IPGSCKotlinx_coroutines_coreOpDescriptor *)op __attribute__((swift_name("takeAffectedNode(op:)")));
- (id)updatedNextAffected:(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *)next __attribute__((swift_name("updatedNext(affected:next:)")));
@property (readonly) IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable affectedNode __attribute__((swift_name("affectedNode")));
@property (readonly) T node __attribute__((swift_name("node")));
@property (readonly) IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *originalNext __attribute__((swift_name("originalNext")));
@property (readonly) IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *queue __attribute__((swift_name("queue")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreLockFreeLinkedListNodeRemoveFirstDesc")))
@interface IPGSCKotlinx_coroutines_coreLockFreeLinkedListNodeRemoveFirstDesc<T> : IPGSCKotlinx_coroutines_coreLockFreeLinkedListNodeAbstractAtomicDesc
- (instancetype)initWithQueue:(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *)queue __attribute__((swift_name("init(queue:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (id _Nullable)failureAffected:(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *)affected __attribute__((swift_name("failure(affected:)")));
- (void)finishOnSuccessAffected:(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *)next __attribute__((swift_name("finishOnSuccess(affected:next:)")));
- (void)finishPreparePrepareOp:(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNodePrepareOp *)prepareOp __attribute__((swift_name("finishPrepare(prepareOp:)")));
- (BOOL)retryAffected:(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(id)next __attribute__((swift_name("retry(affected:next:)")));
- (IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable)takeAffectedNodeOp:(IPGSCKotlinx_coroutines_coreOpDescriptor *)op __attribute__((swift_name("takeAffectedNode(op:)")));
- (id)updatedNextAffected:(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *)next __attribute__((swift_name("updatedNext(affected:next:)")));
@property (readonly) IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable affectedNode __attribute__((swift_name("affectedNode")));
@property (readonly) IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable originalNext __attribute__((swift_name("originalNext")));
@property (readonly) IPGSCKotlinx_coroutines_coreLockFreeLinkedListNode *queue __attribute__((swift_name("queue")));
@property (readonly) T _Nullable result __attribute__((swift_name("result")));
@end;

#pragma pop_macro("_Nullable_result")
#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
